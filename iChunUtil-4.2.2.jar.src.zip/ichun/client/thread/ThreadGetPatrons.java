/*    */ package ichun.client.thread;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import ichun.common.iChunUtil;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import java.net.URL;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class ThreadGetPatrons
/*    */   extends Thread
/*    */ {
/* 16 */   public String patronList = "https://raw.github.com/iChun/iChunUtil/master/src/main/resources/assets/ichunutil/mod/patrons.json";
/*    */ 
/*    */   
/*    */   public ThreadGetPatrons() {
/* 20 */     setName("iChunUtil Patron Getter Thread");
/* 21 */     setDaemon(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     try {
/* 29 */       Gson gson = new Gson();
/* 30 */       Reader fileIn = new InputStreamReader((new URL(this.patronList)).openStream());
/* 31 */       String[] json = (String[])gson.fromJson(fileIn, String[].class);
/* 32 */       fileIn.close();
/*    */       
/* 34 */       if (json != null)
/*    */       {
/* 36 */         for (String s : json) {
/*    */           
/* 38 */           if (s.replaceAll("-", "").equalsIgnoreCase(Minecraft.func_71410_x().func_110432_I().func_148255_b()))
/*    */           {
/* 40 */             iChunUtil.isPatron = true;
/* 41 */             iChunUtil.config.setCurrentCategory("patreon", "ichun.config.patreon.name", "ichun.config.patreon.comment");
/* 42 */             iChunUtil.config.createIntBoolProperty("showPatronReward", "ichun.config.showPatronReward.name", "ichun.config.showPatronReward.comment", true, false, true);
/* 43 */             iChunUtil.config.save();
/*    */           }
/*    */         
/*    */         } 
/*    */       }
/* 48 */     } catch (Exception e) {
/*    */       
/* 50 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\thread\ThreadGetPatrons.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */