/*     */ package ichun.client.gui;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import ichun.common.core.CommonProxy;
/*     */ import ichun.common.core.updateChecker.ModVersionChecker;
/*     */ import ichun.common.iChunUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiModUpdateNotification
/*     */   extends Gui
/*     */ {
/*  25 */   private static final ResourceLocation rlAchievement = new ResourceLocation("textures/gui/achievement/achievement_background.png");
/*     */   private Minecraft mc;
/*     */   private int width;
/*     */   private int height;
/*     */   private String topText;
/*     */   private long achiTime;
/*  31 */   public ArrayList<String> modUpdatesPending = new ArrayList<String>();
/*  32 */   public ArrayList<String> modUpdates = new ArrayList<String>();
/*  33 */   public ArrayList<String> modUpdatesDone = new ArrayList<String>();
/*     */   
/*     */   public boolean shouldRender;
/*     */   
/*     */   public boolean pending;
/*     */   
/*     */   public GuiModUpdateNotification(Minecraft par1Minecraft) {
/*  40 */     this.mc = par1Minecraft;
/*  41 */     this.shouldRender = false;
/*  42 */     this.topText = StatCollector.func_74838_a("ichun.gui.newUpdate");
/*     */   }
/*     */ 
/*     */   
/*     */   public void addModUpdate(String modName, String version) {
/*  47 */     boolean render = this.shouldRender;
/*     */     
/*  49 */     if (iChunUtil.config.getInt("versionNotificationFrequency") == 3) {
/*     */       
/*  51 */       iChunUtil.console("[NEW UPDATE AVAILABLE] " + modName + " - " + version);
/*     */       return;
/*     */     } 
/*  54 */     if (iChunUtil.config.getInt("versionNotificationFrequency") == 2) {
/*     */       
/*  56 */       for (Map.Entry<String, String> e : (Iterable<Map.Entry<String, String>>)CommonProxy.versionChecker.entrySet())
/*     */       {
/*  58 */         String oldVer = (String)CommonProxy.prevVerChecker.get(e.getKey());
/*  59 */         if (oldVer != null && oldVer.equals(e.getValue())) {
/*     */           return;
/*     */         }
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  67 */       this.shouldRender = (iChunUtil.config.getInt("versionNotificationFrequency") == 0 || (iChunUtil.config.getInt("versionNotificationFrequency") == 1 && ModVersionChecker.differentDay));
/*     */     } 
/*     */     
/*  70 */     if (!this.modUpdatesPending.contains(modName + " - " + version)) {
/*     */       
/*  72 */       this.pending = true;
/*     */       
/*  74 */       this.modUpdatesPending.add(modName + " - " + version);
/*  75 */       while ((this.height == 0 || this.modUpdates.size() * 32.0D < this.height) && !this.modUpdatesPending.isEmpty()) {
/*     */         
/*  77 */         this.modUpdates.add(this.modUpdatesPending.get(0));
/*  78 */         this.modUpdatesPending.remove(0);
/*     */         
/*  80 */         if (render) {
/*     */           
/*  82 */           this.achiTime = Minecraft.func_71386_F() - 250L;
/*     */         }
/*     */         else {
/*     */           
/*  86 */           this.achiTime = Minecraft.func_71386_F();
/*     */         } 
/*  88 */         Collections.sort(this.modUpdates);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateWindowScale() {
/*  95 */     GL11.glViewport(0, 0, this.mc.field_71443_c, this.mc.field_71440_d);
/*  96 */     GL11.glMatrixMode(5889);
/*  97 */     GL11.glLoadIdentity();
/*  98 */     GL11.glMatrixMode(5888);
/*  99 */     GL11.glLoadIdentity();
/* 100 */     this.width = this.mc.field_71443_c;
/* 101 */     this.height = this.mc.field_71440_d;
/* 102 */     ScaledResolution scaledresolution = new ScaledResolution(this.mc, this.mc.field_71443_c, this.mc.field_71440_d);
/* 103 */     this.width = scaledresolution.func_78326_a();
/* 104 */     this.height = scaledresolution.func_78328_b();
/* 105 */     GL11.glClear(256);
/* 106 */     GL11.glMatrixMode(5889);
/* 107 */     GL11.glLoadIdentity();
/* 108 */     GL11.glOrtho(0.0D, this.width, this.height, 0.0D, 1000.0D, 3000.0D);
/* 109 */     GL11.glMatrixMode(5888);
/* 110 */     GL11.glLoadIdentity();
/* 111 */     GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void update() {
/* 116 */     if (this.pending) {
/*     */       
/* 118 */       this.pending = false;
/* 119 */       this.achiTime = Minecraft.func_71386_F() + 5000L;
/*     */     } 
/* 121 */     if (this.shouldRender && this.achiTime != 0L && (Minecraft.func_71410_x()).field_71439_g != null)
/*     */     {
/* 123 */       for (int k = 0; k < this.modUpdates.size(); k++) {
/*     */         
/* 125 */         double d0 = (Minecraft.func_71386_F() - this.achiTime) / (3000.0D + 500.0D * (this.modUpdates.size() - 1));
/*     */         
/* 127 */         if ((d0 < -5.0D || d0 > 1.0D) && k == this.modUpdates.size() - 1) {
/*     */           
/* 129 */           this.shouldRender = false;
/* 130 */           this.achiTime = 0L;
/* 131 */           for (int l = 0; l < this.modUpdates.size(); l++) {
/*     */             
/* 133 */             String s = this.modUpdates.get(l);
/* 134 */             iChunUtil.console("[NEW UPDATE AVAILABLE] " + s);
/*     */           } 
/* 136 */           this.modUpdatesDone.addAll(this.modUpdates);
/* 137 */           this.modUpdates.clear();
/*     */           
/* 139 */           if (this.modUpdatesPending.isEmpty())
/*     */           {
/* 141 */             ModVersionChecker.differentDay = false;
/*     */           }
/*     */           
/* 144 */           while (this.modUpdates.size() * 32.0D < this.height && !this.modUpdatesPending.isEmpty()) {
/*     */             
/* 146 */             this.modUpdates.add(this.modUpdatesPending.get(0));
/* 147 */             this.modUpdatesPending.remove(0);
/* 148 */             this.achiTime = Minecraft.func_71386_F();
/* 149 */             Collections.sort(this.modUpdates);
/*     */           } 
/* 151 */           this.shouldRender = true;
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 156 */         updateWindowScale();
/* 157 */         GL11.glDisable(2929);
/* 158 */         GL11.glDepthMask(false);
/* 159 */         double d1 = d0 * 2.0D;
/*     */         
/* 161 */         if (d1 > 1.0D)
/*     */         {
/* 163 */           d1 = 2.0D - d1;
/*     */         }
/*     */         
/* 166 */         d1 *= 4.0D;
/* 167 */         d1 = 1.0D - d1;
/*     */         
/* 169 */         if (d1 < 0.0D)
/*     */         {
/* 171 */           d1 = 0.0D;
/*     */         }
/*     */         
/* 174 */         d1 *= d1;
/* 175 */         d1 *= d1;
/* 176 */         int i = 0;
/* 177 */         int j = (int)(32.0D * k * (1.0D - d1)) - (int)(d1 * 36.0D);
/* 178 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 179 */         GL11.glEnable(3553);
/* 180 */         this.mc.func_110434_K().func_110577_a(rlAchievement);
/* 181 */         GL11.glDisable(2896);
/* 182 */         func_73729_b(i, j, 96, 202, 160, 32);
/*     */         
/* 184 */         this.mc.field_71466_p.func_78276_b(this.topText, i + 10, j + 7, -256);
/* 185 */         this.mc.field_71466_p.func_78276_b(this.modUpdates.get(k), i + 15, j + 18, -1);
/*     */         
/* 187 */         RenderHelper.func_74520_c();
/* 188 */         GL11.glDisable(2896);
/* 189 */         GL11.glEnable(32826);
/* 190 */         GL11.glEnable(2903);
/* 191 */         GL11.glDepthMask(true);
/* 192 */         GL11.glEnable(2929);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearModUpdates() {
/* 199 */     this.shouldRender = false;
/* 200 */     ModVersionChecker.clearListOfNonSidedMods(this.modUpdates);
/* 201 */     ModVersionChecker.clearListOfNonSidedMods(this.modUpdatesPending);
/* 202 */     this.modUpdatesDone.clear();
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\gui\GuiModUpdateNotification.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */