/*      */ package ichun.client.gui.config;
/*      */ import cpw.mods.fml.relauncher.Side;
/*      */ import ichun.client.keybind.KeyBind;
/*      */ import ichun.client.render.RendererHelper;
/*      */ import ichun.common.core.config.Config;
/*      */ import ichun.common.iChunUtil;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.client.gui.Gui;
/*      */ import net.minecraft.client.gui.GuiScreen;
/*      */ import net.minecraft.client.gui.GuiSlot;
/*      */ import net.minecraft.client.gui.GuiTextField;
/*      */ import net.minecraft.client.renderer.Tessellator;
/*      */ import net.minecraft.client.settings.GameSettings;
/*      */ import net.minecraft.util.EnumChatFormatting;
/*      */ import net.minecraft.util.ResourceLocation;
/*      */ import net.minecraft.util.StatCollector;
/*      */ import net.minecraftforge.common.config.Property;
/*      */ import org.lwjgl.input.Keyboard;
/*      */ import org.lwjgl.input.Mouse;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ 
/*      */ public class GuiConfigSetterScroll extends GuiSlot {
/*   29 */   protected static final ResourceLocation WIDGITS = new ResourceLocation("textures/gui/widgets.png");
/*      */   private GuiConfigSetter controls;
/*      */   private Minecraft mc;
/*      */   private Config config;
/*      */   private ArrayList<Property> properties;
/*      */   private ArrayList<String> propNames;
/*      */   private String[] message;
/*      */   private int _mouseX;
/*      */   private int _mouseY;
/*   38 */   private int selected = -1;
/*   39 */   private int selectedIntArrayProp = -1;
/*   40 */   private int intArraySlots = 0;
/*      */   
/*      */   private String selectedText;
/*      */   
/*      */   public byte blinker;
/*      */   public GuiTextField textDummy;
/*      */   private boolean needRestart;
/*      */   private boolean settingKeybind;
/*      */   private boolean releasedMouse;
/*      */   private int lastKeyHeld;
/*      */   private int keyHeldTime;
/*   51 */   private ArrayList<Integer> intArrayList = new ArrayList<Integer>();
/*   52 */   private LinkedHashMap<Integer, ArrayList<Integer>> nestedIntArrayList = new LinkedHashMap<Integer, ArrayList<Integer>>();
/*      */ 
/*      */   
/*      */   public GuiConfigSetterScroll(GuiConfigSetter guiConfigSetter, Config cfg, ArrayList<Property> props, Minecraft mc) {
/*   56 */     super(mc, guiConfigSetter.field_146294_l, guiConfigSetter.field_146295_m, 16, guiConfigSetter.field_146295_m - 32 + 4, 25);
/*   57 */     this.field_148152_e = -10;
/*   58 */     this.controls = guiConfigSetter;
/*   59 */     this.mc = mc;
/*   60 */     this.config = cfg;
/*   61 */     this.properties = props;
/*   62 */     this.blinker = 0;
/*   63 */     this.selectedText = "";
/*   64 */     this.textDummy = new GuiTextField((Minecraft.func_71410_x()).field_71466_p, 3, 6, 45, 20);
/*   65 */     this.textDummy.func_146185_a(false);
/*   66 */     this.textDummy.func_146203_f(80);
/*      */     
/*   68 */     this.propNames = new ArrayList<String>();
/*      */     
/*   70 */     for (Property p : this.properties)
/*      */     {
/*   72 */       this.propNames.add((String)this.config.propName.get(p));
/*      */     }
/*   74 */     Collections.sort(this.propNames);
/*      */     
/*   76 */     this.needRestart = false;
/*   77 */     this.settingKeybind = false;
/*   78 */     this.releasedMouse = false;
/*      */     
/*   80 */     this.lastKeyHeld = 0;
/*   81 */     this.keyHeldTime = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int func_148127_b() {
/*   87 */     return (this.selectedIntArrayProp != -1) ? (this.properties.size() + this.intArraySlots) : this.properties.size();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int func_148139_c() {
/*   93 */     return 200;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void func_148144_a(int i, boolean flag, int mouseX, int mouseY) {
/*   99 */     if (this.settingKeybind) {
/*      */       return;
/*      */     }
/*      */     
/*  103 */     if (!flag) {
/*      */       
/*  105 */       if (this.selected != -1) {
/*      */         Property prop;
/*  107 */         boolean selectedIntArraySlot = (this.selectedIntArrayProp != -1 && this.selected > this.selectedIntArrayProp && this.selected <= this.selectedIntArrayProp + this.intArraySlots);
/*      */         
/*  109 */         if (selectedIntArraySlot) {
/*      */           
/*  111 */           prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get(this.selectedIntArrayProp)));
/*      */         }
/*      */         else {
/*      */           
/*  115 */           prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get((this.selectedIntArrayProp != -1 && this.selected > this.selectedIntArrayProp) ? (this.selected - this.intArraySlots) : this.selected)));
/*      */         } 
/*      */         
/*  118 */         if (isValidValue(prop, this.selectedText))
/*      */         {
/*  120 */           updateProperty(prop, this.selectedText);
/*      */         }
/*      */       } 
/*      */       
/*  124 */       this.selected = i;
/*      */       
/*  126 */       boolean isIntArraySlot = (this.selectedIntArrayProp != -1 && i > this.selectedIntArrayProp && i <= this.selectedIntArrayProp + this.intArraySlots);
/*      */       
/*  128 */       if (isIntArraySlot) {
/*      */         
/*  130 */         this.selectedText = "";
/*      */       }
/*      */       else {
/*      */         
/*  134 */         this.intArrayList.clear();
/*  135 */         this.nestedIntArrayList.clear();
/*      */         
/*  137 */         Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get((this.selectedIntArrayProp != -1 && i > this.selectedIntArrayProp) ? (i - this.intArraySlots) : i)));
/*  138 */         Config.EnumPropType type = this.config.getPropType(prop);
/*  139 */         if (type == Config.EnumPropType.INT_ARRAY || type == Config.EnumPropType.NESTED_INT_ARRAY) {
/*      */           
/*  141 */           if (((this.selectedIntArrayProp != -1 && i > this.selectedIntArrayProp) ? (i - this.intArraySlots) : i) > this.selectedIntArrayProp) {
/*      */             
/*  143 */             this.selected = this.selectedIntArrayProp = i - this.intArraySlots;
/*      */           }
/*      */           else {
/*      */             
/*  147 */             this.selected = this.selectedIntArrayProp = i;
/*      */           } 
/*      */           
/*  150 */           String value = prop.getString();
/*      */           
/*  152 */           if (type == Config.EnumPropType.NESTED_INT_ARRAY)
/*      */           {
/*  154 */             this.nestedIntArrayList = this.config.parseNestedIntArray(value);
/*  155 */             this.intArraySlots = this.nestedIntArrayList.size() + 1;
/*      */           }
/*      */           else
/*      */           {
/*  159 */             this.intArrayList = this.config.parseIntArray(value);
/*  160 */             this.intArraySlots = 1;
/*      */           }
/*      */         
/*  163 */         } else if (type == Config.EnumPropType.INT_BOOL) {
/*      */           
/*  165 */           prop.set((prop.getInt() == 1) ? 0 : 1);
/*  166 */           updateProperty(prop, prop.getString());
/*      */           
/*  168 */           this.selected = -1;
/*      */         }
/*      */         else {
/*      */           
/*  172 */           if (type == Config.EnumPropType.KEYBIND) {
/*      */             
/*  174 */             this.settingKeybind = true;
/*  175 */             this.releasedMouse = false;
/*  176 */             this.keyHeldTime = 0;
/*      */           } 
/*      */           
/*  179 */           this.selected = (this.selectedIntArrayProp != -1 && i > this.selectedIntArrayProp) ? (i - this.intArraySlots) : i;
/*  180 */           this.intArraySlots = 0;
/*  181 */           this.selectedIntArrayProp = -1;
/*  182 */           this.selectedText = (prop.getType() == Property.Type.INTEGER) ? Integer.toString(prop.getInt()) : prop.getString();
/*      */         } 
/*      */       } 
/*  185 */       this.textDummy.func_146180_a(this.selectedText);
/*  186 */       this.textDummy.func_146202_e();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isValidValue(Property prop, String s) {
/*  192 */     switch (this.config.getPropType(prop)) {
/*      */       
/*      */       case COLOUR:
/*      */         
/*      */         try {
/*      */           
/*  198 */           Integer.decode(s);
/*  199 */           return (s.length() < 8);
/*      */         }
/*  201 */         catch (NumberFormatException e) {
/*      */           
/*  203 */           return false;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       case INT_BOOL:
/*      */       case INT:
/*      */         try {
/*  211 */           int i = Integer.parseInt(s);
/*  212 */           int[] minmax = (int[])this.config.minmax.get(prop);
/*  213 */           if (i < minmax[0] || i > minmax[1])
/*      */           {
/*  215 */             return false;
/*      */           }
/*  217 */           return true;
/*      */         }
/*  219 */         catch (NumberFormatException e) {
/*      */           
/*  221 */           return false;
/*      */         } 
/*      */ 
/*      */       
/*      */       case KEYBIND:
/*      */       case STRING:
/*  227 */         return true;
/*      */ 
/*      */ 
/*      */       
/*      */       case INT_ARRAY:
/*      */         try {
/*  233 */           int i = Integer.parseInt(s);
/*  234 */           int[] minmax = (int[])this.config.minmax.get(prop);
/*  235 */           if (i < minmax[0] || i > minmax[1])
/*      */           {
/*  237 */             return false;
/*      */           }
/*  239 */           if (this.intArrayList.contains(Integer.valueOf(Integer.parseInt(s))))
/*      */           {
/*  241 */             return false;
/*      */           }
/*  243 */           return true;
/*      */         }
/*  245 */         catch (NumberFormatException e) {
/*      */           
/*  247 */           return false;
/*      */         } 
/*      */ 
/*      */       
/*      */       case NESTED_INT_ARRAY:
/*  252 */         if (this.selected == this.selectedIntArrayProp + this.intArraySlots) {
/*      */           
/*      */           try {
/*      */             
/*  256 */             int i = Integer.parseInt(s);
/*  257 */             int[] minmax = (int[])this.config.minmax.get(prop);
/*  258 */             if (i < minmax[0] || i > minmax[1])
/*      */             {
/*  260 */               return false;
/*      */             }
/*  262 */             if (this.nestedIntArrayList.containsKey(Integer.valueOf(Integer.parseInt(s))))
/*      */             {
/*  264 */               return false;
/*      */             }
/*  266 */             return true;
/*      */           }
/*  268 */           catch (NumberFormatException e) {
/*      */             
/*  270 */             return false;
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  277 */           int i = Integer.parseInt(s);
/*  278 */           int[] minmax = (int[])this.config.nestedMinmax.get(prop);
/*  279 */           if (i < minmax[0] || i > minmax[1])
/*      */           {
/*  281 */             return false;
/*      */           }
/*      */           
/*  284 */           int m = 0;
/*  285 */           Iterator<Map.Entry<Integer, ArrayList<Integer>>> ite = this.nestedIntArrayList.entrySet().iterator();
/*  286 */           while (ite.hasNext()) {
/*      */             
/*  288 */             Map.Entry<Integer, ArrayList<Integer>> e = ite.next();
/*  289 */             m++;
/*  290 */             if (this.selected - this.selectedIntArrayProp == m) {
/*      */               
/*  292 */               if (((ArrayList)e.getValue()).contains(Integer.valueOf(Integer.parseInt(s))))
/*      */               {
/*  294 */                 return false;
/*      */               }
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*  300 */           return true;
/*      */         }
/*  302 */         catch (NumberFormatException e) {
/*      */           
/*  304 */           return false;
/*      */         } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  310 */     return false;
/*      */   } public boolean updateProperty(Property prop, String s) {
/*      */     StringBuilder sb;
/*      */     KeyBind oriKeyBind;
/*      */     int i;
/*      */     String keyString, strings[];
/*      */     KeyBind bind;
/*  317 */     String _default = prop.getString();
/*      */     
/*  319 */     switch (this.config.getPropType(prop)) {
/*      */       
/*      */       case INT_BOOL:
/*      */       case INT:
/*      */         
/*      */         try {
/*      */           
/*  326 */           int j = Integer.parseInt(s);
/*      */           
/*  328 */           int[] minmax = (int[])this.config.minmax.get(prop);
/*  329 */           if (j < minmax[0] || j > minmax[1])
/*      */           {
/*  331 */             return false;
/*      */           }
/*      */           
/*  334 */           prop.set(j);
/*      */           
/*  336 */           Object object = null;
/*      */           
/*  338 */           if (this.config.sessionProps.contains(prop)) {
/*      */             
/*  340 */             object = ((HashMap)this.config.sessionState.get(Side.SERVER)).get(prop.getName());
/*  341 */             ((HashMap<String, Integer>)this.config.sessionState.get(Side.SERVER)).put(prop.getName(), Integer.valueOf(j));
/*  342 */             System.out.println(prop.getName());
/*      */           } 
/*      */           
/*  345 */           if (this.config.parent.onConfigChange(this.config, prop)) {
/*      */             
/*  347 */             this.config.save();
/*      */             
/*  349 */             if (this.config.propNeedsRestart.contains(prop))
/*      */             {
/*  351 */               this.needRestart = true;
/*      */             }
/*      */           }
/*      */           else {
/*      */             
/*  356 */             prop.set(_default);
/*      */             
/*  358 */             if (object != null)
/*      */             {
/*  360 */               ((HashMap<String, Object>)this.config.sessionState.get(Side.SERVER)).put(prop.getName(), object);
/*      */             }
/*  362 */             return false;
/*      */           } 
/*  364 */           return true;
/*      */         }
/*  366 */         catch (NumberFormatException e) {
/*      */           
/*  368 */           return false;
/*      */         } 
/*      */ 
/*      */       
/*      */       case INT_ARRAY:
/*  373 */         sb = new StringBuilder();
/*      */         
/*  375 */         for (i = 0; i < this.intArrayList.size(); i++) {
/*      */           
/*  377 */           sb.append(this.intArrayList.get(i));
/*  378 */           if (i < this.intArrayList.size() - 1)
/*      */           {
/*  380 */             sb.append(", ");
/*      */           }
/*      */         } 
/*  383 */         prop.set(sb.toString());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case NESTED_INT_ARRAY:
/*  389 */         sb = new StringBuilder();
/*  390 */         i = 0;
/*  391 */         for (Map.Entry<Integer, ArrayList<Integer>> e : this.nestedIntArrayList.entrySet()) {
/*      */           
/*  393 */           sb.append(e.getKey());
/*  394 */           for (int m = 0; m < ((ArrayList)e.getValue()).size(); m++) {
/*      */             
/*  396 */             if (m == 0)
/*      */             {
/*  398 */               sb.append(": ");
/*      */             }
/*  400 */             sb.append(((ArrayList)e.getValue()).get(m));
/*  401 */             if (m < ((ArrayList)e.getValue()).size() - 1)
/*      */             {
/*  403 */               sb.append(": ");
/*      */             }
/*      */           } 
/*  406 */           if (i < this.nestedIntArrayList.size() - 1 || (((ArrayList)e.getValue()).isEmpty() && i < this.nestedIntArrayList.size() - 1))
/*      */           {
/*  408 */             sb.append(", ");
/*      */           }
/*  410 */           i++;
/*      */         } 
/*  412 */         prop.set(sb.toString());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case KEYBIND:
/*  418 */         oriKeyBind = (KeyBind)this.config.keyBindMap.get(prop);
/*      */         
/*  420 */         keyString = s;
/*  421 */         strings = keyString.split(":");
/*      */ 
/*      */         
/*      */         try {
/*  425 */           bind = new KeyBind(Integer.parseInt(strings[0].trim()), keyString.contains("SHIFT"), keyString.contains("CTRL"), keyString.contains("ALT"), false);
/*      */         }
/*  427 */         catch (Exception e) {
/*      */           
/*  429 */           iChunUtil.console("Error parsing key, this shouldn't happen: " + keyString, true);
/*  430 */           e.printStackTrace();
/*  431 */           bind = oriKeyBind;
/*      */         } 
/*      */         
/*  434 */         this.config.keyBindMap.put(prop.getName(), iChunUtil.proxy.registerKeyBind(bind, oriKeyBind));
/*      */         
/*  436 */         prop.set(s);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case COLOUR:
/*      */       case STRING:
/*  443 */         prop.set(s);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  449 */         return false;
/*      */     } 
/*      */ 
/*      */     
/*  453 */     Object def = null;
/*      */     
/*  455 */     if (this.config.sessionProps.contains(prop)) {
/*      */       
/*  457 */       def = ((HashMap)this.config.sessionState.get(Side.SERVER)).get(prop.getName());
/*  458 */       ((HashMap<String, String>)this.config.sessionState.get(Side.SERVER)).put(prop.getName(), prop.getString());
/*      */     } 
/*      */     
/*  461 */     if (this.config.parent.onConfigChange(this.config, prop)) {
/*      */       
/*  463 */       if (this.config.getPropType(prop).equals(Config.EnumPropType.KEYBIND)) {
/*      */         
/*  465 */         Config.configKeybind.save();
/*      */       }
/*      */       else {
/*      */         
/*  469 */         this.config.save();
/*      */       } 
/*      */       
/*  472 */       if (this.config.propNeedsRestart.contains(prop))
/*      */       {
/*  474 */         this.needRestart = true;
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  479 */       prop.set(_default);
/*      */       
/*  481 */       if (def != null)
/*      */       {
/*  483 */         ((HashMap<String, Object>)this.config.sessionState.get(Side.SERVER)).put(prop.getName(), def);
/*      */       }
/*  485 */       return false;
/*      */     } 
/*  487 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean func_148131_a(int i) {
/*  493 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void func_148123_a() {}
/*      */ 
/*      */   
/*      */   private void overlayBackground(int p_148136_1_, int p_148136_2_, int p_148136_3_, int p_148136_4_) {
/*  501 */     Tessellator tessellator = Tessellator.field_78398_a;
/*  502 */     this.mc.func_110434_K().func_110577_a(Gui.field_110325_k);
/*  503 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  504 */     float f = 32.0F;
/*  505 */     tessellator.func_78382_b();
/*  506 */     tessellator.func_78384_a(4210752, p_148136_4_);
/*  507 */     tessellator.func_78374_a(this.field_148152_e, p_148136_2_, 0.0D, 0.0D, (p_148136_2_ / f));
/*  508 */     tessellator.func_78374_a((this.field_148152_e + this.field_148155_a), p_148136_2_, 0.0D, (this.field_148155_a / f), (p_148136_2_ / f));
/*  509 */     tessellator.func_78384_a(4210752, p_148136_3_);
/*  510 */     tessellator.func_78374_a((this.field_148152_e + this.field_148155_a), p_148136_1_, 0.0D, (this.field_148155_a / f), (p_148136_1_ / f));
/*  511 */     tessellator.func_78374_a(this.field_148152_e, p_148136_1_, 0.0D, 0.0D, (p_148136_1_ / f));
/*  512 */     tessellator.func_78381_a();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void func_148128_a(int mX, int mY, float f) {
/*  518 */     this._mouseX = mX;
/*  519 */     this._mouseY = mY;
/*      */     
/*  521 */     super.func_148128_a(mX, mY, f);
/*      */     
/*  523 */     GL11.glTranslatef(10.0F, 0.0F, 0.0F);
/*  524 */     overlayBackground(0, this.field_148153_b, 255, 255);
/*  525 */     overlayBackground(this.field_148154_c, this.controls.field_146295_m, 255, 255);
/*  526 */     GL11.glTranslatef(-10.0F, 0.0F, 0.0F);
/*      */     
/*  528 */     if (this.settingKeybind)
/*      */     {
/*  530 */       if (!this.releasedMouse) {
/*      */         
/*  532 */         this.releasedMouse = !Mouse.isButtonDown(0);
/*      */       }
/*      */       else {
/*      */         
/*  536 */         for (int i = 0; i < 16; i++) {
/*      */           
/*  538 */           if (Mouse.isButtonDown(i)) {
/*      */             
/*  540 */             if (Minecraft.field_142025_a && i == 0 && (Keyboard.isKeyDown(29) || Keyboard.isKeyDown(157)))
/*      */             {
/*  542 */               i = 1;
/*      */             }
/*      */             
/*  545 */             Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get(this.selected)));
/*  546 */             if (this.config.getPropType(prop) == Config.EnumPropType.KEYBIND) {
/*      */               
/*  548 */               StringBuilder sb = new StringBuilder();
/*      */               
/*  550 */               sb.append(i - 100);
/*      */               
/*  552 */               if (GuiScreen.func_146272_n())
/*      */               {
/*  554 */                 sb.append(":SHIFT");
/*      */               }
/*  556 */               if (GuiScreen.func_146271_m())
/*      */               {
/*  558 */                 sb.append(":CTRL");
/*      */               }
/*  560 */               if (Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184))
/*      */               {
/*  562 */                 sb.append(":ALT");
/*      */               }
/*      */               
/*  565 */               updateProperty(prop, sb.toString());
/*      */               
/*  567 */               this.settingKeybind = false;
/*  568 */               this.selected = -1;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int func_148137_d() {
/*  581 */     return this.controls.field_146294_l / 2 + 102;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void func_148126_a(int index, int xPosition, int yPosition, int l, Tessellator tessellator, int mouseX, int mouseY) {
/*  587 */     if (index >= func_148127_b()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  592 */     String textDummyString = this.textDummy.func_146179_b();
/*  593 */     int textDummyCursorPosition = this.textDummy.func_146198_h();
/*      */     
/*  595 */     int width = 200;
/*  596 */     int height = 20;
/*  597 */     xPosition += 8;
/*  598 */     boolean flag = (this._mouseX >= xPosition && this._mouseY >= yPosition && this._mouseX < xPosition + width && this._mouseY < yPosition + height);
/*  599 */     int k = flag ? 2 : 1;
/*      */     
/*  601 */     this.mc.field_71446_o.func_110577_a(WIDGITS);
/*  602 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */     
/*  604 */     boolean isIntArraySlot = (this.selectedIntArrayProp != -1 && index > this.selectedIntArrayProp && index <= this.selectedIntArrayProp + this.intArraySlots);
/*  605 */     if (isIntArraySlot) {
/*      */ 
/*      */       
/*  608 */       Gui.func_73734_a(xPosition + width - 45, yPosition, xPosition + width - 5, yPosition + height, -6250336);
/*  609 */       Gui.func_73734_a(xPosition + width - 45 + 1, yPosition + 1, xPosition + width - 5 - 1, yPosition + height - 1, -16777216);
/*      */       
/*  611 */       Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get(this.selectedIntArrayProp)));
/*      */       
/*  613 */       StringBuilder sb = new StringBuilder("> ");
/*  614 */       if (this.config.getPropType(prop) == Config.EnumPropType.INT_ARRAY) {
/*      */         
/*  616 */         for (int i = 0; i < this.intArrayList.size(); i++)
/*      */         {
/*  618 */           sb.append(this.intArrayList.get(i));
/*  619 */           if (i < this.intArrayList.size() - 1)
/*      */           {
/*  621 */             sb.append(", ");
/*      */           }
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  627 */         int i = 0;
/*  628 */         for (Map.Entry<Integer, ArrayList<Integer>> e : this.nestedIntArrayList.entrySet()) {
/*      */           
/*  630 */           i++;
/*  631 */           if (index - this.selectedIntArrayProp == i) {
/*      */             
/*  633 */             sb.append(e.getKey());
/*  634 */             for (int m = 0; m < ((ArrayList)e.getValue()).size(); m++) {
/*      */               
/*  636 */               if (m == 0)
/*      */               {
/*  638 */                 sb.append(": ");
/*      */               }
/*  640 */               sb.append(((ArrayList)e.getValue()).get(m));
/*  641 */               if (m < ((ArrayList)e.getValue()).size() - 1)
/*      */               {
/*  643 */                 sb.append(": ");
/*      */               }
/*      */             } 
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*  650 */       this.controls.func_73731_b(this.mc.field_71466_p, sb.toString(), xPosition + 5, yPosition + (height - 8) / 2, (k == 2) ? 14737632 : -6250336);
/*      */       
/*  652 */       if (this.selected == index) {
/*      */         
/*  654 */         String value = this.selectedText + ((this.blinker > 8) ? "_" : "");
/*      */         
/*  656 */         this.textDummy.func_146184_c(true);
/*  657 */         this.textDummy.func_146180_a(value);
/*  658 */         if (this.selected == index) {
/*      */           
/*  660 */           if (this.selectedText.equals("") || isValidValue(prop, this.selectedText))
/*      */           {
/*  662 */             this.textDummy.func_146193_g(16777045);
/*      */           }
/*      */           else
/*      */           {
/*  666 */             this.textDummy.func_146193_g(16733525);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  671 */           this.textDummy.func_146193_g(16777215);
/*  672 */           this.textDummy.func_146190_e(0);
/*      */         } 
/*      */         
/*  675 */         GL11.glPushMatrix();
/*  676 */         GL11.glTranslatef((xPosition + width - 45), yPosition, 0.0F);
/*  677 */         this.textDummy.func_146194_f();
/*      */         
/*  679 */         this.textDummy.func_146184_c(false);
/*      */         
/*  681 */         GL11.glPopMatrix();
/*      */       } 
/*      */     } else {
/*      */       int clr; String value, keyString;
/*      */       int kk;
/*      */       String[] strings;
/*      */       int key;
/*  688 */       Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get((this.selectedIntArrayProp != -1 && index > this.selectedIntArrayProp) ? (index - this.intArraySlots) : index)));
/*      */       
/*  690 */       switch (this.config.getPropType(prop)) {
/*      */ 
/*      */         
/*      */         case KEYBIND:
/*  694 */           clr = 14737632;
/*      */           
/*  696 */           if (k == 2) {
/*      */             
/*  698 */             clr = 16777120;
/*      */             
/*  700 */             ArrayList<String> tooltip = new ArrayList<String>();
/*  701 */             tooltip.add(StatCollector.func_74838_a("ichun.config.keybind.tip1"));
/*  702 */             tooltip.add("");
/*  703 */             tooltip.add(StatCollector.func_74838_a("ichun.config.keybind.tip2"));
/*  704 */             tooltip.add("");
/*  705 */             tooltip.add(StatCollector.func_74838_a("ichun.config.keybind.tip3"));
/*  706 */             this.controls.drawTooltip(tooltip, 0, 35);
/*      */             
/*  708 */             this.mc.field_71446_o.func_110577_a(WIDGITS);
/*      */           } 
/*      */           
/*  711 */           this.controls.func_73729_b(xPosition + width - 70, yPosition, 0, 46 + k * 20, 35, height);
/*  712 */           this.controls.func_73729_b(xPosition + width - 35, yPosition, 165, 46 + k * 20, 35, height);
/*      */           
/*  714 */           keyString = prop.getString();
/*  715 */           strings = keyString.split(":");
/*      */           
/*  717 */           key = 0;
/*  718 */           if (strings.length > 0)
/*      */           {
/*  720 */             key = Integer.parseInt(strings[0].trim());
/*      */           }
/*      */           
/*  723 */           this.controls.func_73732_a(this.mc.field_71466_p, (this.settingKeybind && this.selected == index) ? ">???<" : GameSettings.func_74298_c(key), xPosition + width - 35, yPosition + (height - 8) / 2, (this.selected == index) ? 16777045 : clr);
/*      */           
/*  725 */           GL11.glPushMatrix();
/*      */           
/*  727 */           GL11.glScalef(0.5F, 0.5F, 0.5F);
/*  728 */           if (keyString.contains("SHIFT") || (this.settingKeybind && this.selected == index)) {
/*      */             
/*  730 */             this.controls.func_73731_b(this.mc.field_71466_p, "Shift", (xPosition + width - 70) * 2 - 6 - 18, (yPosition + (height - 8) / 2) * 2 - 10, (this.settingKeybind && this.selected == index) ? (GuiScreen.func_146272_n() ? 16777045 : -6250336) : clr);
/*  731 */             GL11.glTranslatef(0.0F, 14.0F, 0.0F);
/*      */           } 
/*      */           
/*  734 */           if (keyString.contains("CTRL") || (this.settingKeybind && this.selected == index)) {
/*      */             
/*  736 */             this.controls.func_73731_b(this.mc.field_71466_p, "Ctrl", (xPosition + width - 70) * 2 - 6 - 14, (yPosition + (height - 8) / 2) * 2 - 10, (this.settingKeybind && this.selected == index) ? (GuiScreen.func_146271_m() ? 16777045 : -6250336) : clr);
/*  737 */             GL11.glTranslatef(0.0F, 14.0F, 0.0F);
/*      */           } 
/*      */           
/*  740 */           if (keyString.contains("ALT") || (this.settingKeybind && this.selected == index))
/*      */           {
/*  742 */             this.controls.func_73731_b(this.mc.field_71466_p, "Alt", (xPosition + width - 70) * 2 - 6 - 8, (yPosition + (height - 8) / 2) * 2 - 10, (this.settingKeybind && this.selected == index) ? ((Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184)) ? 16777045 : -6250336) : clr);
/*      */           }
/*      */           
/*  745 */           GL11.glPopMatrix();
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case INT_ARRAY:
/*      */         case NESTED_INT_ARRAY:
/*  752 */           clr = 14737632;
/*      */           
/*  754 */           kk = k;
/*      */           
/*  756 */           if (this.selectedIntArrayProp == index) {
/*      */             
/*  758 */             clr = -6250336;
/*  759 */             kk = 0;
/*      */           }
/*  761 */           else if (k == 2) {
/*      */             
/*  763 */             clr = 16777120;
/*      */           } 
/*      */           
/*  766 */           this.controls.func_73729_b(xPosition + width - 50, yPosition, 0, 46 + kk * 20, 25, height);
/*  767 */           this.controls.func_73729_b(xPosition + width - 25, yPosition, 175, 46 + kk * 20, 25, height);
/*      */           
/*  769 */           this.controls.func_73732_a(this.mc.field_71466_p, (this.selectedIntArrayProp == index) ? "v" : ">>", xPosition + width - 25, yPosition + (height - 8) / 2, clr);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case INT_BOOL:
/*  775 */           clr = 14737632;
/*      */ 
/*      */           
/*  778 */           if (k == 2)
/*      */           {
/*  780 */             clr = 16777120;
/*      */           }
/*      */           
/*  783 */           this.controls.func_73729_b(xPosition + width - 50, yPosition, 0, 46 + k * 20, 25, height);
/*  784 */           this.controls.func_73729_b(xPosition + width - 25, yPosition, 175, 46 + k * 20, 25, height);
/*      */           
/*  786 */           this.controls.func_73732_a(this.mc.field_71466_p, (prop.getInt() == 1) ? "Yes" : "No", xPosition + width - 25, yPosition + (height - 8) / 2, clr);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/*  793 */           if (this.config.getPropType(prop) == Config.EnumPropType.COLOUR) {
/*      */             
/*  795 */             RendererHelper.drawColourOnScreen(((this.selected == index && isValidValue(prop, this.selectedText)) ? Integer.decode(this.selectedText) : Integer.decode(prop.getString())).intValue(), 255, (xPosition + width - 50), yPosition, 50.0D, height, 0.0D);
/*      */           }
/*      */           else {
/*      */             
/*  799 */             Gui.func_73734_a(xPosition + width - 50, yPosition, xPosition + width, yPosition + height, -6250336);
/*      */           } 
/*  801 */           Gui.func_73734_a(xPosition + width - 50 + 1, yPosition + 1, xPosition + width - 1, yPosition + height - 1, -16777216);
/*      */           
/*  803 */           value = ((this.selected == index) ? this.selectedText : ((prop.getType() == Property.Type.INTEGER) ? Integer.toString(prop.getInt()) : prop.getString())) + ((this.selected == index && this.blinker > 8) ? "_" : " ");
/*      */ 
/*      */           
/*  806 */           this.textDummy.func_146184_c(true);
/*  807 */           this.textDummy.func_146180_a(value);
/*  808 */           if (this.selected == index) {
/*      */             
/*  810 */             if (isValidValue(prop, this.selectedText))
/*      */             {
/*  812 */               this.textDummy.func_146193_g(16777045);
/*      */             }
/*      */             else
/*      */             {
/*  816 */               this.textDummy.func_146193_g(16733525);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  821 */             this.textDummy.func_146193_g(16777215);
/*  822 */             this.textDummy.func_146190_e(0);
/*      */           } 
/*      */           
/*  825 */           GL11.glPushMatrix();
/*  826 */           GL11.glTranslatef((xPosition + width - 50), yPosition, 0.0F);
/*  827 */           this.textDummy.func_146194_f();
/*      */           
/*  829 */           this.textDummy.func_146184_c(false);
/*      */           
/*  831 */           GL11.glPopMatrix();
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  838 */       String str = ((k == 2) ? (String)EnumChatFormatting.YELLOW : "") + StatCollector.func_74838_a(this.propNames.get((this.selectedIntArrayProp != -1 && index > this.selectedIntArrayProp) ? (index - this.intArraySlots) : index));
/*  839 */       this.controls.func_73731_b(this.mc.field_71466_p, str, xPosition, yPosition + (height - 8) / 2, -1);
/*      */       
/*  841 */       if (k == 2 && prop.comment != null) {
/*      */         
/*  843 */         ArrayList<String> tooltip = new ArrayList<String>();
/*  844 */         String[] comments = prop.comment.split("\n");
/*  845 */         for (int i = 0; i < comments.length; i++) {
/*      */           
/*  847 */           if (this.config.getPropType(prop) != Config.EnumPropType.INT_BOOL || i <= comments.length - 4)
/*      */           {
/*      */ 
/*      */             
/*  851 */             tooltip.add(comments[i]); } 
/*      */         } 
/*  853 */         this.controls.drawTooltip(tooltip, xPosition + width, 35);
/*      */       } 
/*      */     } 
/*      */     
/*  857 */     this.textDummy.func_146180_a(textDummyString);
/*  858 */     this.textDummy.func_146190_e(textDummyCursorPosition);
/*      */     
/*  860 */     if (this.needRestart) {
/*      */       
/*  862 */       this.controls.func_73731_b(this.mc.field_71466_p, EnumChatFormatting.RED + "Some changes", 4, height, -1);
/*  863 */       this.controls.func_73731_b(this.mc.field_71466_p, EnumChatFormatting.RED + "require a client", 4, height + 12, -1);
/*  864 */       this.controls.func_73731_b(this.mc.field_71466_p, EnumChatFormatting.RED + "restart.", 4, height + 26, -1);
/*  865 */       this.controls.func_73731_b(this.mc.field_71466_p, EnumChatFormatting.RED + "Some changes", 4, height + 54, -1);
/*  866 */       this.controls.func_73731_b(this.mc.field_71466_p, EnumChatFormatting.RED + "may not take", 4, height + 68, -1);
/*  867 */       this.controls.func_73731_b(this.mc.field_71466_p, EnumChatFormatting.RED + "effect if they", 4, height + 82, -1);
/*  868 */       this.controls.func_73731_b(this.mc.field_71466_p, EnumChatFormatting.RED + "are serverside", 4, height + 96, -1);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean keyTyped(char c, int i) {
/*  874 */     if (this.settingKeybind) {
/*      */       
/*  876 */       Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get(this.selected)));
/*  877 */       if (this.config.getPropType(prop) == Config.EnumPropType.KEYBIND)
/*      */       {
/*  879 */         if (i == 42 || i == 54 || (Minecraft.field_142025_a ? (i == 219 || i == 220) : (i == 29 || i == 157)) || i == 56 || i == 184) {
/*      */           
/*  881 */           this.lastKeyHeld = i;
/*  882 */           this.keyHeldTime = 0;
/*      */         }
/*      */         else {
/*      */           
/*  886 */           StringBuilder sb = new StringBuilder();
/*      */           
/*  888 */           sb.append(i);
/*      */           
/*  890 */           if (GuiScreen.func_146272_n())
/*      */           {
/*  892 */             sb.append(":SHIFT");
/*      */           }
/*  894 */           if (GuiScreen.func_146271_m())
/*      */           {
/*  896 */             sb.append(":CTRL");
/*      */           }
/*  898 */           if (Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184))
/*      */           {
/*  900 */             sb.append(":ALT");
/*      */           }
/*      */           
/*  903 */           updateProperty(prop, sb.toString());
/*      */           
/*  905 */           this.settingKeybind = false;
/*  906 */           this.selected = -1;
/*      */         } 
/*      */       }
/*  909 */       return true;
/*      */     } 
/*  911 */     if (this.selected != -1)
/*      */     {
/*  913 */       if (i == 28) {
/*      */         
/*  915 */         boolean isIntArraySlot = (this.selectedIntArrayProp != -1 && this.selected > this.selectedIntArrayProp && this.selected <= this.selectedIntArrayProp + this.intArraySlots);
/*      */         
/*  917 */         if (isIntArraySlot) {
/*      */           
/*  919 */           Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get(this.selectedIntArrayProp)));
/*  920 */           if (isValidValue(prop, this.selectedText))
/*      */           {
/*  922 */             if (this.config.getPropType(prop) == Config.EnumPropType.INT_ARRAY) {
/*      */               
/*  924 */               this.intArrayList.add(Integer.valueOf(Integer.parseInt(this.selectedText)));
/*      */ 
/*      */             
/*      */             }
/*  928 */             else if (this.selected == this.selectedIntArrayProp + this.intArraySlots) {
/*      */               
/*  930 */               this.nestedIntArrayList.put(Integer.valueOf(Integer.parseInt(this.selectedText)), new ArrayList<Integer>());
/*  931 */               this.intArraySlots++;
/*      */             }
/*      */             else {
/*      */               
/*  935 */               int m = 0;
/*  936 */               Iterator<Map.Entry<Integer, ArrayList<Integer>>> ite = this.nestedIntArrayList.entrySet().iterator();
/*  937 */               while (ite.hasNext()) {
/*      */                 
/*  939 */                 Map.Entry<Integer, ArrayList<Integer>> e = ite.next();
/*  940 */                 m++;
/*  941 */                 if (this.selected - this.selectedIntArrayProp == m) {
/*      */                   
/*  943 */                   ((ArrayList<Integer>)e.getValue()).add(Integer.valueOf(Integer.parseInt(this.selectedText)));
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } 
/*  949 */             this.textDummy.func_146180_a("");
/*  950 */             this.textDummy.func_146202_e();
/*  951 */             this.textDummy.func_146184_c(true);
/*  952 */             this.textDummy.func_146195_b(true);
/*  953 */             this.textDummy.func_146201_a(c, i);
/*  954 */             this.textDummy.func_146184_c(false);
/*  955 */             this.textDummy.func_146195_b(false);
/*  956 */             this.textDummy.func_146202_e();
/*  957 */             this.selectedText = this.textDummy.func_146179_b();
/*      */             
/*  959 */             updateProperty(prop, this.selectedText);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  964 */           Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get(this.selected)));
/*  965 */           if (isValidValue(prop, this.selectedText))
/*      */           {
/*  967 */             updateProperty(prop, this.selectedText);
/*      */           }
/*  969 */           this.selected = -1;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  974 */         if (this.selectedIntArrayProp != -1 && this.selectedText.equalsIgnoreCase("") && i == 14) {
/*      */           
/*  976 */           Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get(this.selectedIntArrayProp)));
/*  977 */           if (this.config.getPropType(prop) == Config.EnumPropType.INT_ARRAY) {
/*      */             
/*  979 */             if (this.intArrayList.size() > 0)
/*      */             {
/*  981 */               this.textDummy.func_146180_a(((Integer)this.intArrayList.get(this.intArrayList.size() - 1)).toString() + " ");
/*  982 */               this.intArrayList.remove(this.intArrayList.size() - 1);
/*  983 */               updateProperty(prop, this.selectedText);
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  988 */           else if (this.nestedIntArrayList.size() > 0) {
/*      */             
/*  990 */             int m = 0;
/*  991 */             Iterator<Map.Entry<Integer, ArrayList<Integer>>> ite = this.nestedIntArrayList.entrySet().iterator();
/*  992 */             while (ite.hasNext()) {
/*      */               
/*  994 */               Map.Entry<Integer, ArrayList<Integer>> e = ite.next();
/*  995 */               m++;
/*  996 */               if (this.selected - this.selectedIntArrayProp == m) {
/*      */                 
/*  998 */                 if (((ArrayList)e.getValue()).size() > 0) {
/*      */                   
/* 1000 */                   this.textDummy.func_146180_a(((Integer)((ArrayList<Integer>)e.getValue()).get(((ArrayList)e.getValue()).size() - 1)).toString() + " ");
/* 1001 */                   ((ArrayList)e.getValue()).remove(((ArrayList)e.getValue()).size() - 1);
/*      */                 }
/*      */                 else {
/*      */                   
/* 1005 */                   this.textDummy.func_146180_a(((Integer)e.getKey()).toString() + " ");
/* 1006 */                   ite.remove();
/* 1007 */                   this.intArraySlots--;
/*      */                 } 
/* 1009 */                 updateProperty(prop, this.selectedText);
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/* 1016 */         this.textDummy.func_146202_e();
/* 1017 */         this.textDummy.func_146184_c(true);
/* 1018 */         this.textDummy.func_146195_b(true);
/* 1019 */         this.textDummy.func_146201_a(c, i);
/* 1020 */         this.textDummy.func_146184_c(false);
/* 1021 */         this.textDummy.func_146195_b(false);
/* 1022 */         this.textDummy.func_146202_e();
/* 1023 */         this.selectedText = this.textDummy.func_146179_b();
/*      */         
/* 1025 */         boolean isIntArraySlot = (this.selectedIntArrayProp != -1 && this.selected > this.selectedIntArrayProp && this.selected <= this.selectedIntArrayProp + this.intArraySlots);
/*      */         
/* 1027 */         if (!isIntArraySlot) {
/*      */           
/* 1029 */           Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get(this.selected)));
/* 1030 */           if (this.config.getPropType(prop) == Config.EnumPropType.COLOUR)
/*      */           {
/* 1032 */             if (this.selectedText.isEmpty()) {
/*      */               
/* 1034 */               this.selectedText = "#";
/* 1035 */               this.textDummy.func_146180_a("#");
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/* 1041 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void tick() {
/* 1046 */     this.blinker = (byte)(this.blinker + 1);
/* 1047 */     if (this.blinker >= 16)
/*      */     {
/* 1049 */       this.blinker = 0;
/*      */     }
/*      */     
/* 1052 */     if (this.settingKeybind)
/*      */     {
/* 1054 */       if (GuiScreen.func_146272_n() || GuiScreen.func_146271_m() || Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184)) {
/*      */         
/* 1056 */         this.keyHeldTime++;
/* 1057 */         if (this.keyHeldTime >= 60) {
/*      */           
/* 1059 */           this.keyHeldTime = 0;
/* 1060 */           Property prop = (Property)this.config.props.get(this.config.propNameToProp.get(this.propNames.get(this.selected)));
/* 1061 */           if (this.config.getPropType(prop) == Config.EnumPropType.KEYBIND) {
/*      */             
/* 1063 */             StringBuilder sb = new StringBuilder();
/*      */             
/* 1065 */             sb.append(this.lastKeyHeld);
/*      */             
/* 1067 */             if (GuiScreen.func_146272_n() && this.lastKeyHeld != 42 && this.lastKeyHeld != 54)
/*      */             {
/* 1069 */               sb.append(":SHIFT");
/*      */             }
/* 1071 */             if (GuiScreen.func_146271_m() && (Minecraft.field_142025_a ? (this.lastKeyHeld == 219 || this.lastKeyHeld == 220) : (this.lastKeyHeld == 29 || this.lastKeyHeld == 157)))
/*      */             {
/* 1073 */               sb.append(":CTRL");
/*      */             }
/* 1075 */             if ((Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184)) && this.lastKeyHeld != 56 && this.lastKeyHeld != 184)
/*      */             {
/* 1077 */               sb.append(":ALT");
/*      */             }
/*      */             
/* 1080 */             updateProperty(prop, sb.toString());
/*      */             
/* 1082 */             this.settingKeybind = false;
/* 1083 */             this.selected = -1;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\gui\config\GuiConfigSetterScroll.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */