/*    */ package ichun.client.gui.config;
/*    */ 
/*    */ import ichun.common.core.config.Config;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.gui.GuiControls;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuiConfigBase
/*    */   extends GuiControls
/*    */ {
/*    */   private GuiConfigBaseScroll scrollPane;
/*    */   public GameSettings gameSets;
/*    */   private Config config;
/*    */   private GuiButton selectedBtn;
/*    */   
/*    */   public GuiConfigBase(GuiScreen parentScreen, GameSettings gameSettings, Config cfg) {
/* 22 */     super(parentScreen, gameSettings);
/* 23 */     this.gameSets = gameSettings;
/* 24 */     this.config = cfg;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_73866_w_() {
/* 30 */     this.field_146495_a = (this.config != null) ? this.config.modName : "Other Options";
/*    */     
/* 32 */     this.field_146292_n.add(new GuiButton(200, this.field_146294_l / 2 - 100, this.field_146295_m - 28, I18n.func_135052_a("gui.done", new Object[0])));
/*    */     
/* 34 */     this.scrollPane = new GuiConfigBaseScroll(this, this.config, this.field_146297_k);
/* 35 */     this.scrollPane.func_148134_d(7, 8);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_73863_a(int par1, int par2, float par3) {
/* 42 */     func_146276_q_();
/* 43 */     this.scrollPane.func_148128_a(par1, par2, par3);
/* 44 */     func_73732_a(this.field_146289_q, this.field_146495_a, this.field_146294_l / 2, 4, 16777215);
/*    */     
/* 46 */     for (int k = 0; k < this.field_146292_n.size(); k++) {
/*    */       
/* 48 */       GuiButton guibutton = this.field_146292_n.get(k);
/* 49 */       guibutton.func_146112_a(this.field_146297_k, par1, par2);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_73869_a(char par1, int par2) {
/* 56 */     if (this.scrollPane.keyTyped(par1, par2))
/*    */     {
/* 58 */       if (par2 == 1) {
/*    */         
/* 60 */         this.field_146297_k.func_147108_a((GuiScreen)null);
/* 61 */         this.field_146297_k.func_71381_h();
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_73864_a(int par1, int par2, int par3) {
/* 70 */     if (par3 == 0)
/*    */     {
/* 72 */       for (int l = 0; l < this.field_146292_n.size(); l++) {
/*    */         
/* 74 */         GuiButton guibutton = this.field_146292_n.get(l);
/*    */         
/* 76 */         if (guibutton.func_146116_c(this.field_146297_k, par1, par2)) {
/*    */           
/* 78 */           this.selectedBtn = guibutton;
/* 79 */           guibutton.func_146113_a(this.field_146297_k.func_147118_V());
/* 80 */           func_146284_a(guibutton);
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_146286_b(int p_146286_1_, int p_146286_2_, int p_146286_3_) {
/* 89 */     if (this.selectedBtn != null && p_146286_3_ == 0) {
/*    */       
/* 91 */       this.selectedBtn.func_146118_a(p_146286_1_, p_146286_2_);
/* 92 */       this.selectedBtn = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\gui\config\GuiConfigBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */