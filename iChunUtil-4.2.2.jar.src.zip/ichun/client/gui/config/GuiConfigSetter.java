/*     */ package ichun.client.gui.config;
/*     */ 
/*     */ import ichun.common.core.config.Config;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiControls;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraftforge.common.config.Property;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuiConfigSetter
/*     */   extends GuiControls
/*     */ {
/*     */   private GuiConfigSetterScroll scrollPane;
/*     */   public GameSettings gameSets;
/*     */   private Config config;
/*     */   public ArrayList<Property> properties;
/*     */   private GuiButton selectedBtn;
/*     */   
/*     */   public GuiConfigSetter(GuiScreen parentScreen, GameSettings gameSettings, Config cfg, String title, ArrayList<Property> cat) {
/*  34 */     super(parentScreen, gameSettings);
/*  35 */     this.gameSets = gameSettings;
/*  36 */     this.config = cfg;
/*  37 */     this.field_146495_a = cfg.modName + " - " + title;
/*  38 */     this.properties = cat;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73866_w_() {
/*  44 */     this.field_146292_n.add(new GuiButton(200, this.field_146294_l / 2 - 100, this.field_146295_m - 28, I18n.func_135052_a("gui.done", new Object[0])));
/*     */     
/*  46 */     this.scrollPane = new GuiConfigSetterScroll(this, this.config, this.properties, this.field_146297_k);
/*  47 */     this.scrollPane.func_148134_d(7, 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73876_c() {
/*  54 */     this.scrollPane.tick();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_146281_b() {
/*  60 */     this.scrollPane.keyTyped('*', 28);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73863_a(int par1, int par2, float par3) {
/*  66 */     func_146276_q_();
/*  67 */     this.scrollPane.func_148128_a(par1, par2, par3);
/*  68 */     func_73732_a(this.field_146289_q, this.field_146495_a, this.field_146294_l / 2, 4, 16777215);
/*     */     
/*  70 */     for (int k = 0; k < this.field_146292_n.size(); k++) {
/*     */       
/*  72 */       GuiButton guibutton = this.field_146292_n.get(k);
/*  73 */       guibutton.func_146112_a(this.field_146297_k, par1, par2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_73869_a(char par1, int par2) {
/*  80 */     if (this.scrollPane.keyTyped(par1, par2))
/*     */     {
/*  82 */       if (par2 == 1) {
/*     */         
/*  84 */         this.field_146297_k.func_147108_a((GuiScreen)null);
/*  85 */         this.field_146297_k.func_71381_h();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_73864_a(int par1, int par2, int par3) {
/*  94 */     if (par3 == 0)
/*     */     {
/*  96 */       for (int l = 0; l < this.field_146292_n.size(); l++) {
/*     */         
/*  98 */         GuiButton guibutton = this.field_146292_n.get(l);
/*     */         
/* 100 */         if (guibutton.func_146116_c(this.field_146297_k, par1, par2)) {
/*     */           
/* 102 */           this.selectedBtn = guibutton;
/* 103 */           guibutton.func_146113_a(this.field_146297_k.func_147118_V());
/* 104 */           func_146284_a(guibutton);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146286_b(int p_146286_1_, int p_146286_2_, int p_146286_3_) {
/* 113 */     if (this.selectedBtn != null && p_146286_3_ == 0) {
/*     */       
/* 115 */       this.selectedBtn.func_146118_a(p_146286_1_, p_146286_2_);
/* 116 */       this.selectedBtn = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawTooltip(List<String> par1List, int par2, int par3) {
/* 122 */     if (!par1List.isEmpty()) {
/*     */       
/* 124 */       GL11.glDisable(32826);
/* 125 */       GL11.glDisable(2929);
/* 126 */       int k = 0;
/*     */       
/* 128 */       boolean shouldBreak = false;
/* 129 */       while (!shouldBreak) {
/*     */         
/* 131 */         for (int i = 0; i < par1List.size(); i++) {
/*     */           
/* 133 */           String s = par1List.get(i);
/* 134 */           if (s.length() > 17) {
/*     */             
/* 136 */             par1List.remove(i);
/* 137 */             String temp = s.substring(0, 17);
/* 138 */             int lastIndex = temp.lastIndexOf(" ");
/* 139 */             if (lastIndex == -1) {
/*     */               
/* 141 */               lastIndex = 17;
/*     */             }
/*     */             else {
/*     */               
/* 145 */               lastIndex++;
/*     */             } 
/* 147 */             par1List.add(i, s.substring(0, lastIndex));
/* 148 */             par1List.add(i + 1, s.substring(lastIndex, s.length()));
/*     */             break;
/*     */           } 
/* 151 */           if (i == par1List.size() - 1)
/*     */           {
/* 153 */             shouldBreak = true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 158 */       Iterator<String> iterator = par1List.iterator();
/*     */       
/* 160 */       while (iterator.hasNext()) {
/*     */         
/* 162 */         String s = iterator.next();
/* 163 */         int l = this.field_146289_q.func_78256_a(s);
/*     */         
/* 165 */         if (l > k)
/*     */         {
/* 167 */           k = l;
/*     */         }
/*     */       } 
/*     */       
/* 171 */       int i1 = par2 + 12;
/* 172 */       int j1 = par3 - 12;
/* 173 */       int k1 = 8;
/*     */       
/* 175 */       if (par1List.size() > 1)
/*     */       {
/* 177 */         k1 += 2 + (par1List.size() - 1) * 10;
/*     */       }
/*     */       
/* 180 */       if (i1 + k > this.field_146294_l)
/*     */       {
/* 182 */         i1 -= 28 + k;
/*     */       }
/*     */       
/* 185 */       if (j1 + k1 + 6 > this.field_146295_m)
/*     */       {
/* 187 */         j1 = this.field_146295_m - k1 - 6;
/*     */       }
/*     */       
/* 190 */       this.field_73735_i = 300.0F;
/* 191 */       int l1 = -267386864;
/* 192 */       func_73733_a(i1 - 3, j1 - 4, i1 + k + 3, j1 - 3, l1, l1);
/* 193 */       func_73733_a(i1 - 3, j1 + k1 + 3, i1 + k + 3, j1 + k1 + 4, l1, l1);
/* 194 */       func_73733_a(i1 - 3, j1 - 3, i1 + k + 3, j1 + k1 + 3, l1, l1);
/* 195 */       func_73733_a(i1 - 4, j1 - 3, i1 - 3, j1 + k1 + 3, l1, l1);
/* 196 */       func_73733_a(i1 + k + 3, j1 - 3, i1 + k + 4, j1 + k1 + 3, l1, l1);
/* 197 */       int i2 = 1347420415;
/* 198 */       int j2 = (i2 & 0xFEFEFE) >> 1 | i2 & 0xFF000000;
/* 199 */       func_73733_a(i1 - 3, j1 - 3 + 1, i1 - 3 + 1, j1 + k1 + 3 - 1, i2, j2);
/* 200 */       func_73733_a(i1 + k + 2, j1 - 3 + 1, i1 + k + 3, j1 + k1 + 3 - 1, i2, j2);
/* 201 */       func_73733_a(i1 - 3, j1 - 3, i1 + k + 3, j1 - 3 + 1, i2, i2);
/* 202 */       func_73733_a(i1 - 3, j1 + k1 + 2, i1 + k + 3, j1 + k1 + 3, j2, j2);
/*     */       
/* 204 */       for (int k2 = 0; k2 < par1List.size(); k2++) {
/*     */         
/* 206 */         String s1 = par1List.get(k2);
/* 207 */         this.field_146289_q.func_78261_a(s1, i1, j1, -1);
/*     */         
/* 209 */         if (k2 == 0)
/*     */         {
/* 211 */           j1 += 2;
/*     */         }
/*     */         
/* 214 */         j1 += 10;
/*     */       } 
/*     */       
/* 217 */       this.field_73735_i = 0.0F;
/* 218 */       GL11.glEnable(2929);
/* 219 */       GL11.glEnable(32826);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\gui\config\GuiConfigSetter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */