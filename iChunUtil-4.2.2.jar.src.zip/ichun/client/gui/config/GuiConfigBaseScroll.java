/*     */ package ichun.client.gui.config;
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import ichun.common.core.config.Config;
/*     */ import ichun.common.core.config.ConfigHandler;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.audio.PositionedSoundRecord;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.GuiSlot;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiConfigBaseScroll extends GuiSlot {
/*  16 */   protected static final ResourceLocation WIDGITS = new ResourceLocation("textures/gui/widgets.png");
/*     */   private GuiConfigBase controls;
/*     */   private Minecraft mc;
/*     */   private Config config;
/*     */   private String[] message;
/*     */   private int _mouseX;
/*     */   private int _mouseY;
/*  23 */   private int selected = -1;
/*     */ 
/*     */   
/*     */   public GuiConfigBaseScroll(GuiConfigBase controls, Config cfg, Minecraft mc) {
/*  27 */     super(mc, controls.field_146294_l, controls.field_146295_m, 16, controls.field_146295_m - 32 + 4, 25);
/*  28 */     this.controls = controls;
/*  29 */     this.mc = mc;
/*  30 */     this.config = cfg;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int func_148127_b() {
/*  36 */     return (this.config != null) ? this.config.categoriesList.size() : ConfigHandler.configs.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_148144_a(int i, boolean flag, int mouseX, int mouseY) {
/*  42 */     if (!flag) {
/*     */       
/*  44 */       Config oriCfg = this.config;
/*  45 */       if (this.config == null) {
/*     */         
/*  47 */         Config cfg = ConfigHandler.configs.get(i);
/*  48 */         if (!cfg.categories.isEmpty()) {
/*     */           
/*  50 */           this.mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0F));
/*  51 */           FMLClientHandler.instance().showGuiScreen(new GuiConfigBase((GuiScreen)this.controls, this.controls.gameSets, cfg));
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/*  56 */         this.config = cfg;
/*     */       } 
/*     */       
/*  59 */       if (this.config != null)
/*     */       {
/*  61 */         if (this.config.categoriesList.size() > 0) {
/*     */           
/*  63 */           this.mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0F));
/*  64 */           FMLClientHandler.instance().showGuiScreen(new GuiConfigSetter((GuiScreen)this.controls, this.controls.gameSets, this.config, this.config.categoriesList.get(i), (ArrayList<Property>)this.config.categories.get(this.config.categoriesList.get(i))));
/*     */         }
/*     */         else {
/*     */           
/*  68 */           this.config = oriCfg;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_148131_a(int i) {
/*  78 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_148123_a() {}
/*     */ 
/*     */   
/*     */   public void func_148128_a(int mX, int mY, float f) {
/*  87 */     this._mouseX = mX;
/*  88 */     this._mouseY = mY;
/*     */     
/*  90 */     super.func_148128_a(mX, mY, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_148126_a(int index, int xPosition, int yPosition, int l, Tessellator tessellator, int mouseX, int mouseY) {
/*  96 */     int width = 150;
/*  97 */     int height = 20;
/*  98 */     xPosition += 32;
/*  99 */     boolean flag = (this._mouseX >= xPosition && this._mouseY >= yPosition && this._mouseX < xPosition + width && this._mouseY < yPosition + height);
/* 100 */     int k = flag ? 2 : 1;
/*     */     
/* 102 */     if (this.config == null && ((Config)ConfigHandler.configs.get(index)).categoriesList.isEmpty())
/*     */     {
/* 104 */       k = 0;
/*     */     }
/*     */     
/* 107 */     this.mc.field_71446_o.func_110577_a(WIDGITS);
/* 108 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 109 */     this.controls.func_73729_b(xPosition, yPosition, 0, 46 + k * 20, width / 2, height);
/* 110 */     this.controls.func_73729_b(xPosition + width / 2, yPosition, 200 - width / 2, 46 + k * 20, width / 2, height);
/*     */     
/* 112 */     String str = ((k == 2) ? (String)EnumChatFormatting.YELLOW : "") + ((this.config != null && this.config.categoriesList.size() > 0) ? this.config.categoriesList.get(index) : ((Config)ConfigHandler.configs.get(index)).modName);
/* 113 */     this.controls.func_73732_a(this.mc.field_71466_p, str, xPosition + width / 2, yPosition + (height - 8) / 2, (k != 0) ? -1 : -6250336);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean keyTyped(char c, int i) {
/* 118 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\gui\config\GuiConfigBaseScroll.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */