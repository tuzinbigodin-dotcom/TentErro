package ichun.client.gui;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public interface ISlider {
  void onChangeSliderValue(GuiSlider paramGuiSlider);
}


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\gui\ISlider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */