/*     */ package ichun.client.gui;
/*     */ 
/*     */ import cpw.mods.fml.client.config.GuiUtils;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiSlider
/*     */   extends GuiButton
/*     */ {
/*     */   public double sliderValue;
/*     */   public String dispString;
/*     */   public boolean dragging;
/*     */   public boolean showDecimal;
/*     */   public double minValue;
/*     */   public double maxValue;
/*     */   public ISlider parent;
/*     */   public String suffix;
/*     */   public boolean drawString;
/*     */   
/*     */   public GuiSlider(int id, int xPos, int yPos, int length, String prefix, String suf, double minVal, double maxVal, double currentVal, boolean showDec, boolean drawStr, ISlider par) {
/*  34 */     super(id, xPos, yPos, length, 20, prefix); String val; this.sliderValue = 1.0D; this.dispString = ""; this.dragging = false; this.showDecimal = true; this.minValue = 0.0D; this.maxValue = 5.0D; this.parent = null; this.suffix = ""; this.drawString = true;
/*  35 */     this.minValue = minVal;
/*  36 */     this.maxValue = maxVal;
/*  37 */     if (currentVal < this.minValue) {
/*     */       
/*  39 */       currentVal = this.minValue;
/*     */     }
/*  41 */     else if (currentVal > this.maxValue) {
/*     */       
/*  43 */       currentVal = this.maxValue;
/*     */     } 
/*  45 */     this.sliderValue = (currentVal - this.minValue) / (this.maxValue - this.minValue);
/*  46 */     this.dispString = prefix;
/*  47 */     this.parent = par;
/*  48 */     this.suffix = suf;
/*  49 */     this.showDecimal = showDec;
/*     */ 
/*     */     
/*  52 */     if (this.showDecimal) {
/*     */       
/*  54 */       val = Double.toString(this.sliderValue * (this.maxValue - this.minValue) + this.minValue);
/*     */       
/*  56 */       if (val.length() > 4)
/*     */       {
/*  58 */         val = val.substring(0, 4);
/*     */         
/*  60 */         if (val.endsWith("."))
/*     */         {
/*  62 */           val = val.substring(0, 3);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  67 */         while (val.length() < 4)
/*     */         {
/*  69 */           val = val + "0";
/*     */         }
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  75 */       val = Integer.toString((int)Math.round(this.sliderValue * (this.maxValue - this.minValue) + this.minValue));
/*     */     } 
/*     */     
/*  78 */     this.field_146126_j = this.dispString + val + this.suffix;
/*     */     
/*  80 */     this.drawString = drawStr;
/*  81 */     if (!this.drawString)
/*     */     {
/*  83 */       this.field_146126_j = "";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public GuiSlider(int id, int xPos, int yPos, String displayStr, double minVal, double maxVal, double currentVal, ISlider par) {
/*  89 */     this(id, xPos, yPos, 150, displayStr, "", minVal, maxVal, currentVal, true, true, par);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_146114_a(boolean par1) {
/*  99 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146119_b(Minecraft par1Minecraft, int par2, int par3) {
/* 108 */     if (this.field_146125_m) {
/*     */       
/* 110 */       if (this.dragging) {
/*     */         
/* 112 */         this.sliderValue = ((par2 - this.field_146128_h + 4) / (this.field_146120_f - 8));
/* 113 */         updateSlider();
/*     */       } 
/*     */       
/* 116 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 117 */       func_73729_b(this.field_146128_h + (int)(this.sliderValue * (this.field_146120_f - 8)), this.field_146129_i, 0, 66, 4, 20);
/* 118 */       func_73729_b(this.field_146128_h + (int)(this.sliderValue * (this.field_146120_f - 8)) + 4, this.field_146129_i, 196, 66, 4, 20);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_146116_c(Minecraft par1Minecraft, int par2, int par3) {
/* 129 */     if (super.func_146116_c(par1Minecraft, par2, par3)) {
/*     */       
/* 131 */       this.sliderValue = ((par2 - this.field_146128_h + 4) / (this.field_146120_f - 8));
/* 132 */       updateSlider();
/* 133 */       this.dragging = true;
/* 134 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateSlider() {
/*     */     String val;
/* 144 */     if (this.sliderValue < 0.0D)
/*     */     {
/* 146 */       this.sliderValue = 0.0D;
/*     */     }
/*     */     
/* 149 */     if (this.sliderValue > 1.0D)
/*     */     {
/* 151 */       this.sliderValue = 1.0D;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 156 */     if (this.showDecimal) {
/*     */       
/* 158 */       val = Double.toString(this.sliderValue * (this.maxValue - this.minValue) + this.minValue);
/*     */       
/* 160 */       if (val.length() > 4)
/*     */       {
/* 162 */         val = val.substring(0, 4);
/*     */         
/* 164 */         if (val.endsWith("."))
/*     */         {
/* 166 */           val = val.substring(0, 3);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 171 */         while (val.length() < 4)
/*     */         {
/* 173 */           val = val + "0";
/*     */         }
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 179 */       val = Integer.toString((int)Math.round(this.sliderValue * (this.maxValue - this.minValue) + this.minValue));
/*     */     } 
/*     */     
/* 182 */     if (this.drawString)
/*     */     {
/* 184 */       this.field_146126_j = this.dispString + val + this.suffix;
/*     */     }
/*     */     
/* 187 */     this.parent.onChangeSliderValue(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_146118_a(int par1, int par2) {
/* 196 */     this.dragging = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getValueInt() {
/* 201 */     return (int)Math.round(this.sliderValue * (this.maxValue - this.minValue) + this.minValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getValue() {
/* 206 */     return this.sliderValue * (this.maxValue - this.minValue) + this.minValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_146112_a(Minecraft mc, int mouseX, int mouseY) {
/* 217 */     if (this.field_146125_m) {
/*     */       
/* 219 */       this.field_146123_n = (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g);
/* 220 */       int k = func_146114_a(this.field_146123_n);
/* 221 */       GuiUtils.drawContinuousTexturedBox(field_146122_a, this.field_146128_h, this.field_146129_i, 0, 46 + k * 20, this.field_146120_f, this.field_146121_g, 200, 20, 2, 3, 2, 2, this.field_73735_i);
/* 222 */       func_146119_b(mc, mouseX, mouseY);
/* 223 */       int color = 14737632;
/*     */       
/* 225 */       if (this.packedFGColour != 0) {
/*     */         
/* 227 */         color = this.packedFGColour;
/*     */       }
/* 229 */       else if (!this.field_146124_l) {
/*     */         
/* 231 */         color = 10526880;
/*     */       }
/* 233 */       else if (this.field_146123_n) {
/*     */         
/* 235 */         color = 16777120;
/*     */       } 
/*     */       
/* 238 */       String buttonText = this.field_146126_j;
/* 239 */       int strWidth = mc.field_71466_p.func_78256_a(buttonText);
/* 240 */       int ellipsisWidth = mc.field_71466_p.func_78256_a("...");
/*     */       
/* 242 */       if (strWidth > this.field_146120_f - 6 && strWidth > ellipsisWidth) {
/* 243 */         buttonText = mc.field_71466_p.func_78269_a(buttonText, this.field_146120_f - 6 - ellipsisWidth).trim() + "...";
/*     */       }
/* 245 */       func_73732_a(mc.field_71466_p, buttonText, this.field_146128_h + this.field_146120_f / 2, this.field_146129_i + (this.field_146121_g - 8) / 2, color);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\gui\GuiSlider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */