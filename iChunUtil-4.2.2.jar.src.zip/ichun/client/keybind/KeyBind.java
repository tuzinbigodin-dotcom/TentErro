/*     */ package ichun.client.keybind;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyBind
/*     */ {
/*     */   public final int keyIndex;
/*     */   public final boolean holdShift;
/*     */   public final boolean holdCtrl;
/*     */   public final boolean holdAlt;
/*     */   public boolean canPulse;
/*     */   public int pulseTime;
/*     */   public int pulseTimer;
/*     */   public boolean ignoreHold;
/*     */   private boolean pressed;
/*     */   private boolean isMinecraftBind;
/*     */   public int usages;
/*     */   
/*     */   public KeyBind(int index, boolean shift, boolean ctrl, boolean alt, boolean ignoreHolding) {
/*  32 */     this.keyIndex = index;
/*  33 */     this.holdShift = shift;
/*  34 */     this.holdCtrl = ctrl;
/*  35 */     this.holdAlt = alt;
/*  36 */     this.ignoreHold = ignoreHolding;
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/*  41 */     if (this.canPulse)
/*     */     {
/*  43 */       if (this.pressed) {
/*     */         
/*  45 */         this.pulseTimer--;
/*  46 */         if (this.pulseTimer == 0)
/*     */         {
/*  48 */           triggerEvent(true);
/*  49 */           this.pulseTimer = this.pulseTime;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/*  54 */         this.pulseTimer = this.pulseTime;
/*     */       } 
/*     */     }
/*     */     
/*  58 */     boolean flag = this.pressed;
/*     */     
/*  60 */     this.pressed = checkPressed();
/*  61 */     if (this.pressed != flag)
/*     */     {
/*  63 */       triggerEvent(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private boolean checkPressed() {
/*  70 */     boolean stateShift = ((this.holdShift && GuiScreen.func_146272_n()) || (!this.holdShift && (this.ignoreHold || !GuiScreen.func_146272_n() || this.keyIndex == 42 || this.keyIndex == 54)));
/*  71 */     boolean stateCtrl = ((this.holdCtrl && GuiScreen.func_146271_m()) || (!this.holdCtrl && (this.ignoreHold || !GuiScreen.func_146271_m() || this.keyIndex == (Minecraft.field_142025_a ? 219 : 29) || this.keyIndex == (Minecraft.field_142025_a ? 220 : 157))));
/*  72 */     boolean stateAlt = ((this.holdAlt && (Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184))) || (!this.holdAlt && (this.ignoreHold || (!Keyboard.isKeyDown(56) && !Keyboard.isKeyDown(184)) || this.keyIndex == 56 || this.keyIndex == 184)));
/*  73 */     if (!stateShift || !stateCtrl || !stateAlt)
/*     */     {
/*  75 */       return false;
/*     */     }
/*  77 */     return isPressed(this.keyIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyBind setPulse(boolean flag, int time) {
/*  82 */     if (flag) {
/*     */       
/*  84 */       this.canPulse = true;
/*  85 */       this.pulseTime = time;
/*  86 */       this.pulseTimer = this.pulseTime;
/*     */     }
/*     */     else {
/*     */       
/*  90 */       this.canPulse = false;
/*     */     } 
/*  92 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void triggerEvent(boolean pulse) {
/*  97 */     MinecraftForge.EVENT_BUS.post(new KeyEvent(this, pulse));
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyBind setIsMinecraftBind() {
/* 102 */     this.isMinecraftBind = true;
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMinecraftBind() {
/* 108 */     return this.isMinecraftBind;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 114 */     if (obj instanceof KeyBind) {
/*     */       
/* 116 */       KeyBind bind = (KeyBind)obj;
/* 117 */       return (bind.keyIndex == this.keyIndex && bind.holdShift == this.holdShift && bind.holdCtrl == this.holdCtrl && bind.holdAlt == this.holdAlt && bind.canPulse == this.canPulse && bind.pulseTime == this.pulseTime && bind.ignoreHold == this.ignoreHold);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static boolean isPressed(int key) {
/* 131 */     if (key < 0)
/*     */     {
/* 133 */       return Mouse.isButtonDown(key + 100);
/*     */     }
/* 135 */     return Keyboard.isKeyDown(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPressed() {
/* 140 */     return this.pressed;
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\keybind\KeyBind.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */