/*    */ package ichun.client.keybind;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.Event;
/*    */ 
/*    */ public class KeyEvent
/*    */   extends Event
/*    */ {
/*    */   public final KeyBind keyBind;
/*    */   public final boolean isPulse;
/*    */   
/*    */   public KeyEvent(KeyBind keyBind, boolean pulse) {
/* 12 */     this.keyBind = keyBind;
/* 13 */     this.isPulse = pulse;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\keybind\KeyEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */