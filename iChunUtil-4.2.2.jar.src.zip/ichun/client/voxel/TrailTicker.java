/*     */ package ichun.client.voxel;
/*     */ 
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import ichun.common.core.network.AbstractPacket;
/*     */ import ichun.common.core.network.PacketHandler;
/*     */ import ichun.common.core.packet.PacketShowPatronReward;
/*     */ import ichun.common.iChunUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class TrailTicker {
/*     */   public float renderTick;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void renderTick(TickEvent.RenderTickEvent event) {
/*  25 */     if (event.phase == TickEvent.Phase.START) {
/*     */       
/*  27 */       this.renderTick = event.renderTickTime;
/*     */       
/*  29 */       Iterator<Map.Entry<String, EntityTrail>> iterator = this.streaks.entrySet().iterator();
/*     */       
/*  31 */       while (iterator.hasNext()) {
/*     */         
/*  33 */         Map.Entry<String, EntityTrail> e = iterator.next();
/*  34 */         if (((EntityTrail)e.getValue()).parent != null) {
/*     */           
/*  36 */           EntityTrail streak = e.getValue();
/*  37 */           if (((EntityTrail)e.getValue()).parent.field_70128_L) {
/*     */             
/*  39 */             streak.func_70106_y();
/*  40 */             iterator.remove();
/*     */             
/*     */             continue;
/*     */           } 
/*  44 */           updatePos(streak);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public WorldClient worldInstance;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void worldTick(TickEvent.ClientTickEvent event) {
/*  54 */     if (event.phase == TickEvent.Phase.END && (Minecraft.func_71410_x()).field_71441_e != null) {
/*     */       
/*  56 */       WorldClient world = (Minecraft.func_71410_x()).field_71441_e;
/*  57 */       if (this.worldInstance != world) {
/*     */         
/*  59 */         this.worldInstance = world;
/*  60 */         this.streaks.clear();
/*     */       } 
/*     */       
/*  63 */       Iterator<Map.Entry<String, EntityTrail>> ite = this.streaks.entrySet().iterator();
/*     */       
/*  65 */       while (ite.hasNext()) {
/*     */         
/*  67 */         Map.Entry<String, EntityTrail> e = ite.next();
/*  68 */         if (((EntityTrail)e.getValue()).field_70170_p.field_73011_w.field_76574_g != world.field_73011_w.field_76574_g || world.func_72820_D() - ((EntityTrail)e.getValue()).lastUpdate > 10L) {
/*     */           
/*  70 */           ((EntityTrail)e.getValue()).func_70106_y();
/*  71 */           ite.remove();
/*     */         } 
/*     */       } 
/*     */       
/*  75 */       if (this.tellServerAsPatron) {
/*     */         
/*  77 */         this.tellServerAsPatron = false;
/*  78 */         PacketHandler.sendToServer(iChunUtil.channels, (AbstractPacket)new PacketShowPatronReward((iChunUtil.config.getInt("showPatronReward") == 1)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void playerTick(TickEvent.PlayerTickEvent event) {
/*  86 */     if (event.side == Side.CLIENT && event.phase == TickEvent.Phase.END) {
/*     */       
/*  88 */       AbstractClientPlayer player = (AbstractClientPlayer)event.player;
/*  89 */       if (player.field_70170_p.func_72924_a(player.func_70005_c_()) != player) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  94 */       WorldClient world = (Minecraft.func_71410_x()).field_71441_e;
/*     */       
/*  96 */       EntityTrail hat = this.streaks.get(player.func_70005_c_());
/*  97 */       if (hat == null || hat.field_70128_L) {
/*     */         
/*  99 */         if (player.func_70005_c_().equalsIgnoreCase((Minecraft.func_71410_x()).field_71439_g.func_70005_c_()))
/*     */         {
/*     */           
/* 102 */           for (Map.Entry<String, EntityTrail> e : this.streaks.entrySet())
/*     */           {
/* 104 */             ((EntityTrail)e.getValue()).func_70106_y();
/*     */           }
/*     */         }
/*     */         
/* 108 */         hat = new EntityTrail((World)world, player);
/* 109 */         this.streaks.put(player.func_70005_c_(), hat);
/* 110 */         world.func_72838_d(hat);
/*     */       } 
/*     */       
/* 113 */       ArrayList<LocationInfo> loc = getPlayerLocationInfo((EntityPlayer)player);
/* 114 */       LocationInfo oldest = loc.get(0);
/* 115 */       loc.remove(0);
/* 116 */       loc.add(oldest);
/* 117 */       oldest.update((EntityPlayer)player);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<LocationInfo> getPlayerLocationInfo(EntityPlayer player) {
/* 123 */     ArrayList<LocationInfo> loc = this.playerLoc.get(player.func_70005_c_());
/* 124 */     if (loc == null) {
/*     */       
/* 126 */       loc = new ArrayList<LocationInfo>();
/* 127 */       this.playerLoc.put(player.func_70005_c_(), loc);
/*     */     } 
/* 129 */     int time = 100;
/* 130 */     if (loc.size() < time) {
/*     */       
/* 132 */       for (int i = 0; i < time - loc.size(); i++)
/*     */       {
/* 134 */         loc.add(0, new LocationInfo(player));
/*     */       }
/*     */     }
/* 137 */     else if (loc.size() > time) {
/*     */       
/* 139 */       loc.remove(0);
/*     */     } 
/* 141 */     return loc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updatePos(EntityTrail streak) {
/* 146 */     streak.field_70142_S = streak.parent.field_70142_S;
/* 147 */     streak.field_70137_T = streak.parent.field_70137_T;
/* 148 */     streak.field_70136_U = streak.parent.field_70136_U;
/*     */     
/* 150 */     streak.field_70169_q = streak.parent.field_70169_q;
/* 151 */     streak.field_70167_r = streak.parent.field_70167_r;
/* 152 */     streak.field_70166_s = streak.parent.field_70166_s;
/*     */     
/* 154 */     streak.field_70165_t = streak.parent.field_70165_t;
/* 155 */     streak.field_70163_u = streak.parent.field_70163_u;
/* 156 */     streak.field_70161_v = streak.parent.field_70161_v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public HashMap<String, ArrayList<LocationInfo>> playerLoc = new HashMap<String, ArrayList<LocationInfo>>();
/*     */   
/* 165 */   public HashMap<String, EntityTrail> streaks = new HashMap<String, EntityTrail>();
/*     */   
/* 167 */   public ArrayList<String> patronList = new ArrayList<String>();
/*     */   public boolean tellServerAsPatron;
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\voxel\TrailTicker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */