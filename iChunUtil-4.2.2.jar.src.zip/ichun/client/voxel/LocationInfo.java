/*    */ package ichun.client.voxel;
/*    */ 
/*    */ import ichun.common.core.CommonProxy;
/*    */ import ichun.common.iChunUtil;
/*    */ import morph.api.Api;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocationInfo
/*    */ {
/*    */   public double posX;
/*    */   public double posY;
/*    */   public double posZ;
/*    */   public float renderYawOffset;
/*    */   public float rotationYawHead;
/*    */   public float rotationPitch;
/*    */   public float limbSwing;
/*    */   public float limbSwingAmount;
/*    */   public boolean sneaking;
/*    */   public boolean canRender;
/*    */   public long lastTick;
/*    */   public float pitchChange;
/*    */   public float yawChange;
/*    */   public ResourceLocation txLocation;
/*    */   
/*    */   public LocationInfo(EntityPlayer player) {
/* 33 */     update(player);
/*    */   }
/*    */ 
/*    */   
/*    */   public void update(EntityPlayer player) {
/* 38 */     this.posX = player.field_70165_t;
/* 39 */     this.posY = player.field_70121_D.field_72338_b;
/* 40 */     this.posZ = player.field_70161_v;
/*    */     
/* 42 */     this.renderYawOffset = player.field_70761_aq;
/* 43 */     this.rotationYawHead = player.field_70759_as;
/* 44 */     this.rotationPitch = player.field_70125_A;
/*    */     
/* 46 */     this.limbSwing = player.field_70754_ba;
/* 47 */     this.limbSwingAmount = player.field_70721_aZ;
/*    */     
/* 49 */     this.sneaking = player.func_70093_af();
/*    */     
/* 51 */     this.lastTick = player.field_70170_p.func_72820_D();
/* 52 */     float speed = 7.5F;
/* 53 */     this.pitchChange = player.field_70170_p.field_73012_v.nextFloat() * speed * 2.0F - speed;
/* 54 */     this.yawChange = player.field_70170_p.field_73012_v.nextFloat() * speed * 2.0F - speed;
/*    */     
/* 56 */     this.canRender = false;
/* 57 */     for (String s : CommonProxy.trailTicker.patronList) {
/*    */       
/* 59 */       if (s.equals(player.func_146103_bH().getId().toString())) {
/*    */         
/* 61 */         this.canRender = true;
/*    */         break;
/*    */       } 
/*    */     } 
/* 65 */     this.txLocation = ((AbstractClientPlayer)player).func_110306_p();
/* 66 */     if (this.canRender && player.func_82150_aj())
/*    */     {
/* 68 */       this.canRender = false;
/*    */     }
/* 70 */     if (this.canRender && iChunUtil.hasMorphMod)
/*    */     {
/* 72 */       if (Api.hasMorph(player.func_70005_c_(), true)) {
/*    */         
/* 74 */         if (Api.morphProgress(player.func_70005_c_(), true) < 1.0F || !(Api.getMorphEntity(player.func_70005_c_(), true) instanceof AbstractClientPlayer))
/*    */         {
/* 76 */           this.canRender = false;
/*    */         }
/* 78 */         if (Api.getMorphEntity(player.func_70005_c_(), true) instanceof AbstractClientPlayer)
/*    */         {
/* 80 */           this.txLocation = ((AbstractClientPlayer)Api.getMorphEntity(player.func_70005_c_(), true)).func_110306_p();
/*    */         }
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\client\voxel\LocationInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */