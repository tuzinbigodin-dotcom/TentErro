/*    */ package ichun.common.core.network;
/*    */ 
/*    */ import cpw.mods.fml.common.FMLCommonHandler;
/*    */ import cpw.mods.fml.common.network.FMLEmbeddedChannel;
/*    */ import cpw.mods.fml.common.network.FMLOutboundHandler;
/*    */ import cpw.mods.fml.common.network.NetworkRegistry;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import java.util.EnumMap;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PacketHandler
/*    */ {
/*    */   public static void sendToAll(EnumMap<Side, FMLEmbeddedChannel> channels, AbstractPacket packet) {
/* 16 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.ALL);
/* 17 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).writeAndFlush(packet);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void sendToPlayer(EnumMap<Side, FMLEmbeddedChannel> channels, AbstractPacket packet, EntityPlayer player) {
/* 22 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.PLAYER);
/* 23 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGETARGS).set(player);
/* 24 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).writeAndFlush(packet);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void sendToAllAround(EnumMap<Side, FMLEmbeddedChannel> channels, AbstractPacket packet, NetworkRegistry.TargetPoint point) {
/* 29 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.ALLAROUNDPOINT);
/* 30 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGETARGS).set(point);
/* 31 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).writeAndFlush(packet);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void sendToDimension(EnumMap<Side, FMLEmbeddedChannel> channels, AbstractPacket packet, int dimension) {
/* 36 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.DIMENSION);
/* 37 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGETARGS).set(Integer.valueOf(dimension));
/* 38 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).writeAndFlush(packet);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void sendToServer(EnumMap<Side, FMLEmbeddedChannel> channels, AbstractPacket packet) {
/* 43 */     ((FMLEmbeddedChannel)channels.get(Side.CLIENT)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.TOSERVER);
/* 44 */     ((FMLEmbeddedChannel)channels.get(Side.CLIENT)).writeAndFlush(packet);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void sendToAllExcept(EnumMap<Side, FMLEmbeddedChannel> channels, AbstractPacket packet, EntityPlayer player) {
/* 49 */     for (int i = 0; i < (FMLCommonHandler.instance().getMinecraftServerInstance().func_71203_ab()).field_72404_b.size(); i++) {
/*    */       
/* 51 */       EntityPlayer player1 = (FMLCommonHandler.instance().getMinecraftServerInstance().func_71203_ab()).field_72404_b.get(i);
/*    */       
/* 53 */       if (!player.func_70005_c_().equalsIgnoreCase(player1.func_70005_c_()))
/*    */       {
/*    */ 
/*    */ 
/*    */         
/* 58 */         sendToPlayer(channels, packet, player1);
/*    */       }
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\network\PacketHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */