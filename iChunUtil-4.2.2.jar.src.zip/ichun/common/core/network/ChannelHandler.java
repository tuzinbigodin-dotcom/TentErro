/*     */ package ichun.common.core.network;
/*     */ 
/*     */ import cpw.mods.fml.common.network.FMLEmbeddedChannel;
/*     */ import cpw.mods.fml.common.network.FMLIndexedMessageToMessageCodec;
/*     */ import cpw.mods.fml.common.network.NetworkRegistry;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import ichun.common.iChunUtil;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandler.Sharable;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.SimpleChannelInboundHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.crash.CrashReport;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.network.INetHandler;
/*     */ import net.minecraft.network.NetHandlerPlayServer;
/*     */ import net.minecraft.util.ReportedException;
/*     */ 
/*     */ public class ChannelHandler
/*     */   extends FMLIndexedMessageToMessageCodec<AbstractPacket>
/*     */ {
/*     */   public final String channel;
/*     */   
/*     */   private ChannelHandler(String s, Class<? extends AbstractPacket>... packetTypes) {
/*  30 */     this.channel = s;
/*  31 */     ArrayList<Class<? extends AbstractPacket>> list = new ArrayList<Class<? extends AbstractPacket>>();
/*  32 */     for (int i = 0; i < packetTypes.length; i++) {
/*     */       
/*  34 */       if (!list.contains(packetTypes[i])) {
/*     */         
/*  36 */         list.add(packetTypes[i]);
/*     */       }
/*     */       else {
/*     */         
/*  40 */         iChunUtil.console("Channel " + this.channel + " is reregistering packet types!", true);
/*     */       } 
/*  42 */       addDiscriminator(i, packetTypes[i]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static EnumMap<Side, FMLEmbeddedChannel> getChannelHandlers(String modId, Class<? extends AbstractPacket>... packetTypes) {
/*  48 */     if (packetTypes.length == 0)
/*     */     {
/*  50 */       throw new ReportedException(new CrashReport("Mod " + modId + " is not registering any packets with its channel handlers.", new Throwable()));
/*     */     }
/*  52 */     EnumMap<Side, FMLEmbeddedChannel> handlers = NetworkRegistry.INSTANCE.newChannel(modId, new io.netty.channel.ChannelHandler[] { (io.netty.channel.ChannelHandler)new ChannelHandler(modId, packetTypes) });
/*     */     
/*  54 */     PacketExecuter executer = new PacketExecuter();
/*     */     
/*  56 */     for (Map.Entry<Side, FMLEmbeddedChannel> e : handlers.entrySet()) {
/*     */       
/*  58 */       FMLEmbeddedChannel channel = e.getValue();
/*  59 */       String codec = channel.findChannelHandlerNameForType(ChannelHandler.class);
/*  60 */       channel.pipeline().addAfter(codec, "PacketExecuter", (io.netty.channel.ChannelHandler)executer);
/*     */     } 
/*     */     
/*  63 */     return handlers;
/*     */   }
/*     */   
/*     */   @Sharable
/*     */   private static class PacketExecuter
/*     */     extends SimpleChannelInboundHandler<AbstractPacket> {
/*     */     private PacketExecuter() {}
/*     */     
/*     */     protected void channelRead0(ChannelHandlerContext ctx, AbstractPacket msg) throws Exception {
/*  72 */       Side side = (Side)ctx.channel().attr(NetworkRegistry.CHANNEL_SOURCE).get();
/*  73 */       EntityPlayer player = null;
/*  74 */       if (side.isServer()) {
/*     */         
/*  76 */         INetHandler netHandler = (INetHandler)ctx.channel().attr(NetworkRegistry.NET_HANDLER).get();
/*  77 */         EntityPlayerMP entityPlayerMP = ((NetHandlerPlayServer)netHandler).field_147369_b;
/*     */       }
/*     */       else {
/*     */         
/*  81 */         player = getClientPlayer();
/*     */       } 
/*     */       
/*  84 */       msg.execute(side, player);
/*     */     }
/*     */ 
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public EntityPlayer getClientPlayer() {
/*  90 */       return (EntityPlayer)(Minecraft.func_71410_x()).field_71439_g;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeInto(ChannelHandlerContext ctx, AbstractPacket msg, ByteBuf target) throws Exception {
/*     */     try {
/*  99 */       msg.writeTo(target, (Side)ctx.channel().attr(NetworkRegistry.CHANNEL_SOURCE).get());
/*     */     }
/* 101 */     catch (Exception e) {
/*     */       
/* 103 */       iChunUtil.console("Error writing to packet for channel: " + this.channel, true);
/* 104 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf source, AbstractPacket msg) {
/*     */     try {
/* 113 */       msg.readFrom(source, (Side)ctx.channel().attr(NetworkRegistry.CHANNEL_SOURCE).get());
/*     */     }
/* 115 */     catch (Exception e) {
/*     */       
/* 117 */       iChunUtil.console("Error reading from packet for channel: " + this.channel, true);
/* 118 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\network\ChannelHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */