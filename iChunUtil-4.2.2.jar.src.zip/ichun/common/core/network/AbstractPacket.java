package ichun.common.core.network;

import cpw.mods.fml.relauncher.Side;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;

public abstract class AbstractPacket {
  public abstract void writeTo(ByteBuf paramByteBuf, Side paramSide);
  
  public abstract void readFrom(ByteBuf paramByteBuf, Side paramSide);
  
  public abstract void execute(Side paramSide, EntityPlayer paramEntityPlayer);
}


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\network\AbstractPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */