/*    */ package ichun.common.core.packet;
/*    */ 
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import ichun.common.core.CommonProxy;
/*    */ import ichun.common.core.network.AbstractPacket;
/*    */ import ichun.common.iChunUtil;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PacketPatrons
/*    */   extends AbstractPacket
/*    */ {
/*    */   public void writeTo(ByteBuf buffer, Side side) {
/* 17 */     for (String s : iChunUtil.patronList)
/*    */     {
/* 19 */       ByteBufUtils.writeUTF8String(buffer, s);
/*    */     }
/* 21 */     ByteBufUtils.writeUTF8String(buffer, "##endPacket");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void readFrom(ByteBuf buffer, Side side) {
/* 27 */     CommonProxy.trailTicker.patronList.clear();
/* 28 */     String s = ByteBufUtils.readUTF8String(buffer);
/* 29 */     while (!s.equals("##endPacket")) {
/*    */       
/* 31 */       CommonProxy.trailTicker.patronList.add(s);
/* 32 */       s = ByteBufUtils.readUTF8String(buffer);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void execute(Side side, EntityPlayer player) {}
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\packet\PacketPatrons.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */