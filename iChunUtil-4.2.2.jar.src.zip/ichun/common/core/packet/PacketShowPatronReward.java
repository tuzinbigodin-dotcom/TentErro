/*    */ package ichun.common.core.packet;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import ichun.common.core.network.AbstractPacket;
/*    */ import ichun.common.core.network.PacketHandler;
/*    */ import ichun.common.iChunUtil;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class PacketShowPatronReward
/*    */   extends AbstractPacket
/*    */ {
/*    */   public boolean show;
/*    */   
/*    */   public PacketShowPatronReward() {}
/*    */   
/*    */   public PacketShowPatronReward(boolean show) {
/* 18 */     this.show = show;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeTo(ByteBuf buffer, Side side) {
/* 24 */     buffer.writeBoolean(this.show);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void readFrom(ByteBuf buffer, Side side) {
/* 30 */     this.show = buffer.readBoolean();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute(Side side, EntityPlayer player) {
/* 36 */     if (this.show) {
/*    */       
/* 38 */       iChunUtil.patronList.add(player.func_146103_bH().getId().toString());
/*    */     }
/*    */     else {
/*    */       
/* 42 */       iChunUtil.patronList.remove(player.func_146103_bH().getId().toString());
/*    */     } 
/*    */     
/* 45 */     PacketHandler.sendToAll(iChunUtil.channels, new PacketPatrons());
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\packet\PacketShowPatronReward.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */