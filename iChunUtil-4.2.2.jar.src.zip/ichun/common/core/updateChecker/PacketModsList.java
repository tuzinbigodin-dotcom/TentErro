/*    */ package ichun.common.core.updateChecker;
/*    */ 
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import ichun.common.core.CommonProxy;
/*    */ import ichun.common.core.network.AbstractPacket;
/*    */ import ichun.common.iChunUtil;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ public class PacketModsList
/*    */   extends AbstractPacket
/*    */ {
/*    */   public int id;
/*    */   public boolean isOp;
/*    */   
/*    */   public PacketModsList() {}
/*    */   
/*    */   public PacketModsList(int i, boolean op) {
/* 22 */     this.id = i;
/* 23 */     this.isOp = op;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeTo(ByteBuf buffer, Side side) {
/* 29 */     buffer.writeInt(this.id);
/* 30 */     buffer.writeBoolean(this.isOp);
/* 31 */     ModVersionChecker.writeToBuffer(buffer);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void readFrom(ByteBuf buffer, Side side) {
/* 37 */     this.id = buffer.readInt();
/* 38 */     this.isOp = buffer.readBoolean();
/* 39 */     HashMap<String, String> versions = new HashMap<String, String>();
/* 40 */     String name = ByteBufUtils.readUTF8String(buffer);
/* 41 */     while (!name.equalsIgnoreCase("##endPacket")) {
/*    */       
/* 43 */       versions.put(name, ByteBufUtils.readUTF8String(buffer));
/* 44 */       name = ByteBufUtils.readUTF8String(buffer);
/*    */     } 
/*    */     
/* 47 */     if (iChunUtil.config.getInt("versionNotificationTypes") == 1 && !this.isOp) if (CommonProxy.tickHandlerClient.modUpdateNotification != null)
/*    */       {
/* 49 */         CommonProxy.tickHandlerClient.modUpdateNotification.clearModUpdates();
/*    */       }
/*    */     
/* 52 */     if (iChunUtil.config.getInt("versionNotificationTypes") == 0 || (iChunUtil.config.getInt("versionNotificationTypes") == 1 && this.isOp))
/*    */     {
/* 54 */       ModVersionChecker.compareServerVersions(versions);
/*    */     }
/*    */   }
/*    */   
/*    */   public void execute(Side side, EntityPlayer player) {}
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\cor\\updateChecker\PacketModsList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */