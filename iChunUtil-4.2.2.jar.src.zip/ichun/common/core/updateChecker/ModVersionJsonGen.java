/*     */ package ichun.common.core.updateChecker;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModVersionJsonGen
/*     */ {
/*     */   public static void generate() {
/*  13 */     Map<String, Map<String, String>> map = new HashMap<String, Map<String, String>>();
/*     */ 
/*     */ 
/*     */     
/*  17 */     Map<String, String> versions = new HashMap<String, String>();
/*  18 */     map.put("Grinder", versions);
/*  19 */     versions.put("1.7.10", "4.0.0");
/*  20 */     versions.put("1.7", "3.0.0");
/*     */     
/*  22 */     versions = new HashMap<String, String>();
/*  23 */     map.put("BackTools", versions);
/*  24 */     versions.put("1.7.10", "4.0.0");
/*  25 */     versions.put("1.7", "3.0.1");
/*     */     
/*  27 */     versions = new HashMap<String, String>();
/*  28 */     map.put("Doors", versions);
/*  29 */     versions.put("1.7.10", "4.0.1");
/*     */     
/*  31 */     versions = new HashMap<String, String>();
/*  32 */     map.put("Hats", versions);
/*  33 */     versions.put("1.7.10", "4.0.1");
/*  34 */     versions.put("1.7", "3.0.1");
/*     */     
/*  36 */     versions = new HashMap<String, String>();
/*  37 */     map.put("HatStand", versions);
/*  38 */     versions.put("1.7.10", "4.0.0");
/*  39 */     versions.put("1.7", "3.0.0");
/*     */     
/*  41 */     versions = new HashMap<String, String>();
/*  42 */     map.put("iChunUtil", versions);
/*  43 */     versions.put("1.7.10", "4.1.3");
/*  44 */     versions.put("1.7", "3.3.0");
/*     */     
/*  46 */     versions = new HashMap<String, String>();
/*  47 */     map.put("ItFellFromTheSky", versions);
/*  48 */     versions.put("1.7.10", "4.0.0");
/*  49 */     versions.put("1.7", "3.0.0");
/*     */     
/*  51 */     versions = new HashMap<String, String>();
/*  52 */     map.put("MobAmputation", versions);
/*  53 */     versions.put("1.7.10", "4.0.0");
/*  54 */     versions.put("1.7", "3.0.1");
/*     */     
/*  56 */     versions = new HashMap<String, String>();
/*  57 */     map.put("MobDismemberment", versions);
/*  58 */     versions.put("1.7.10", "4.0.0");
/*  59 */     versions.put("1.7", "3.0.1");
/*     */     
/*  61 */     versions = new HashMap<String, String>();
/*  62 */     map.put("Morph", versions);
/*  63 */     versions.put("1.7.10", "0.9.1");
/*  64 */     versions.put("1.7", "0.8.1");
/*     */     
/*  66 */     versions = new HashMap<String, String>();
/*  67 */     map.put("PiP", versions);
/*  68 */     versions.put("1.7.10", "4.0.0");
/*  69 */     versions.put("1.7", "3.0.4");
/*     */     
/*  71 */     versions = new HashMap<String, String>();
/*  72 */     map.put("Photoreal", versions);
/*  73 */     versions.put("1.7.10", "4.0.0");
/*  74 */     versions.put("1.7", "3.0.0");
/*     */     
/*  76 */     versions = new HashMap<String, String>();
/*  77 */     map.put("Shatter", versions);
/*  78 */     versions.put("1.7.10", "4.0.0");
/*  79 */     versions.put("1.7", "3.0.0");
/*     */     
/*  81 */     versions = new HashMap<String, String>();
/*  82 */     map.put("Streak", versions);
/*  83 */     versions.put("1.7.10", "4.0.0");
/*  84 */     versions.put("1.7", "3.0.0");
/*     */     
/*  86 */     versions = new HashMap<String, String>();
/*  87 */     map.put("Sync", versions);
/*  88 */     versions.put("1.7.10", "4.0.0");
/*  89 */     versions.put("1.7", "3.0.1");
/*     */     
/*  91 */     versions = new HashMap<String, String>();
/*  92 */     map.put("Tabula", versions);
/*  93 */     versions.put("1.7.10", "4.1.0");
/*     */     
/*  95 */     versions = new HashMap<String, String>();
/*  96 */     map.put("Torched", versions);
/*  97 */     versions.put("1.7.10", "4.0.0");
/*  98 */     versions.put("1.7", "3.0.1");
/*     */     
/* 100 */     versions = new HashMap<String, String>();
/* 101 */     map.put("TrailMix", versions);
/* 102 */     versions.put("1.7.10", "4.0.0");
/* 103 */     versions.put("1.7", "3.0.2");
/*     */     
/* 105 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 106 */     String jsonOutput = gson.toJson(map);
/*     */     
/* 108 */     System.out.println(jsonOutput);
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\cor\\updateChecker\ModVersionJsonGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */