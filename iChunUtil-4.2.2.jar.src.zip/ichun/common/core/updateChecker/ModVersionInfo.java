/*    */ package ichun.common.core.updateChecker;
/*    */ 
/*    */ import cpw.mods.fml.common.versioning.DefaultArtifactVersion;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModVersionInfo
/*    */ {
/*    */   public final String modName;
/*    */   public final String mcVersion;
/*    */   public final String modVersion;
/*    */   public final boolean sided;
/*    */   public String newModVersion;
/*    */   
/*    */   public ModVersionInfo(String modName, String mcVersion, String modVersion, boolean sided) {
/* 19 */     this.modName = modName;
/* 20 */     this.mcVersion = mcVersion;
/* 21 */     this.modVersion = modVersion;
/* 22 */     this.sided = sided;
/* 23 */     this.newModVersion = modVersion;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean processAndReturnHasUpdate(Map<String, String> map) {
/* 32 */     DefaultArtifactVersion defaultArtifactVersion1 = new DefaultArtifactVersion(this.modVersion);
/*    */     
/* 34 */     String lat = map.get(this.mcVersion);
/* 35 */     DefaultArtifactVersion defaultArtifactVersion2 = new DefaultArtifactVersion(lat);
/*    */     
/* 37 */     int diff = defaultArtifactVersion2.compareTo(defaultArtifactVersion1);
/*    */     
/* 39 */     if (diff > 0) {
/*    */       
/* 41 */       this.newModVersion = lat.trim();
/* 42 */       return true;
/*    */     } 
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isVersionOutdated(String version) {
/* 49 */     DefaultArtifactVersion defaultArtifactVersion1 = new DefaultArtifactVersion(version);
/*    */     
/* 51 */     DefaultArtifactVersion defaultArtifactVersion2 = new DefaultArtifactVersion(this.newModVersion);
/*    */     
/* 53 */     int diff = defaultArtifactVersion2.compareTo(defaultArtifactVersion1);
/*    */     
/* 55 */     return (diff > 0 || !this.modVersion.equals(this.newModVersion));
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\cor\\updateChecker\ModVersionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */