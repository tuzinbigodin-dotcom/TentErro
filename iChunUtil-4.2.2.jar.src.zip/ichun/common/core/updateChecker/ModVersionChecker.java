/*     */ package ichun.common.core.updateChecker;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import cpw.mods.fml.common.network.ByteBufUtils;
/*     */ import ichun.common.core.CommonProxy;
/*     */ import ichun.common.core.util.EventCalendar;
/*     */ import ichun.common.iChunUtil;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraftforge.common.config.Property;
/*     */ 
/*     */ public class ModVersionChecker
/*     */ {
/*     */   private static final String iChunJsonURL = "https://raw.github.com/iChun/iChunUtil/master/src/main/resources/assets/ichunutil/mod/versions.json";
/*  21 */   private static HashMap<String, ArrayList<ModVersionInfo>> urlsToCheck = new HashMap<String, ArrayList<ModVersionInfo>>();
/*     */ 
/*     */   
/*     */   private static boolean init = false;
/*     */ 
/*     */   
/*     */   public static boolean differentDay;
/*     */ 
/*     */   
/*     */   public static void init() {
/*  31 */     if (!init)
/*     */     {
/*  33 */       (new Thread("iChunUtil Mod Version Check")
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void run()
/*     */           {
/*     */             try {
/*  41 */               for (Map.Entry<String, ArrayList<ModVersionInfo>> e : (Iterable<Map.Entry<String, ArrayList<ModVersionInfo>>>)ModVersionChecker.urlsToCheck.entrySet()) {
/*     */                 Reader fileIn;
/*  43 */                 Gson gson = new Gson();
/*     */ 
/*     */                 
/*     */                 try {
/*  47 */                   fileIn = new InputStreamReader((new URL(e.getKey())).openStream());
/*     */                 }
/*  49 */                 catch (Exception e1) {
/*     */                   
/*  51 */                   fileIn = null;
/*  52 */                   e1.printStackTrace();
/*     */                 } 
/*  54 */                 if (fileIn != null) {
/*     */                   
/*  56 */                   Map<String, Object> json = (Map<String, Object>)gson.fromJson(fileIn, Map.class);
/*  57 */                   for (ModVersionInfo info : e.getValue())
/*     */                   {
/*  59 */                     Map<String, String> versionInfo = (Map<String, String>)json.get(info.modName);
/*  60 */                     if (versionInfo != null && info.processAndReturnHasUpdate(versionInfo))
/*     */                     {
/*  62 */                       iChunUtil.proxy.notifyNewUpdate(info.modName, info.newModVersion);
/*     */                     }
/*     */                   }
/*     */                 
/*     */                 } 
/*     */               } 
/*  68 */             } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */             
/*  72 */             ModVersionChecker.differentDay = (((Property)iChunUtil.config.props.get("dayCheck")).getInt() != EventCalendar.day);
/*  73 */             ((Property)iChunUtil.config.props.get("dayCheck")).set(EventCalendar.day);
/*     */             
/*  75 */             StringBuilder sb = new StringBuilder();
/*  76 */             ArrayList<String> names = new ArrayList<String>();
/*  77 */             for (Map.Entry<String, String> e : (Iterable<Map.Entry<String, String>>)CommonProxy.versionChecker.entrySet())
/*     */             {
/*  79 */               names.add(e.getKey());
/*     */             }
/*  81 */             Collections.sort(names);
/*     */             
/*  83 */             for (int i = 0; i < names.size(); i++) {
/*     */               
/*  85 */               sb.append(names.get(i));
/*  86 */               sb.append(": ");
/*  87 */               sb.append((String)CommonProxy.versionChecker.get(names.get(i)));
/*  88 */               if (names.size() - 1 != i)
/*     */               {
/*  90 */                 sb.append(", ");
/*     */               }
/*     */             } 
/*  93 */             ((Property)iChunUtil.config.props.get("lastCheck")).set(sb.toString());
/*     */             
/*  95 */             iChunUtil.config.save();
/*     */           }
/*  97 */         }).start();
/*     */     }
/*  99 */     init = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerModVersionToCheck(String url, ModVersionInfo info) {
/* 109 */     ArrayList<ModVersionInfo> list = getArrayListForURL(url);
/* 110 */     list.add(info);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register_iChunMod(ModVersionInfo info) {
/* 119 */     ArrayList<ModVersionInfo> list = getArrayListForURL("https://raw.github.com/iChun/iChunUtil/master/src/main/resources/assets/ichunutil/mod/versions.json");
/* 120 */     list.add(info);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ArrayList<ModVersionInfo> getListOf_iChunMods() {
/* 125 */     return getArrayListForURL("https://raw.github.com/iChun/iChunUtil/master/src/main/resources/assets/ichunutil/mod/versions.json");
/*     */   }
/*     */ 
/*     */   
/*     */   private static ArrayList<ModVersionInfo> getArrayListForURL(String url) {
/* 130 */     ArrayList<ModVersionInfo> list = urlsToCheck.get(url);
/* 131 */     if (list == null) {
/*     */       
/* 133 */       list = new ArrayList<ModVersionInfo>();
/* 134 */       urlsToCheck.put(url, list);
/*     */     } 
/* 136 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void writeToBuffer(ByteBuf buffer) {
/* 141 */     for (Map.Entry<String, ArrayList<ModVersionInfo>> e : urlsToCheck.entrySet()) {
/*     */       
/* 143 */       for (ModVersionInfo info : e.getValue()) {
/*     */         
/* 145 */         ByteBufUtils.writeUTF8String(buffer, info.modName);
/* 146 */         ByteBufUtils.writeUTF8String(buffer, info.modVersion);
/*     */       } 
/*     */     } 
/* 149 */     ByteBufUtils.writeUTF8String(buffer, "##endPacket");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void compareServerVersions(HashMap<String, String> versions) {
/* 154 */     if (CommonProxy.tickHandlerClient.modUpdateNotification != null)
/*     */     {
/* 156 */       CommonProxy.tickHandlerClient.modUpdateNotification.clearModUpdates();
/*     */     }
/*     */     
/* 159 */     ArrayList<ModVersionInfo> infos = new ArrayList<ModVersionInfo>();
/* 160 */     for (Map.Entry<String, ArrayList<ModVersionInfo>> e : urlsToCheck.entrySet()) {
/*     */       
/* 162 */       for (ModVersionInfo info : e.getValue()) {
/*     */         
/* 164 */         String version = versions.get(info.modName);
/* 165 */         if (version != null && info.isVersionOutdated(version))
/*     */         {
/* 167 */           iChunUtil.proxy.notifyNewUpdate(info.modName, info.newModVersion);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void clearListOfNonSidedMods(ArrayList<String> list) {
/* 175 */     for (int i = list.size() - 1; i >= 0; i--) {
/*     */       
/* 177 */       String modName = list.get(i);
/*     */       
/* 179 */       boolean br = false;
/* 180 */       for (Map.Entry<String, ArrayList<ModVersionInfo>> e : urlsToCheck.entrySet()) {
/*     */         
/* 182 */         for (ModVersionInfo info : e.getValue()) {
/*     */           
/* 184 */           if (modName.startsWith(info.modName) && !info.sided) {
/*     */             
/* 186 */             list.remove(i);
/* 187 */             br = true;
/*     */           } 
/* 189 */           if (br) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 194 */         if (br)
/*     */           break; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\cor\\updateChecker\ModVersionChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */