package ichun.common.core.config;

import net.minecraftforge.common.config.Property;

public interface IConfigUser {
  boolean onConfigChange(Config paramConfig, Property paramProperty);
}


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\config\IConfigUser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */