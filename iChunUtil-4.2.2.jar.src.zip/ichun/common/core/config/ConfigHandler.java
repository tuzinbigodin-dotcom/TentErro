/*    */ package ichun.common.core.config;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import net.minecraftforge.common.config.Configuration;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ public class ConfigHandler
/*    */ {
/* 12 */   public static ArrayList<Config> configs = new ArrayList<Config>();
/*    */ 
/*    */   
/*    */   public static Config createConfig(File file, String modIdName, String modName, Logger logger, IConfigUser parent) {
/* 16 */     Configuration cfg = new Configuration(file);
/* 17 */     cfg.load();
/* 18 */     Config config = new Config(cfg, modIdName, modName, logger, parent);
/* 19 */     configs.add(config);
/* 20 */     Collections.sort(configs);
/* 21 */     return config;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\config\ConfigHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */