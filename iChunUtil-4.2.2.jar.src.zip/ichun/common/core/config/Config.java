/*     */ package ichun.common.core.config;
/*     */ 
/*     */ import com.google.common.base.Splitter;
/*     */ import cpw.mods.fml.common.FMLCommonHandler;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import ichun.client.keybind.KeyBind;
/*     */ import ichun.common.iChunUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ import net.minecraftforge.common.config.Property;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class Config implements Comparable {
/*  22 */   public static int printKey = -1;
/*  23 */   public static String curMod = "sync";
/*     */   
/*     */   public static Configuration configKeybind;
/*     */   
/*     */   public final Configuration config;
/*     */   
/*     */   public final String modId;
/*     */   
/*     */   public final String modName;
/*     */   public final Logger logger;
/*     */   public final IConfigUser parent;
/*     */   public String currentCat;
/*     */   public String currentCatName;
/*  36 */   public HashMap<String, Property> props = new HashMap<String, Property>();
/*  37 */   public HashMap<Property, String> propName = new HashMap<Property, String>();
/*  38 */   public HashMap<String, String> propNameToProp = new HashMap<String, String>();
/*  39 */   public HashMap<Property, int[]> minmax = (HashMap)new HashMap<Property, int>();
/*  40 */   public HashMap<Property, int[]> nestedMinmax = (HashMap)new HashMap<Property, int>();
/*  41 */   public ArrayList<Property> sessionProps = new ArrayList<Property>();
/*     */   
/*  43 */   public HashMap<String, ArrayList<Property>> categories = new HashMap<String, ArrayList<Property>>();
/*  44 */   public ArrayList<String> categoriesList = new ArrayList<String>();
/*     */   
/*  46 */   public HashMap<Property, EnumPropType> propType = new HashMap<Property, EnumPropType>();
/*     */   
/*  48 */   public HashMap<String, KeyBind> keyBindMap = new HashMap<String, KeyBind>();
/*     */   
/*  50 */   public ArrayList<Property> propNeedsRestart = new ArrayList<Property>();
/*  51 */   public ArrayList<String> unfound = new ArrayList<String>();
/*     */   
/*  53 */   public EnumMap<Side, HashMap<String, Object>> sessionState = new EnumMap<Side, HashMap<String, Object>>(Side.class)
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean setup;
/*     */ 
/*     */ 
/*     */   
/*     */   public Config(Configuration cfg, String ModId, String ModName, Logger lg, IConfigUser configParent) {
/*  65 */     this.config = cfg;
/*  66 */     this.modId = ModId;
/*  67 */     this.modName = ModName;
/*  68 */     this.logger = lg;
/*  69 */     this.setup = false;
/*  70 */     this.parent = configParent;
/*     */     
/*  72 */     this.currentCat = "general";
/*  73 */     this.currentCatName = StatCollector.func_74838_a("ichun.config.cat.general.name");
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetSession() {
/*  78 */     ((HashMap)this.sessionState.get(FMLCommonHandler.instance().getEffectiveSide())).clear();
/*  79 */     for (Property prop : this.sessionProps)
/*     */     {
/*  81 */       ((HashMap)this.sessionState.get(FMLCommonHandler.instance().getEffectiveSide())).put(prop.getName(), (prop.getType() == Property.Type.INTEGER) ? Integer.valueOf(prop.getInt()) : prop.getString());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateSession(String s, Object obj) {
/*  87 */     ((HashMap<String, Object>)this.sessionState.get(FMLCommonHandler.instance().getEffectiveSide())).put(s, obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public Property get(String s) {
/*  92 */     if (!this.props.containsKey(s) && !this.unfound.contains(s)) {
/*     */       
/*  94 */       this.unfound.add(s);
/*  95 */       if (this.logger != null)
/*     */       {
/*  97 */         this.logger.log(Level.WARN, "Tried to reference unknown property: " + s);
/*     */       }
/*     */     } 
/* 100 */     return this.props.get(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(String s) {
/* 105 */     Property prop = get(s);
/* 106 */     if (prop != null && prop.getType() == Property.Type.INTEGER)
/*     */     {
/* 108 */       return prop.getInt();
/*     */     }
/* 110 */     if (this.logger != null && !this.unfound.contains(s)) {
/*     */       
/* 112 */       this.unfound.add(s);
/* 113 */       this.logger.log(Level.WARN, "Tried to reference non-int property as int: " + s);
/*     */     } 
/* 115 */     return -2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String s) {
/* 120 */     Property prop = get(s);
/* 121 */     if (prop != null && prop.getType() == Property.Type.STRING)
/*     */     {
/* 123 */       return prop.getString();
/*     */     }
/* 125 */     if (this.logger != null && !this.unfound.contains(s)) {
/*     */       
/* 127 */       this.unfound.add(s);
/* 128 */       this.logger.log(Level.WARN, "Tried to reference non-string property as string: " + s);
/*     */     } 
/* 130 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public HashMap<String, ArrayList<String>> getStringArray(String s) {
/* 135 */     HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();
/*     */     
/* 137 */     String s1 = getString(s);
/*     */     
/* 139 */     String[] split = s1.split(", *");
/*     */     
/* 141 */     if (split.length > 0 && !split[0].equalsIgnoreCase(""))
/*     */     {
/* 143 */       for (String splits : split) {
/*     */         
/* 145 */         String[] split1 = splits.split(": *");
/* 146 */         if (split1.length > 0 && !split1[0].equalsIgnoreCase(""))
/*     */         {
/* 148 */           if (split1.length == 1) {
/*     */             
/* 150 */             map.put(split1[0], new ArrayList<String>());
/*     */           }
/*     */           else {
/*     */             
/* 154 */             ArrayList<String> strings = new ArrayList<String>();
/* 155 */             for (int i = 1; i < split1.length; i++)
/*     */             {
/* 157 */               strings.add(split1[i]);
/*     */             }
/* 159 */             map.put(split1[0], strings);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/* 164 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyBind getKeyBind(String s) {
/* 169 */     KeyBind bind = this.keyBindMap.get(s);
/* 170 */     if (bind != null)
/*     */     {
/* 172 */       return bind;
/*     */     }
/* 174 */     bind = new KeyBind(0, false, false, false, false);
/* 175 */     this.keyBindMap.put(s, bind);
/*     */     
/* 177 */     if (this.logger != null && !this.unfound.contains(s)) {
/*     */       
/* 179 */       this.unfound.add(s);
/* 180 */       this.logger.log(Level.WARN, "Tried to reference non-existent keybind: " + s);
/*     */     } 
/*     */     
/* 183 */     return bind;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<Integer> getIntArray(String s) {
/* 188 */     Property prop = get(s);
/* 189 */     if (prop != null && prop.getType() == Property.Type.STRING)
/*     */     {
/* 191 */       return parseIntArray(getString(s));
/*     */     }
/* 193 */     if (this.logger != null && !this.unfound.contains(s)) {
/*     */       
/* 195 */       this.unfound.add(s);
/* 196 */       this.logger.log(Level.WARN, "Tried to reference non-string property as string: " + s);
/*     */     } 
/* 198 */     return new ArrayList<Integer>();
/*     */   }
/*     */ 
/*     */   
/*     */   public LinkedHashMap<Integer, ArrayList<Integer>> getNestedIntArray(String s) {
/* 203 */     Property prop = get(s);
/* 204 */     if (prop != null && prop.getType() == Property.Type.STRING)
/*     */     {
/* 206 */       return parseNestedIntArray(getString(s));
/*     */     }
/* 208 */     if (this.logger != null && !this.unfound.contains(s)) {
/*     */       
/* 210 */       this.unfound.add(s);
/* 211 */       this.logger.log(Level.WARN, "Tried to reference non-string property as string: " + s);
/*     */     } 
/* 213 */     return new LinkedHashMap<Integer, ArrayList<Integer>>();
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<Integer> parseIntArray(String s) {
/* 218 */     ArrayList<Integer> list = new ArrayList<Integer>();
/*     */     
/* 220 */     String[] split = s.split(", *");
/*     */     
/* 222 */     if (split.length > 0 && !split[0].equalsIgnoreCase(""))
/*     */     {
/* 224 */       for (String splits : split) {
/*     */ 
/*     */         
/*     */         try {
/* 228 */           Integer i = Integer.valueOf(Integer.parseInt(splits));
/* 229 */           list.add(i);
/*     */         }
/* 231 */         catch (NumberFormatException e) {
/*     */           
/* 233 */           if (this.logger != null)
/*     */           {
/* 235 */             this.logger.log(Level.WARN, "Could not parse following as int: " + splits);
/*     */           }
/* 237 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */     }
/* 241 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public LinkedHashMap<Integer, ArrayList<Integer>> parseNestedIntArray(String s) {
/* 246 */     LinkedHashMap<Integer, ArrayList<Integer>> map = new LinkedHashMap<Integer, ArrayList<Integer>>();
/*     */     
/* 248 */     String[] split = s.split(", *");
/*     */     
/* 250 */     if (split.length > 0 && !split[0].equalsIgnoreCase(""))
/*     */     {
/* 252 */       for (String splits : split) {
/*     */         
/* 254 */         String[] split1 = splits.split(": *");
/* 255 */         if (split1.length > 0 && !split1[0].equalsIgnoreCase("")) {
/*     */           
/*     */           try {
/*     */             
/* 259 */             if (split1.length == 1)
/*     */             {
/* 261 */               map.put(Integer.valueOf(Integer.parseInt(split1[0])), new ArrayList<Integer>());
/*     */             }
/*     */             else
/*     */             {
/* 265 */               ArrayList<Integer> ints = new ArrayList<Integer>();
/* 266 */               for (int i = 1; i < split1.length; i++) {
/*     */ 
/*     */                 
/*     */                 try {
/* 270 */                   ints.add(Integer.valueOf(Integer.parseInt(split1[i])));
/*     */                 }
/* 272 */                 catch (NumberFormatException e) {
/*     */                   
/* 274 */                   if (this.logger != null)
/*     */                   {
/* 276 */                     this.logger.log(Level.WARN, "Could not parse following as (nested) int: " + split1[i]);
/*     */                   }
/* 278 */                   e.printStackTrace();
/*     */                 } 
/*     */               } 
/* 281 */               map.put(Integer.valueOf(Integer.parseInt(split1[0])), ints);
/*     */             }
/*     */           
/* 284 */           } catch (NumberFormatException e) {
/*     */             
/* 286 */             if (this.logger != null)
/*     */             {
/* 288 */               this.logger.log(Level.WARN, "Could not parse following as int: " + split1[0]);
/*     */             }
/* 290 */             e.printStackTrace();
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/* 295 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSessionInt(String s) {
/* 300 */     Object obj = ((HashMap)this.sessionState.get(FMLCommonHandler.instance().getEffectiveSide())).get(s);
/* 301 */     if (obj instanceof Integer)
/*     */     {
/* 303 */       return ((Integer)obj).intValue();
/*     */     }
/* 305 */     return -2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSessionString(String s) {
/* 310 */     Object obj = ((HashMap)this.sessionState.get(FMLCommonHandler.instance().getEffectiveSide())).get(s);
/* 311 */     if (obj instanceof String)
/*     */     {
/* 313 */       return (String)obj;
/*     */     }
/* 315 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public HashMap<String, ArrayList<String>> getSessionStringArray(String s) {
/* 320 */     Object obj = ((HashMap)this.sessionState.get(FMLCommonHandler.instance().getEffectiveSide())).get(s);
/* 321 */     if (obj instanceof HashMap)
/*     */     {
/* 323 */       return (HashMap<String, ArrayList<String>>)obj;
/*     */     }
/* 325 */     return new HashMap<String, ArrayList<String>>();
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<Integer> getSessionIntArray(String s) {
/* 330 */     Object obj = ((HashMap)this.sessionState.get(FMLCommonHandler.instance().getEffectiveSide())).get(s);
/* 331 */     if (obj instanceof ArrayList)
/*     */     {
/* 333 */       return (ArrayList<Integer>)obj;
/*     */     }
/* 335 */     return new ArrayList<Integer>();
/*     */   }
/*     */ 
/*     */   
/*     */   public HashMap<Integer, ArrayList<Integer>> getSessionNestedIntArray(String s) {
/* 340 */     Object obj = ((HashMap)this.sessionState.get(FMLCommonHandler.instance().getEffectiveSide())).get(s);
/* 341 */     if (obj instanceof HashMap)
/*     */     {
/* 343 */       return (HashMap<Integer, ArrayList<Integer>>)obj;
/*     */     }
/* 345 */     return new HashMap<Integer, ArrayList<Integer>>();
/*     */   }
/*     */ 
/*     */   
/*     */   private void addToCategory(String catName, Property prop) {
/*     */     ArrayList<Property> categoryList;
/* 351 */     if ((catName != null && this.categories.containsKey(catName)) || (catName == null && this.categories.containsKey("uncat"))) {
/*     */       
/* 353 */       categoryList = this.categories.get((catName != null) ? catName : "uncat");
/*     */     }
/*     */     else {
/*     */       
/* 357 */       categoryList = new ArrayList<Property>();
/* 358 */       this.categories.put((catName != null) ? catName : "uncat", categoryList);
/*     */     } 
/* 360 */     if (!categoryList.contains(prop))
/*     */     {
/* 362 */       categoryList.add(prop);
/*     */     }
/* 364 */     if (this.setup && !this.categoriesList.contains(catName)) {
/*     */       
/* 366 */       this.categoriesList.add(catName);
/* 367 */       Collections.sort(this.categoriesList);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int createIntProperty(String propName1, boolean changable, boolean isSessionProp, int i, int min, int max) {
/* 373 */     return createIntProperty(propName1, this.modId.toLowerCase() + ".config.prop." + propName1 + ".name", this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment", changable, isSessionProp, i, min, max);
/*     */   }
/*     */   
/*     */   public int createIntProperty(String propName1, String fullPropName, String comment, boolean changable, boolean isSessionProp, int i, int min, int max) {
/*     */     Property prop;
/* 378 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 2)
/* 379 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".name=" + fullPropName); 
/* 380 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 3)
/* 381 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment=" + comment); 
/* 382 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 4) {
/* 383 */       System.out.println("config.createIntProperty(\"" + propName1 + "\", \"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".name\", " + "\"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment\", " + Boolean.toString(changable) + ", " + Boolean.toString(isSessionProp) + ", " + Integer.toString(i) + ", " + ((min == Integer.MIN_VALUE) ? "Integer.MIN_VALUE" : Integer.toString(min)) + ", " + ((max == Integer.MAX_VALUE) ? "Integer.MAX_VALUE" : Integer.toString(max)) + ");");
/*     */     }
/*     */     
/* 386 */     if (this.props.containsKey(propName1)) {
/*     */       
/* 388 */       prop = this.props.get(propName1);
/* 389 */       prop.set(i);
/*     */     }
/*     */     else {
/*     */       
/* 393 */       prop = this.config.get(this.currentCat, propName1, i);
/* 394 */       if (prop.getInt() > max)
/*     */       {
/* 396 */         prop.set(max);
/*     */       }
/* 398 */       if (prop.getInt() < min)
/*     */       {
/* 400 */         prop.set(min);
/*     */       }
/*     */     } 
/*     */     
/* 404 */     if (!comment.equalsIgnoreCase("")) {
/*     */       
/* 406 */       List<String> cms = Splitter.on("\\n").splitToList(StatCollector.func_74838_a(comment));
/* 407 */       String cm = "";
/* 408 */       for (int ll = 0; ll < cms.size(); ll++) {
/*     */         
/* 410 */         cm = cm + cms.get(ll);
/* 411 */         if (ll != cms.size() - 1)
/*     */         {
/* 413 */           cm = cm + "\n";
/*     */         }
/*     */       } 
/* 416 */       prop.comment = cm + "\n" + ((min != Integer.MIN_VALUE) ? ("\nMin: " + min) : "") + ((max != Integer.MAX_VALUE) ? ("\nMax: " + max) : "");
/*     */     } 
/*     */     
/* 419 */     this.props.put(propName1, prop);
/* 420 */     this.propName.put(prop, fullPropName);
/* 421 */     this.propNameToProp.put(fullPropName, propName1);
/* 422 */     this.minmax.put(prop, new int[] { min, max });
/*     */     
/* 424 */     this.propType.put(prop, EnumPropType.INT);
/*     */     
/* 426 */     if (!changable && !this.propNeedsRestart.contains(prop))
/*     */     {
/* 428 */       this.propNeedsRestart.add(prop);
/*     */     }
/* 430 */     if (isSessionProp && !this.sessionProps.contains(prop))
/*     */     {
/* 432 */       this.sessionProps.add(prop);
/*     */     }
/*     */     
/* 435 */     addToCategory(this.currentCatName, prop);
/*     */     
/* 437 */     save();
/*     */     
/* 439 */     return prop.getInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public int createIntBoolProperty(String propName1, boolean changable, boolean isSessionProp, boolean flag) {
/* 444 */     return createIntBoolProperty(propName1, this.modId.toLowerCase() + ".config.prop." + propName1 + ".name", this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment", changable, isSessionProp, flag);
/*     */   }
/*     */   
/*     */   public int createIntBoolProperty(String propName1, String fullPropName, String comment, boolean changable, boolean isSessionProp, boolean flag) {
/*     */     Property prop;
/* 449 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 2)
/* 450 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".name=" + fullPropName); 
/* 451 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 3)
/* 452 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment=" + comment); 
/* 453 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 4) {
/* 454 */       System.out.println("config.createIntBoolProperty(\"" + propName1 + "\", \"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".name\", " + "\"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment\", " + Boolean.toString(changable) + ", " + Boolean.toString(isSessionProp) + ", " + Boolean.toString(flag) + ");");
/*     */     }
/*     */     
/* 457 */     if (this.props.containsKey(propName1)) {
/*     */       
/* 459 */       prop = this.props.get(propName1);
/* 460 */       prop.set(flag ? 1 : 0);
/*     */     }
/*     */     else {
/*     */       
/* 464 */       prop = this.config.get(this.currentCat, propName1, flag ? 1 : 0);
/* 465 */       if (prop.getInt() > 1)
/*     */       {
/* 467 */         prop.set(1);
/*     */       }
/* 469 */       if (prop.getInt() < 0)
/*     */       {
/* 471 */         prop.set(0);
/*     */       }
/*     */     } 
/*     */     
/* 475 */     if (!comment.equalsIgnoreCase("")) {
/*     */       
/* 477 */       List<String> cms = Splitter.on("\\n").splitToList(StatCollector.func_74838_a(comment));
/* 478 */       String cm = "";
/* 479 */       for (int ll = 0; ll < cms.size(); ll++) {
/*     */         
/* 481 */         cm = cm + cms.get(ll);
/* 482 */         if (ll != cms.size() - 1)
/*     */         {
/* 484 */           cm = cm + "\n";
/*     */         }
/*     */       } 
/* 487 */       prop.comment = cm + "\n\nMin: 0\nMax: 1";
/*     */     } 
/*     */     
/* 490 */     this.props.put(propName1, prop);
/* 491 */     this.propName.put(prop, fullPropName);
/* 492 */     this.propNameToProp.put(fullPropName, propName1);
/* 493 */     this.minmax.put(prop, new int[] { 0, 1 });
/*     */     
/* 495 */     this.propType.put(prop, EnumPropType.INT_BOOL);
/*     */     
/* 497 */     if (!changable && !this.propNeedsRestart.contains(prop))
/*     */     {
/* 499 */       this.propNeedsRestart.add(prop);
/*     */     }
/* 501 */     if (isSessionProp && !this.sessionProps.contains(prop))
/*     */     {
/* 503 */       this.sessionProps.add(prop);
/*     */     }
/*     */     
/* 506 */     addToCategory(this.currentCatName, prop);
/*     */     
/* 508 */     save();
/*     */     
/* 510 */     return prop.getInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public int createColourProperty(String propName1, boolean changable, boolean isSessionProp, int colour) {
/* 515 */     return createColourProperty(propName1, this.modId.toLowerCase() + ".config.prop." + propName1 + ".name", this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment", changable, isSessionProp, colour);
/*     */   }
/*     */   
/*     */   public int createColourProperty(String propName1, String fullPropName, String comment, boolean changable, boolean isSessionProp, int colour) {
/*     */     Property prop;
/* 520 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 2)
/* 521 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".name=" + fullPropName); 
/* 522 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 3)
/* 523 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment=" + comment); 
/* 524 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 4) {
/* 525 */       System.out.println("config.createColourProperty(\"" + propName1 + "\", \"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".name\", " + "\"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment\", " + Boolean.toString(changable) + ", " + Boolean.toString(isSessionProp) + ", " + Integer.toHexString(colour) + ");");
/*     */     }
/*     */     
/* 528 */     if (this.props.containsKey(propName1)) {
/*     */       
/* 530 */       prop = this.props.get(propName1);
/* 531 */       prop.set("#" + Integer.toHexString(colour));
/*     */     }
/*     */     else {
/*     */       
/* 535 */       prop = this.config.get(this.currentCat, propName1, "#" + Integer.toHexString(colour));
/*     */ 
/*     */       
/*     */       try {
/* 539 */         Integer.decode(prop.getString().trim());
/*     */       }
/* 541 */       catch (NumberFormatException e) {
/*     */         
/* 543 */         if (this.logger != null)
/*     */         {
/* 545 */           this.logger.log(Level.WARN, "Could not parse following as colour code, setting as default: " + prop.getString());
/*     */         }
/* 547 */         e.printStackTrace();
/*     */         
/* 549 */         prop.set("#" + Integer.toHexString(colour));
/*     */       } 
/*     */     } 
/*     */     
/* 553 */     if (!comment.equalsIgnoreCase("")) {
/*     */       
/* 555 */       List<String> cms = Splitter.on("\\n").splitToList(StatCollector.func_74838_a(comment));
/* 556 */       String cm = "";
/* 557 */       for (int ll = 0; ll < cms.size(); ll++) {
/*     */         
/* 559 */         cm = cm + cms.get(ll);
/* 560 */         if (ll != cms.size() - 1)
/*     */         {
/* 562 */           cm = cm + "\n";
/*     */         }
/*     */       } 
/* 565 */       prop.comment = cm;
/*     */     } 
/*     */     
/* 568 */     this.props.put(propName1, prop);
/* 569 */     this.propName.put(prop, fullPropName);
/* 570 */     this.propNameToProp.put(fullPropName, propName1);
/*     */     
/* 572 */     this.propType.put(prop, EnumPropType.COLOUR);
/*     */     
/* 574 */     if (!changable && !this.propNeedsRestart.contains(prop))
/*     */     {
/* 576 */       this.propNeedsRestart.add(prop);
/*     */     }
/* 578 */     if (isSessionProp && !this.sessionProps.contains(prop))
/*     */     {
/* 580 */       this.sessionProps.add(prop);
/*     */     }
/*     */     
/* 583 */     addToCategory(this.currentCatName, prop);
/*     */     
/* 585 */     save();
/*     */     
/* 587 */     return Integer.decode(prop.getString().trim()).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String createStringProperty(String propName1, boolean changable, boolean isSessionProp, String value) {
/* 592 */     return createStringProperty(propName1, this.modId.toLowerCase() + ".config.prop." + propName1 + ".name", this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment", changable, isSessionProp, value);
/*     */   }
/*     */   
/*     */   public String createStringProperty(String propName1, String fullPropName, String comment, boolean changable, boolean isSessionProp, String value) {
/*     */     Property prop;
/* 597 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 2)
/* 598 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".name=" + fullPropName); 
/* 599 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 3)
/* 600 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment=" + comment); 
/* 601 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 4) {
/* 602 */       System.out.println("config.createStringProperty(\"" + propName1 + "\", \"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".name\", " + "\"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment\", " + Boolean.toString(changable) + ", " + Boolean.toString(isSessionProp) + ", \"" + value + "\");");
/*     */     }
/*     */     
/* 605 */     if (this.props.containsKey(propName1)) {
/*     */       
/* 607 */       prop = this.props.get(propName1);
/* 608 */       prop.set(value);
/*     */     }
/*     */     else {
/*     */       
/* 612 */       prop = this.config.get(this.currentCat, propName1, value);
/*     */     } 
/*     */     
/* 615 */     if (!comment.equalsIgnoreCase("")) {
/*     */       
/* 617 */       List<String> cms = Splitter.on("\\n").splitToList(StatCollector.func_74838_a(comment));
/* 618 */       String cm = "";
/* 619 */       for (int ll = 0; ll < cms.size(); ll++) {
/*     */         
/* 621 */         cm = cm + cms.get(ll);
/* 622 */         if (ll != cms.size() - 1)
/*     */         {
/* 624 */           cm = cm + "\n";
/*     */         }
/*     */       } 
/* 627 */       prop.comment = cm;
/*     */     } 
/*     */     
/* 630 */     this.props.put(propName1, prop);
/* 631 */     this.propName.put(prop, fullPropName);
/* 632 */     this.propNameToProp.put(fullPropName, propName1);
/*     */     
/* 634 */     this.propType.put(prop, EnumPropType.STRING);
/*     */     
/* 636 */     if (!changable && !this.propNeedsRestart.contains(prop))
/*     */     {
/* 638 */       this.propNeedsRestart.add(prop);
/*     */     }
/* 640 */     if (isSessionProp && !this.sessionProps.contains(prop))
/*     */     {
/* 642 */       this.sessionProps.add(prop);
/*     */     }
/*     */     
/* 645 */     addToCategory(this.currentCatName, prop);
/*     */     
/* 647 */     save();
/*     */     
/* 649 */     return prop.getString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Property createKeybindProperty(String propName1, int keyValue, boolean holdShift, boolean holdCtrl, boolean holdAlt, boolean canPulse, int pulseTime, boolean ignoreHold) {
/* 654 */     return createKeybindProperty(propName1, this.modId.toLowerCase() + ".config.prop." + propName1 + ".name", this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment", keyValue, holdShift, holdCtrl, holdAlt, canPulse, pulseTime, ignoreHold);
/*     */   } public Property createKeybindProperty(String propName1, String fullPropName, String comment, int keyValue, boolean holdShift, boolean holdCtrl, boolean holdAlt, boolean canPulse, int pulseTime, boolean ignoreHold) {
/*     */     Property prop;
/*     */     ArrayList<Property> categoryList;
/*     */     KeyBind bind;
/* 659 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 2)
/* 660 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".name=" + fullPropName); 
/* 661 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 3)
/* 662 */       System.out.println(this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment=" + comment); 
/* 663 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 4) {
/* 664 */       System.out.println("config.createKeybindProperty(\"" + propName1 + "\", \"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".name\", " + "\"" + this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment\", " + Integer.toString(keyValue) + ", " + Boolean.toString(holdShift) + ", " + Boolean.toString(holdCtrl) + ", " + Boolean.toString(holdAlt) + ", " + Boolean.toString(canPulse) + ", " + Integer.toString(pulseTime) + ", " + Boolean.toString(ignoreHold) + ");");
/*     */     }
/*     */ 
/*     */     
/* 668 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 670 */     sb.append(keyValue);
/*     */     
/* 672 */     if (holdShift)
/*     */     {
/* 674 */       sb.append(":SHIFT");
/*     */     }
/* 676 */     if (holdCtrl)
/*     */     {
/* 678 */       sb.append(":CTRL");
/*     */     }
/* 680 */     if (holdAlt)
/*     */     {
/* 682 */       sb.append(":ALT");
/*     */     }
/*     */     
/* 685 */     if (this.props.containsKey(propName1)) {
/*     */       
/* 687 */       prop = this.props.get(propName1);
/* 688 */       prop.set(sb.toString());
/*     */     }
/*     */     else {
/*     */       
/* 692 */       List<String> cms = Splitter.on("\\n").splitToList(StatCollector.func_74838_a("ichun.config.keybind.comment"));
/* 693 */       String cm = "";
/* 694 */       for (int ll = 0; ll < cms.size(); ll++) {
/*     */         
/* 696 */         cm = cm + cms.get(ll);
/* 697 */         if (ll != cms.size() - 1)
/*     */         {
/* 699 */           cm = cm + "\n";
/*     */         }
/*     */       } 
/* 702 */       configKeybind.addCustomCategoryComment("keybinds", cm);
/* 703 */       prop = configKeybind.get("keybinds." + this.modName, propName1, sb.toString());
/*     */       
/* 705 */       if (prop.getString() != sb.toString()) {
/*     */         
/* 707 */         String[] arrayOfString = prop.getString().split(":");
/* 708 */         if (arrayOfString.length == 0) {
/*     */           
/* 710 */           iChunUtil.console("Invalid keybind for mod " + this.modName + ": " + fullPropName, true);
/* 711 */           prop.set(sb.toString());
/*     */         } else {
/*     */ 
/*     */           
/*     */           try {
/*     */             
/* 717 */             Integer.parseInt(arrayOfString[0].trim());
/*     */           }
/* 719 */           catch (NumberFormatException e) {
/*     */             
/* 721 */             iChunUtil.console("Invalid key for mod " + this.modName + ": " + fullPropName, true);
/* 722 */             prop.set(sb.toString());
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 728 */     if (!comment.equalsIgnoreCase("")) {
/*     */       
/* 730 */       List<String> cms = Splitter.on("\\n").splitToList(StatCollector.func_74838_a(comment));
/* 731 */       String cm = "";
/* 732 */       for (int ll = 0; ll < cms.size(); ll++) {
/*     */         
/* 734 */         cm = cm + cms.get(ll);
/* 735 */         if (ll != cms.size() - 1)
/*     */         {
/* 737 */           cm = cm + "\n";
/*     */         }
/*     */       } 
/* 740 */       prop.comment = cm;
/*     */     } 
/*     */     
/* 743 */     this.props.put(propName1, prop);
/* 744 */     this.propName.put(prop, fullPropName);
/* 745 */     this.propNameToProp.put(fullPropName, propName1);
/*     */     
/* 747 */     this.propType.put(prop, EnumPropType.KEYBIND);
/*     */ 
/*     */     
/* 750 */     if (this.categories.containsKey("Key Binds")) {
/*     */       
/* 752 */       categoryList = this.categories.get("Key Binds");
/*     */     }
/*     */     else {
/*     */       
/* 756 */       categoryList = new ArrayList<Property>();
/* 757 */       this.categories.put("Key Binds", categoryList);
/*     */     } 
/* 759 */     if (!categoryList.contains(prop))
/*     */     {
/* 761 */       categoryList.add(prop);
/*     */     }
/*     */     
/* 764 */     String keyString = prop.getString();
/* 765 */     String[] strings = keyString.split(":");
/*     */ 
/*     */     
/*     */     try {
/* 769 */       bind = new KeyBind(Integer.parseInt(strings[0].trim()), keyString.contains("SHIFT"), keyString.contains("CTRL"), keyString.contains("ALT"), ignoreHold);
/*     */     }
/* 771 */     catch (Exception e) {
/*     */       
/* 773 */       iChunUtil.console("Error parsing key for mod " + this.modName + ": " + fullPropName, true);
/* 774 */       bind = new KeyBind(keyValue, holdShift, holdCtrl, holdAlt, ignoreHold);
/*     */     } 
/*     */     
/* 777 */     bind.setPulse(canPulse, pulseTime);
/*     */     
/* 779 */     this.keyBindMap.put(propName1, iChunUtil.proxy.registerKeyBind(bind, null));
/*     */     
/* 781 */     save();
/*     */     
/* 783 */     return prop;
/*     */   }
/*     */ 
/*     */   
/*     */   public void createIntArrayProperty(String propName1, boolean changable, boolean isSessionProp, boolean nestedIntArray, String value, int[] minMax, int[] nestedMinMax) {
/* 788 */     createIntArrayProperty(propName1, this.modId.toLowerCase() + ".config.prop." + propName1 + ".name", this.modId.toLowerCase() + ".config.prop." + propName1 + ".comment", changable, isSessionProp, nestedIntArray, value, minMax, nestedMinMax);
/*     */   }
/*     */ 
/*     */   
/*     */   public void createIntArrayProperty(String propName1, String fullPropName, String comment, boolean changable, boolean isSessionProp, boolean nestedIntArray, String value, int[] minMax, int[] nestedMinMax) {
/*     */     Property prop;
/* 794 */     if (this.props.containsKey(propName1)) {
/*     */       
/* 796 */       prop = this.props.get(propName1);
/* 797 */       prop.set(value);
/*     */     }
/*     */     else {
/*     */       
/* 801 */       prop = this.config.get(this.currentCat, propName1, value);
/*     */     } 
/*     */     
/* 804 */     if (!comment.equalsIgnoreCase("")) {
/*     */       
/* 806 */       List<String> cms = Splitter.on("\\n").splitToList(StatCollector.func_74838_a(comment));
/* 807 */       String cm = "";
/* 808 */       for (int ll = 0; ll < cms.size(); ll++) {
/*     */         
/* 810 */         cm = cm + cms.get(ll);
/* 811 */         if (ll != cms.size() - 1)
/*     */         {
/* 813 */           cm = cm + "\n";
/*     */         }
/*     */       } 
/* 816 */       prop.comment = cm;
/*     */     } 
/*     */     
/* 819 */     this.props.put(propName1, prop);
/* 820 */     this.propName.put(prop, fullPropName);
/* 821 */     this.propNameToProp.put(fullPropName, propName1);
/*     */     
/* 823 */     if (nestedIntArray) {
/*     */       
/* 825 */       this.propType.put(prop, EnumPropType.NESTED_INT_ARRAY);
/*     */     }
/*     */     else {
/*     */       
/* 829 */       this.propType.put(prop, EnumPropType.INT_ARRAY);
/*     */     } 
/*     */     
/* 832 */     if (minMax == null || minMax.length != 2)
/*     */     {
/* 834 */       minMax = new int[] { (minMax != null && minMax.length > 0) ? minMax[0] : Integer.MIN_VALUE, (minMax != null && minMax.length > 1) ? minMax[1] : Integer.MAX_VALUE };
/*     */     }
/* 836 */     this.minmax.put(prop, minMax);
/*     */     
/* 838 */     if (nestedIntArray) {
/*     */       
/* 840 */       if (nestedMinMax == null || nestedMinMax.length != 2)
/*     */       {
/* 842 */         nestedMinMax = new int[] { (nestedMinMax != null && nestedMinMax.length > 0) ? nestedMinMax[0] : Integer.MIN_VALUE, (nestedMinMax != null && nestedMinMax.length > 1) ? nestedMinMax[1] : Integer.MAX_VALUE };
/*     */       }
/* 844 */       this.nestedMinmax.put(prop, nestedMinMax);
/*     */     } 
/*     */ 
/*     */     
/* 848 */     if (!changable && !this.propNeedsRestart.contains(prop))
/*     */     {
/* 850 */       this.propNeedsRestart.add(prop);
/*     */     }
/* 852 */     if (isSessionProp && !this.sessionProps.contains(prop))
/*     */     {
/* 854 */       this.sessionProps.add(prop);
/*     */     }
/*     */     
/* 857 */     addToCategory(this.currentCatName, prop);
/*     */     
/* 859 */     save();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentCategory(String cat) {
/* 866 */     setCurrentCategory(cat, this.modId.toLowerCase() + ".config.cat." + cat + ".name", this.modId.toLowerCase() + ".config.cat." + cat + ".comment");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentCategory(String cat, String catName, String comment) {
/* 871 */     this.currentCat = cat;
/* 872 */     this.currentCatName = StatCollector.func_74838_a(catName);
/* 873 */     List<String> cms = Splitter.on("\\n").splitToList(StatCollector.func_74838_a(comment));
/* 874 */     String cm = "";
/* 875 */     for (int ll = 0; ll < cms.size(); ll++) {
/*     */       
/* 877 */       cm = cm + cms.get(ll);
/* 878 */       if (ll != cms.size() - 1)
/*     */       {
/* 880 */         cm = cm + "\n";
/*     */       }
/*     */     } 
/* 883 */     this.config.addCustomCategoryComment(this.currentCat, cm);
/*     */     
/* 885 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 0)
/* 886 */       System.out.println(this.modId.toLowerCase() + ".config.cat." + cat + ".name=" + catName); 
/* 887 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 1)
/* 888 */       System.out.println(this.modId.toLowerCase() + ".config.cat." + cat + ".comment=" + comment); 
/* 889 */     if (this.modId.equalsIgnoreCase(curMod) && printKey == 4) {
/* 890 */       System.out.println("config.setCurrentCategory(\"" + cat + "\", \"" + this.modId.toLowerCase() + ".config.cat." + cat + ".name\", \"" + this.modId.toLowerCase() + ".config.cat." + cat + ".comment\");");
/*     */     }
/*     */   }
/*     */   
/*     */   public void setup() {
/* 895 */     this.categoriesList.clear();
/* 896 */     this.setup = true;
/* 897 */     save();
/*     */     
/* 899 */     for (Map.Entry<String, ArrayList<Property>> e : this.categories.entrySet()) {
/*     */       
/* 901 */       if (!((String)e.getKey()).equals("uncat"))
/*     */       {
/* 903 */         this.categoriesList.add(e.getKey());
/*     */       }
/*     */     } 
/* 906 */     Collections.sort(this.categoriesList);
/*     */   }
/*     */ 
/*     */   
/*     */   public void save() {
/* 911 */     if (this.setup && this.config.hasChanged())
/*     */     {
/* 913 */       this.config.save();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object arg0) {
/* 920 */     if (arg0 instanceof Config) {
/*     */       
/* 922 */       Config cfg = (Config)arg0;
/* 923 */       return this.modName.compareTo(cfg.modName);
/*     */     } 
/* 925 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public EnumPropType getPropType(Property prop) {
/* 930 */     EnumPropType type = this.propType.get(prop);
/* 931 */     if (this.propType == null) {
/*     */       
/* 933 */       iChunUtil.console("Property has no type: " + prop.getName(), true);
/* 934 */       return EnumPropType.UNDEFINED;
/*     */     } 
/* 936 */     return type;
/*     */   }
/*     */   
/*     */   public enum EnumPropType
/*     */   {
/* 941 */     UNDEFINED,
/* 942 */     STRING,
/* 943 */     INT,
/* 944 */     INT_BOOL,
/* 945 */     INT_ARRAY,
/* 946 */     NESTED_INT_ARRAY,
/* 947 */     KEYBIND,
/* 948 */     COLOUR;
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\config\Config.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */