/*     */ package ichun.common.core.techne;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import com.google.gson.annotations.SerializedName;
/*     */ import ichun.common.iChunUtil;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class TC2Info {
/*  32 */   public Techne Techne = new Techne();
/*     */   public transient boolean tampered;
/*     */   
/*     */   public class Techne
/*     */   {
/*     */     @SerializedName("@Version")
/*  38 */     public String Version = "2.2";
/*     */     
/*  40 */     public String Author = "NotZeuX";
/*  41 */     public String Name = "";
/*  42 */     public String PreviewImage = "";
/*  43 */     public String ProjectName = "";
/*  44 */     public String ProjectType = "";
/*  45 */     public String Description = "";
/*  46 */     public String DateCreated = "";
/*  47 */     public TC2Info.Model[] Models = new TC2Info.Model[0];
/*     */     
/*  49 */     private String _comment = "Generated using iChunUtil";
/*     */ 
/*     */     
/*     */     public void createNewModelArray(int size) {
/*  53 */       this.Models = new TC2Info.Model[size];
/*  54 */       for (int i = 0; i < this.Models.length; i++)
/*     */       {
/*  56 */         this.Models[i] = new TC2Info.Model();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public class Model
/*     */   {
/*  63 */     public TC2Info.ModelInfo Model = new TC2Info.ModelInfo();
/*     */   }
/*     */   
/*     */   public class ModelInfo
/*     */   {
/*  68 */     public String GlScale = "1,1,1";
/*  69 */     public String Name = "";
/*  70 */     public String TextureSize = "64,32"; @SerializedName("@texture")
/*  71 */     public String texture = "texture.png";
/*     */     
/*  73 */     public String BaseClass = "ModelBase";
/*  74 */     public TC2Info.Group Geometry = new TC2Info.Group();
/*     */     
/*     */     public transient BufferedImage image;
/*     */   }
/*     */   
/*     */   public class Group
/*     */   {
/*  81 */     public TC2Info.Circular[] Circular = new TC2Info.Circular[0];
/*  82 */     public TC2Info.Shape[] Shape = new TC2Info.Shape[0];
/*  83 */     public TC2Info.Linear[] Linear = new TC2Info.Linear[0];
/*  84 */     public TC2Info.Null[] Null = new TC2Info.Null[0];
/*     */ 
/*     */     
/*     */     public void createNewShapeArray(int size) {
/*  88 */       this.Shape = new TC2Info.Shape[size];
/*  89 */       for (int i = 0; i < this.Shape.length; i++)
/*     */       {
/*  91 */         this.Shape[i] = new TC2Info.Shape();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void extendNullArray() {
/*  97 */       TC2Info.Null[] nulls = new TC2Info.Null[this.Null.length + 1];
/*  98 */       for (int i = 0; i < this.Null.length; i++)
/*     */       {
/* 100 */         nulls[i] = this.Null[i];
/*     */       }
/* 102 */       nulls[this.Null.length] = new TC2Info.Null();
/* 103 */       this.Null = nulls;
/*     */     } }
/*     */   
/*     */   public class Circular extends Null { public int Count;
/*     */     public int Radius;
/*     */     
/*     */     public Circular() {
/* 110 */       this.Type = "16932820-ef7c-4b4b-bf05-b72063b3d23c";
/* 111 */       this.Name = "Circular Array";
/*     */       
/* 113 */       this.Count = 5;
/* 114 */       this.Radius = 16;
/*     */     } }
/*     */ 
/*     */   
/*     */   public class Shape {
/* 119 */     public int Id = 1; @SerializedName("@Type")
/* 120 */     public String Type = "d9e621f7-957f-4b77-b1ae-20dcd0da7751";
/*     */     @SerializedName("@Name")
/* 122 */     public String Name = "new cube";
/*     */     
/* 124 */     public String IsDecorative = "False";
/* 125 */     public String IsFixed = "False";
/* 126 */     public String IsMirrored = "False";
/* 127 */     public String Position = "0,0,0";
/* 128 */     public String Offset = "0,0,0";
/* 129 */     public String Rotation = "0,0,0";
/* 130 */     public String Size = "1,1,1";
/* 131 */     public String TextureOffset = "0,0"; }
/*     */   
/*     */   public class Linear extends Null { public String Count;
/*     */     public String Spacing;
/*     */     
/*     */     public Linear() {
/* 137 */       this.Type = "fc4f63c9-8296-4c97-abd8-414f20e49bd5";
/* 138 */       this.Name = "Linear Array";
/*     */       
/* 140 */       this.Count = "0,0,0";
/* 141 */       this.Spacing = "0,0,0";
/*     */     } }
/*     */   
/*     */   public class Null {
/*     */     @SerializedName("@Type")
/* 146 */     public String Type = "3b3bb6e5-2f8b-4bbd-8dbb-478b67762fd0";
/*     */     @SerializedName("@Name")
/* 148 */     public String Name = "null element";
/*     */     
/* 150 */     public String Position = "0,0,0";
/* 151 */     public String Rotation = "0,0,0";
/* 152 */     public TC2Info.Group Children = new TC2Info.Group();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TC2Info readTechneFile(File file) {
/*     */     try {
/* 164 */       ZipFile zipFile = new ZipFile(file);
/* 165 */       Enumeration<? extends ZipEntry> entries = zipFile.entries();
/*     */       
/* 167 */       ZipEntry modelInfo = null;
/* 168 */       HashMap<String, InputStream> images = new HashMap<String, InputStream>();
/*     */       
/* 170 */       boolean tampered = false;
/*     */       
/* 172 */       while (entries.hasMoreElements()) {
/*     */         
/* 174 */         ZipEntry entry = entries.nextElement();
/* 175 */         if (!entry.isDirectory()) {
/*     */           
/* 177 */           if (entry.getName().endsWith(".png") && entry.getCrc() != Long.decode("0xf970c898").longValue())
/*     */           {
/* 179 */             images.put(entry.getName(), zipFile.getInputStream(entry));
/*     */           }
/* 181 */           if (entry.getName().endsWith(".xml") || entry.getName().endsWith(".json"))
/*     */           {
/* 183 */             modelInfo = entry;
/*     */           }
/* 185 */           if (!entry.getName().endsWith(".png") && !entry.getName().endsWith(".xml") && !entry.getName().endsWith(".json"))
/*     */           {
/* 187 */             tampered = true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 192 */       TC2Info info = null;
/* 193 */       if (modelInfo != null)
/*     */       {
/* 195 */         if (modelInfo.getName().endsWith(".xml")) {
/*     */           
/* 197 */           info = convertTechneFile(zipFile.getInputStream(modelInfo), images);
/*     */         }
/*     */         else {
/*     */           
/* 201 */           info = readTechne2File(zipFile.getInputStream(modelInfo), images);
/*     */         } 
/*     */       }
/*     */       
/* 205 */       zipFile.close();
/*     */       
/* 207 */       if (info != null)
/*     */       {
/* 209 */         info.tampered = tampered;
/*     */       }
/*     */       
/* 212 */       return info;
/*     */     }
/* 214 */     catch (Exception e1) {
/*     */       
/* 216 */       e1.printStackTrace();
/* 217 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TC2Info readTechneFile(InputStream stream) {
/*     */     try {
/* 230 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */       
/* 232 */       IOUtils.copy(stream, baos);
/* 233 */       baos.flush();
/*     */       
/* 235 */       ZipInputStream cloneXML = new ZipInputStream(new ByteArrayInputStream(baos.toByteArray()));
/*     */       
/* 237 */       ZipEntry entry = null;
/*     */       
/* 239 */       boolean hasXML = false;
/* 240 */       boolean hasJSON = false;
/* 241 */       while ((entry = cloneXML.getNextEntry()) != null) {
/*     */         
/* 243 */         if (!entry.isDirectory()) {
/*     */           
/* 245 */           if (entry.getName().endsWith(".xml")) {
/*     */             
/* 247 */             hasXML = true;
/*     */             break;
/*     */           } 
/* 250 */           if (entry.getName().endsWith(".json")) {
/*     */             
/* 252 */             hasJSON = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 258 */       entry = null;
/*     */       
/* 260 */       ZipInputStream clonePNG = new ZipInputStream(new ByteArrayInputStream(baos.toByteArray()));
/*     */       
/* 262 */       HashMap<String, InputStream> images = new HashMap<String, InputStream>();
/*     */       
/* 264 */       boolean tampered = false;
/*     */       
/* 266 */       while ((entry = clonePNG.getNextEntry()) != null) {
/*     */         
/* 268 */         if (!entry.isDirectory()) {
/*     */           
/* 270 */           if (entry.getName().endsWith(".png") && !images.containsKey(entry.getName()) && entry.getCrc() != Long.decode("0xf970c898").longValue()) {
/*     */             
/* 272 */             images.put(entry.getName(), clonePNG);
/* 273 */             clonePNG = new ZipInputStream(new ByteArrayInputStream(baos.toByteArray())); continue;
/*     */           } 
/* 275 */           if (!entry.getName().endsWith(".png") && !entry.getName().endsWith(".xml") && !entry.getName().endsWith(".json"))
/*     */           {
/* 277 */             tampered = true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 282 */       stream.close();
/*     */       
/* 284 */       if (!images.isEmpty()) {
/*     */         
/* 286 */         if (hasXML) {
/*     */           
/* 288 */           TC2Info info = convertTechneFile(cloneXML, images);
/* 289 */           if (info != null)
/*     */           {
/* 291 */             info.tampered = tampered;
/*     */           }
/* 293 */           return info;
/*     */         } 
/* 295 */         if (hasJSON) {
/*     */           
/* 297 */           TC2Info info = readTechne2File(cloneXML, images);
/* 298 */           if (info != null)
/*     */           {
/* 300 */             info.tampered = tampered;
/*     */           }
/* 302 */           return info;
/*     */         } 
/*     */       } 
/* 305 */       return null;
/*     */     }
/* 307 */     catch (Exception e1) {
/*     */       
/* 309 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TC2Info convertTechneFile(InputStream xml, HashMap<String, InputStream> images) throws IOException, ParserConfigurationException, SAXException {
/* 318 */     if (xml == null || images == null)
/*     */     {
/* 320 */       return null;
/*     */     }
/*     */     
/* 323 */     TC2Info info = new TC2Info();
/*     */     
/* 325 */     DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*     */     
/* 327 */     Document doc = builder.parse(xml);
/*     */     
/* 329 */     info.Techne.Version = doc.getElementsByTagName("Techne").item(0).getAttributes().item(0).getNodeValue();
/* 330 */     info.Techne.Author = doc.getElementsByTagName("Author").item(0).getTextContent().equals("ZeuX") ? "NotZeux" : doc.getElementsByTagName("Techne").item(0).getTextContent();
/* 331 */     info.Techne.Name = doc.getElementsByTagName("Name").item(0).getTextContent();
/* 332 */     info.Techne.PreviewImage = doc.getElementsByTagName("PreviewImage").item(0).getTextContent();
/* 333 */     info.Techne.ProjectName = doc.getElementsByTagName("ProjectName").item(0).getTextContent();
/* 334 */     info.Techne.ProjectType = doc.getElementsByTagName("ProjectType").item(0).getTextContent();
/* 335 */     info.Techne.Description = doc.getElementsByTagName("Description").item(0).getTextContent();
/* 336 */     info.Techne.DateCreated = doc.getElementsByTagName("DateCreated").item(0).getTextContent();
/*     */     
/* 338 */     NodeList list = doc.getElementsByTagName("Model");
/*     */     
/* 340 */     info.Techne.createNewModelArray(list.getLength());
/*     */     
/* 342 */     int id = 1;
/*     */     
/* 344 */     for (int i = 0; i < list.getLength(); i++) {
/*     */       
/* 346 */       Model model = info.Techne.Models[i];
/*     */       
/* 348 */       Node node = list.item(i);
/*     */       
/* 350 */       for (int j = 0; j < node.getAttributes().getLength(); j++) {
/*     */         
/* 352 */         Node attribute = node.getAttributes().item(j);
/*     */         
/* 354 */         if (attribute.getNodeName().equals("texture")) {
/*     */           
/* 356 */           model.Model.texture = attribute.getNodeValue();
/*     */           
/* 358 */           InputStream stream = images.get(model.Model.texture);
/* 359 */           if (stream != null)
/*     */           {
/* 361 */             model.Model.image = ImageIO.read(stream);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 366 */       Node Geometry = null;
/* 367 */       int shapeCount = 0;
/* 368 */       for (int k = 0; k < node.getChildNodes().getLength(); k++) {
/*     */         
/* 370 */         Node child = node.getChildNodes().item(k);
/* 371 */         if (child.getNodeName().equals("GlScale")) {
/*     */           
/* 373 */           model.Model.GlScale = child.getTextContent();
/*     */         }
/* 375 */         else if (child.getNodeName().equals("Name")) {
/*     */           
/* 377 */           model.Model.Name = child.getTextContent();
/*     */         }
/* 379 */         else if (child.getNodeName().equals("TextureSize")) {
/*     */           
/* 381 */           model.Model.TextureSize = child.getTextContent();
/*     */         }
/* 383 */         else if (child.getNodeName().equals("BaseClass")) {
/*     */           
/* 385 */           model.Model.BaseClass = child.getTextContent();
/*     */         }
/* 387 */         else if (child.getNodeName().equals("Geometry")) {
/*     */           
/* 389 */           id = createShapesFromNode(id, child, model.Model.Geometry);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 394 */     xml.close();
/*     */     
/* 396 */     for (Map.Entry<String, InputStream> img : images.entrySet())
/*     */     {
/* 398 */       ((InputStream)img.getValue()).close();
/*     */     }
/*     */     
/* 401 */     return info;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int createShapesFromNode(int id, Node node, Group group) {
/* 406 */     int shapeCount = 0;
/* 407 */     for (int l = 0; l < node.getChildNodes().getLength(); l++) {
/*     */       
/* 409 */       Node child = node.getChildNodes().item(l);
/* 410 */       if (child.getNodeName().equals("Shape")) {
/*     */         
/* 412 */         for (int j = 0; j < child.getAttributes().getLength(); j++)
/*     */         {
/* 414 */           Node attribute = child.getAttributes().item(j);
/* 415 */           if (attribute.getNodeName().equalsIgnoreCase("type") && (attribute.getNodeValue().equalsIgnoreCase("d9e621f7-957f-4b77-b1ae-20dcd0da7751") || attribute.getNodeValue().equalsIgnoreCase("de81aa14-bd60-4228-8d8d-5238bcd3caaa")))
/*     */           {
/* 417 */             shapeCount++;
/*     */           }
/*     */         }
/*     */       
/* 421 */       } else if (child.getNodeName().equals("Folder") || child.getNodeName().equals("Piece")) {
/*     */         
/* 423 */         group.extendNullArray();
/* 424 */         for (int j = 0; j < child.getAttributes().getLength(); j++) {
/*     */           
/* 426 */           Node attribute = child.getAttributes().item(j);
/* 427 */           if (attribute.getNodeName().equals("Name"))
/*     */           {
/* 429 */             (group.Null[group.Null.length - 1]).Name = attribute.getNodeValue();
/*     */           }
/*     */         } 
/* 432 */         if (child.getNodeName().equals("Piece"))
/*     */         {
/* 434 */           for (int i = 0; i < child.getChildNodes().getLength(); i++) {
/*     */             
/* 436 */             if (child.getChildNodes().item(i).equals("Position"))
/*     */             {
/* 438 */               (group.Null[group.Null.length - 1]).Position = child.getChildNodes().item(i).getTextContent();
/*     */             }
/*     */           } 
/*     */         }
/* 442 */         createShapesFromNode(id, child, (group.Null[group.Null.length - 1]).Children);
/*     */       } 
/*     */     } 
/*     */     
/* 446 */     group.createNewShapeArray(shapeCount);
/*     */     
/* 448 */     int shapeNum = 0;
/* 449 */     for (int k = 0; k < node.getChildNodes().getLength(); k++) {
/*     */       
/* 451 */       Node child = node.getChildNodes().item(k);
/* 452 */       if (child.getNodeName().equals("Shape"))
/*     */       {
/* 454 */         for (int j = 0; j < child.getAttributes().getLength(); j++) {
/*     */           
/* 456 */           Node attribute = child.getAttributes().item(j);
/* 457 */           if (attribute.getNodeName().equals("type") && (attribute.getNodeValue().equalsIgnoreCase("d9e621f7-957f-4b77-b1ae-20dcd0da7751") || attribute.getNodeValue().equalsIgnoreCase("de81aa14-bd60-4228-8d8d-5238bcd3caaa")) && shapeNum < shapeCount) {
/*     */             
/* 459 */             Shape shape = group.Shape[shapeNum];
/* 460 */             shape.Id = id++;
/*     */             
/* 462 */             for (int jj = 0; jj < child.getAttributes().getLength(); jj++) {
/*     */               
/* 464 */               Node attribute1 = child.getAttributes().item(jj);
/* 465 */               if (attribute1.getNodeName().equals("name")) {
/*     */                 
/* 467 */                 shape.Name = attribute1.getNodeValue();
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/* 472 */             for (int kk = 0; kk < child.getChildNodes().getLength(); kk++) {
/*     */               
/* 474 */               Node child1 = child.getChildNodes().item(kk);
/* 475 */               if (child1.getNodeName().equals("IsDecorative")) {
/*     */                 
/* 477 */                 shape.IsDecorative = child1.getTextContent();
/*     */               }
/* 479 */               else if (child1.getNodeName().equals("IsFixed")) {
/*     */                 
/* 481 */                 shape.IsFixed = child1.getTextContent();
/*     */               }
/* 483 */               else if (child1.getNodeName().equals("IsMirrored")) {
/*     */                 
/* 485 */                 shape.IsMirrored = child1.getTextContent();
/*     */               }
/* 487 */               else if (child1.getNodeName().equals("Offset")) {
/*     */                 
/* 489 */                 shape.Offset = child1.getTextContent();
/*     */               }
/* 491 */               else if (child1.getNodeName().equals("Position")) {
/*     */                 
/* 493 */                 shape.Position = child1.getTextContent();
/*     */               }
/* 495 */               else if (child1.getNodeName().equals("Rotation")) {
/*     */                 
/* 497 */                 String[] rotation = child1.getTextContent().split(",");
/* 498 */                 shape.Rotation = (rotation[0].equals("0") ? "0" : Float.toString((float)Math.toRadians(Float.parseFloat(rotation[0])))) + "," + (rotation[1].equals("0") ? "0" : Float.toString((float)Math.toRadians(Float.parseFloat(rotation[1])))) + "," + (rotation[2].equals("0") ? "0" : Float.toString((float)Math.toRadians(Float.parseFloat(rotation[2]))));
/*     */               }
/* 500 */               else if (child1.getNodeName().equals("Size")) {
/*     */                 
/* 502 */                 shape.Size = child1.getTextContent();
/*     */               }
/* 504 */               else if (child1.getNodeName().equals("TextureOffset")) {
/*     */                 
/* 506 */                 shape.TextureOffset = child1.getTextContent();
/*     */               } 
/*     */             } 
/* 509 */             shapeNum++;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 514 */     return id;
/*     */   }
/*     */   
/*     */   public static TC2Info readTechne2File(InputStream json, HashMap<String, InputStream> images) throws IOException {
/*     */     TC2Info info;
/* 519 */     if (json == null || images == null)
/*     */     {
/* 521 */       return null;
/*     */     }
/*     */     
/* 524 */     StringWriter writer = new StringWriter();
/* 525 */     IOUtils.copy(json, writer);
/* 526 */     String jsonString = writer.toString();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 532 */       info = (TC2Info)(new Gson()).fromJson(jsonString, TC2Info.class);
/*     */     }
/* 534 */     catch (JsonSyntaxException e) {
/*     */       
/* 536 */       info = ((TC1Json)(new Gson()).fromJson(jsonString.replaceAll("\000", ""), TC1Json.class)).toTC2Info();
/*     */     } 
/*     */     
/* 539 */     if (info != null)
/*     */     {
/* 541 */       for (Model model : info.Techne.Models) {
/*     */         
/* 543 */         InputStream stream = images.get(model.Model.texture);
/* 544 */         if (stream != null) {
/*     */           
/* 546 */           model.Model.image = ImageIO.read(stream);
/* 547 */           stream.close();
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 552 */     json.close();
/*     */     
/* 554 */     for (Map.Entry<String, InputStream> img : images.entrySet())
/*     */     {
/* 556 */       ((InputStream)img.getValue()).close();
/*     */     }
/* 558 */     return info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean saveAsFile(File file, boolean overwrite) {
/*     */     try {
/* 574 */       if (!overwrite && file.exists())
/*     */       {
/* 576 */         return false;
/*     */       }
/*     */       
/* 579 */       file.getParentFile().mkdirs();
/*     */       
/* 581 */       ZipOutputStream out = new ZipOutputStream(new FileOutputStream(file));
/* 582 */       out.setLevel(0);
/* 583 */       ZipEntry entry = new ZipEntry("model.json");
/*     */       
/* 585 */       out.putNextEntry(entry);
/*     */       
/* 587 */       byte[] data = (new Gson()).toJson(this).getBytes();
/* 588 */       out.write(data, 0, data.length);
/* 589 */       out.closeEntry();
/*     */       
/* 591 */       for (Model model : this.Techne.Models) {
/*     */         
/* 593 */         if (model.Model.image != null) {
/*     */           
/* 595 */           entry = new ZipEntry(model.Model.texture);
/* 596 */           out.putNextEntry(entry);
/*     */           
/* 598 */           ImageIO.write(model.Model.image, "png", out);
/*     */           
/* 600 */           out.closeEntry();
/*     */         } 
/*     */       } 
/*     */       
/* 604 */       out.close();
/* 605 */       return true;
/*     */     }
/* 607 */     catch (Exception e) {
/*     */       
/* 609 */       iChunUtil.console("Failed to save Techne 2 Model.", true);
/* 610 */       e.printStackTrace();
/* 611 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\techne\TC2Info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */