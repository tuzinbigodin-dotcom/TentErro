/*     */ package ichun.common.core.techne;
/*     */ 
/*     */ import com.google.gson.annotations.SerializedName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TC1Json
/*     */ {
/*  12 */   public Techne Techne = new Techne();
/*     */   
/*     */   public class Techne {
/*     */     @SerializedName("@Version")
/*  16 */     public String Version = "2.2";
/*     */     
/*  18 */     public String Author = "NotZeuX";
/*  19 */     public String Name = "";
/*  20 */     public String PreviewImage = "";
/*  21 */     public String ProjectName = "";
/*  22 */     public String ProjectType = "";
/*  23 */     public String Description = "";
/*  24 */     public String DateCreated = "";
/*  25 */     public TC1Json.Model[] Models = new TC1Json.Model[0];
/*     */   }
/*     */   
/*     */   public class Model
/*     */   {
/*  30 */     public TC1Json.ModelInfo Model = new TC1Json.ModelInfo();
/*     */   }
/*     */   
/*     */   public class ModelInfo
/*     */   {
/*  35 */     public String GlScale = "1,1,1";
/*  36 */     public String Name = "";
/*  37 */     public String TextureSize = "64,32"; @SerializedName("@texture")
/*  38 */     public String texture = "texture.png";
/*     */     
/*  40 */     public String BaseClass = "ModelBase";
/*  41 */     public TC1Json.Group Geometry = new TC1Json.Group();
/*     */   }
/*     */   
/*     */   public class Group
/*     */   {
/*  46 */     public TC1Json.Shape[] Shape = new TC1Json.Shape[0];
/*  47 */     public TC1Json.Null[] Folder = new TC1Json.Null[0];
/*     */   }
/*     */   
/*     */   public class Shape {
/*     */     @SerializedName("@type")
/*  52 */     public String Type = "d9e621f7-957f-4b77-b1ae-20dcd0da7751";
/*     */     @SerializedName("@name")
/*  54 */     public String Name = "new cube";
/*     */     
/*  56 */     public TC1Json.Animation Animation = new TC1Json.Animation();
/*  57 */     public String IsDecorative = "False";
/*  58 */     public String IsFixed = "False";
/*  59 */     public String IsMirrored = "False";
/*  60 */     public String Position = "0,0,0";
/*  61 */     public String Offset = "0,0,0";
/*  62 */     public String Rotation = "0,0,0";
/*  63 */     public String Size = "1,1,1";
/*  64 */     public String TextureOffset = "0,0";
/*     */   }
/*     */   
/*     */   public class Animation
/*     */   {
/*  69 */     public String AnimationAngles = "0,0,0";
/*  70 */     public String AnimationDuration = "0,0,0";
/*  71 */     public String AnimationType = "0,0,0";
/*     */   }
/*     */   
/*     */   public class Null {
/*     */     @SerializedName("@type")
/*  76 */     public String Type = "3b3bb6e5-2f8b-4bbd-8dbb-478b67762fd0";
/*     */     @SerializedName("@Name")
/*  78 */     public String Name = "null element";
/*     */ 
/*     */     
/*  81 */     public TC1Json.Shape[] Shape = new TC1Json.Shape[0];
/*  82 */     public Null[] Folder = new Null[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public TC2Info toTC2Info() {
/*  87 */     TC2Info info = new TC2Info();
/*     */     
/*  89 */     info.Techne.Version = this.Techne.Version;
/*  90 */     info.Techne.Author = this.Techne.Author.equals("ZeuX") ? "NotZeuX" : this.Techne.Author;
/*  91 */     info.Techne.Name = this.Techne.Name;
/*  92 */     info.Techne.PreviewImage = this.Techne.PreviewImage;
/*  93 */     info.Techne.ProjectName = this.Techne.ProjectName;
/*  94 */     info.Techne.ProjectType = this.Techne.ProjectType;
/*  95 */     info.Techne.Description = this.Techne.Description;
/*  96 */     info.Techne.DateCreated = this.Techne.DateCreated;
/*     */     
/*  98 */     info.Techne.createNewModelArray(this.Techne.Models.length);
/*     */     
/* 100 */     int id = 0;
/*     */     
/* 102 */     for (int i = 0; i < this.Techne.Models.length; i++) {
/*     */       
/* 104 */       (info.Techne.Models[i]).Model.GlScale = (this.Techne.Models[i]).Model.GlScale;
/*     */       
/* 106 */       (info.Techne.Models[i]).Model.Name = (this.Techne.Models[i]).Model.Name;
/* 107 */       (info.Techne.Models[i]).Model.TextureSize = (this.Techne.Models[i]).Model.TextureSize;
/* 108 */       (info.Techne.Models[i]).Model.texture = "texture.png";
/* 109 */       (info.Techne.Models[i]).Model.BaseClass = (this.Techne.Models[i]).Model.BaseClass;
/*     */       
/* 111 */       (info.Techne.Models[i]).Model.Geometry.createNewShapeArray((this.Techne.Models[i]).Model.Geometry.Shape.length);
/*     */       int j;
/* 113 */       for (j = 0; j < (this.Techne.Models[i]).Model.Geometry.Shape.length; j++) {
/*     */         
/* 115 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).Id = id++;
/*     */         
/* 117 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).Name = ((this.Techne.Models[i]).Model.Geometry.Shape[j]).Name;
/* 118 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).IsDecorative = ((this.Techne.Models[i]).Model.Geometry.Shape[j]).IsDecorative;
/* 119 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).IsFixed = ((this.Techne.Models[i]).Model.Geometry.Shape[j]).IsFixed;
/* 120 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).IsMirrored = ((this.Techne.Models[i]).Model.Geometry.Shape[j]).IsMirrored;
/* 121 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).Position = ((this.Techne.Models[i]).Model.Geometry.Shape[j]).Position;
/* 122 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).Offset = ((this.Techne.Models[i]).Model.Geometry.Shape[j]).Offset;
/*     */         
/* 124 */         String[] rotation = ((this.Techne.Models[i]).Model.Geometry.Shape[j]).Rotation.split(",");
/* 125 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).Rotation = (rotation[0].equals("0") ? "0" : Float.toString((float)Math.toRadians(Float.parseFloat(rotation[0])))) + "," + (rotation[1].equals("0") ? "0" : Float.toString((float)Math.toRadians(Float.parseFloat(rotation[1])))) + "," + (rotation[2].equals("0") ? "0" : Float.toString((float)Math.toRadians(Float.parseFloat(rotation[2]))));
/*     */         
/* 127 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).Size = ((this.Techne.Models[i]).Model.Geometry.Shape[j]).Size;
/* 128 */         ((info.Techne.Models[i]).Model.Geometry.Shape[j]).TextureOffset = ((this.Techne.Models[i]).Model.Geometry.Shape[j]).TextureOffset;
/*     */       } 
/*     */       
/* 131 */       if ((this.Techne.Models[i]).Model.Geometry.Folder != null)
/*     */       {
/* 133 */         for (j = 0; j < (this.Techne.Models[i]).Model.Geometry.Folder.length; j++) {
/*     */           
/* 135 */           (info.Techne.Models[i]).Model.Geometry.extendNullArray();
/* 136 */           id = populateNull(id, (info.Techne.Models[i]).Model.Geometry.Null[j], (this.Techne.Models[i]).Model.Geometry.Folder[j]);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 141 */     return info;
/*     */   }
/*     */ 
/*     */   
/*     */   public int populateNull(int id, TC2Info.Null tc2Null, Null tc1Null) {
/* 146 */     if (tc1Null.Folder != null)
/*     */     {
/* 148 */       for (int i = 0; i < tc1Null.Folder.length; i++) {
/*     */         
/* 150 */         tc2Null.Children.extendNullArray();
/* 151 */         id = populateNull(id, tc2Null.Children.Null[i], tc1Null.Folder[i]);
/*     */       } 
/*     */     }
/*     */     
/* 155 */     tc2Null.Children.createNewShapeArray(tc1Null.Shape.length);
/*     */     
/* 157 */     for (int j = 0; j < tc1Null.Shape.length; j++) {
/*     */       
/* 159 */       (tc2Null.Children.Shape[j]).Id = id++;
/*     */       
/* 161 */       (tc2Null.Children.Shape[j]).Name = (tc1Null.Shape[j]).Name;
/* 162 */       (tc2Null.Children.Shape[j]).IsDecorative = (tc1Null.Shape[j]).IsDecorative;
/* 163 */       (tc2Null.Children.Shape[j]).IsFixed = (tc1Null.Shape[j]).IsFixed;
/* 164 */       (tc2Null.Children.Shape[j]).IsMirrored = (tc1Null.Shape[j]).IsMirrored;
/* 165 */       (tc2Null.Children.Shape[j]).Position = (tc1Null.Shape[j]).Position;
/* 166 */       (tc2Null.Children.Shape[j]).Offset = (tc1Null.Shape[j]).Offset;
/*     */       
/* 168 */       String[] rotation = (tc1Null.Shape[j]).Rotation.split(",");
/* 169 */       (tc2Null.Children.Shape[j]).Rotation = (rotation[0].equals("0") ? "0" : Float.toString((float)Math.toRadians(Float.parseFloat(rotation[0])))) + "," + (rotation[1].equals("0") ? "0" : Float.toString((float)Math.toRadians(Float.parseFloat(rotation[1])))) + "," + (rotation[2].equals("0") ? "0" : Float.toString((float)Math.toRadians(Float.parseFloat(rotation[2]))));
/*     */       
/* 171 */       (tc2Null.Children.Shape[j]).Size = (tc1Null.Shape[j]).Size;
/* 172 */       (tc2Null.Children.Shape[j]).TextureOffset = (tc1Null.Shape[j]).TextureOffset;
/*     */     } 
/* 174 */     return id;
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\techne\TC1Json.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */