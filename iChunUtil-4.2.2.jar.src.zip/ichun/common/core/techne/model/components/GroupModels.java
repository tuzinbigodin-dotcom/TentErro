/*    */ package ichun.common.core.techne.model.components;
/*    */ 
/*    */ import ichun.common.core.techne.model.ModelRendererTechne;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroupModels
/*    */ {
/* 13 */   public ArrayList<ComponentCircularArray> componentCircularArray = new ArrayList<ComponentCircularArray>();
/* 14 */   public ArrayList<ComponentLinearArray> componentLinearArray = new ArrayList<ComponentLinearArray>();
/* 15 */   public ArrayList<ComponentGroup> componentGroup = new ArrayList<ComponentGroup>();
/*    */   
/* 17 */   public ArrayList<ModelRendererTechne> models = new ArrayList<ModelRendererTechne>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(float f5) {
/* 25 */     for (ComponentCircularArray component : this.componentCircularArray)
/*    */     {
/* 27 */       component.render(f5);
/*    */     }
/* 29 */     for (ModelRendererTechne model : this.models)
/*    */     {
/* 31 */       model.renderWithTechneRotation(f5);
/*    */     }
/* 33 */     for (ComponentLinearArray component : this.componentLinearArray)
/*    */     {
/* 35 */       component.render(f5);
/*    */     }
/* 37 */     for (ComponentGroup component : this.componentGroup)
/*    */     {
/* 39 */       component.render(f5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\techne\model\components\GroupModels.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */