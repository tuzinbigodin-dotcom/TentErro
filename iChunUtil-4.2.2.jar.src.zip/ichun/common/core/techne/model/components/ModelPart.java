/*    */ package ichun.common.core.techne.model.components;
/*    */ 
/*    */ import ichun.common.iChunUtil;
/*    */ import java.awt.image.BufferedImage;
/*    */ import net.minecraft.client.renderer.texture.TextureUtil;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelPart
/*    */ {
/*    */   public float scaleX;
/*    */   public float scaleY;
/*    */   public float scaleZ;
/*    */   public int textureWidth;
/*    */   public int textureHeight;
/*    */   public BufferedImage image;
/* 18 */   public int imageId = -1;
/*    */   
/* 20 */   public GroupModels models = new GroupModels();
/*    */ 
/*    */   
/*    */   public boolean render(boolean bindTexture, float f5) {
/* 24 */     if (bindTexture) {
/*    */       
/* 26 */       if (this.image == null) {
/*    */         
/* 28 */         iChunUtil.console("A Techne 2 model part is trying to render without a texture! Removing from overall Model Parts.");
/* 29 */         return false;
/*    */       } 
/* 31 */       if (this.imageId == -1)
/*    */       {
/* 33 */         this.imageId = TextureUtil.func_110987_a(TextureUtil.func_110996_a(), this.image);
/*    */       }
/* 35 */       GL11.glBindTexture(3553, this.imageId);
/*    */     } 
/*    */     
/* 38 */     GL11.glPushMatrix();
/* 39 */     GL11.glScalef(this.scaleX, this.scaleY, this.scaleZ);
/*    */     
/* 41 */     this.models.render(f5);
/*    */     
/* 43 */     GL11.glPopMatrix();
/*    */     
/* 45 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\techne\model\components\ModelPart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */