/*    */ package ichun.common.core.techne.model.components;
/*    */ 
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ public class ComponentCircularArray
/*    */   extends ComponentGroup
/*    */ {
/*    */   public float radius;
/*    */   public int count;
/*    */   
/*    */   protected void renderGroup(float f5) {
/* 13 */     for (int i = 0; i < this.count; i++) {
/*    */       
/* 15 */       GL11.glPushMatrix();
/*    */       
/* 17 */       float angle = 360.0F / this.count * i;
/*    */       
/* 19 */       if (angle != 0.0F)
/*    */       {
/* 21 */         GL11.glRotatef(angle, 0.0F, 1.0F, 0.0F);
/*    */       }
/*    */       
/* 24 */       GL11.glTranslatef(this.radius / 16.0F, 0.0F, 0.0F);
/*    */ 
/*    */       
/* 27 */       this.groupModels.render(f5);
/*    */       
/* 29 */       GL11.glPopMatrix();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\techne\model\components\ComponentCircularArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */