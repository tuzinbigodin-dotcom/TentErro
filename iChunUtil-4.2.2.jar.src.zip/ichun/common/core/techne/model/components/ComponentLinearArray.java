/*    */ package ichun.common.core.techne.model.components;
/*    */ 
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComponentLinearArray
/*    */   extends ComponentGroup
/*    */ {
/*    */   public int countX;
/*    */   public int countY;
/*    */   public int countZ;
/*    */   public float spaceX;
/*    */   public float spaceY;
/*    */   public float spaceZ;
/*    */   
/*    */   protected void renderGroup(float f5) {
/* 18 */     if (this.countX == 0 && this.countY == 0 && this.countZ == 0) {
/*    */       return;
/*    */     }
/*    */     
/* 22 */     for (int i = 0; i < this.countX; i++) {
/*    */       
/* 24 */       for (int j = 0; j < this.countY; j++) {
/*    */         
/* 26 */         for (int k = 0; k < this.countZ; k++) {
/*    */           
/* 28 */           GL11.glPushMatrix();
/*    */           
/* 30 */           GL11.glTranslatef(this.spaceX * i / 16.0F, this.spaceY * j / 16.0F, this.spaceZ * k / 16.0F);
/*    */           
/* 32 */           this.groupModels.render(f5);
/*    */           
/* 34 */           GL11.glPopMatrix();
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\techne\model\components\ComponentLinearArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */