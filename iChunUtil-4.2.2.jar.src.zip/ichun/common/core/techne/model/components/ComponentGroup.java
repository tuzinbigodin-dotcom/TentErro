/*    */ package ichun.common.core.techne.model.components;
/*    */ 
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComponentGroup
/*    */ {
/*    */   public float posX;
/*    */   public float posY;
/*    */   public float posZ;
/*    */   public float rotationX;
/*    */   public float rotationY;
/*    */   public float rotationZ;
/* 19 */   public GroupModels groupModels = new GroupModels();
/*    */ 
/*    */   
/*    */   public void render(float f5) {
/* 23 */     GL11.glPushMatrix();
/* 24 */     GL11.glTranslatef(this.posX / 16.0F, this.posY / 16.0F, this.posZ / 16.0F);
/*    */ 
/*    */     
/* 27 */     if (this.rotationY != 0.0F)
/*    */     {
/* 29 */       GL11.glRotatef((float)Math.toDegrees(this.rotationY), 0.0F, 1.0F, 0.0F);
/*    */     }
/* 31 */     if (this.rotationZ != 0.0F)
/*    */     {
/* 33 */       GL11.glRotatef((float)Math.toDegrees(this.rotationZ), 0.0F, 0.0F, 1.0F);
/*    */     }
/* 35 */     if (this.rotationX != 0.0F)
/*    */     {
/* 37 */       GL11.glRotatef((float)Math.toDegrees(this.rotationX), 1.0F, 0.0F, 0.0F);
/*    */     }
/*    */     
/* 40 */     renderGroup(f5);
/*    */     
/* 42 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void renderGroup(float f5) {
/* 51 */     this.groupModels.render(f5);
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\techne\model\components\ComponentGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */