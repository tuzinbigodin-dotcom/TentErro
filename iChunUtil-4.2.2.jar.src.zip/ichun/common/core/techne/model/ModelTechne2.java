/*     */ package ichun.common.core.techne.model;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import ichun.common.core.techne.TC2Info;
/*     */ import ichun.common.core.techne.model.components.ComponentCircularArray;
/*     */ import ichun.common.core.techne.model.components.ComponentGroup;
/*     */ import ichun.common.core.techne.model.components.ComponentLinearArray;
/*     */ import ichun.common.core.techne.model.components.GroupModels;
/*     */ import ichun.common.core.techne.model.components.ModelPart;
/*     */ import ichun.common.iChunUtil;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ModelTechne2
/*     */   extends ModelBase
/*     */ {
/*  20 */   public ArrayList<ModelPart> modelParts = new ArrayList<ModelPart>();
/*     */ 
/*     */   
/*     */   public ModelTechne2(TC2Info info) {
/*  24 */     for (TC2Info.Model model : info.Techne.Models) {
/*     */ 
/*     */       
/*     */       try {
/*  28 */         ModelPart part = new ModelPart();
/*  29 */         String[] scale = model.Model.GlScale.split(",");
/*  30 */         part.scaleX = Float.parseFloat(scale[0]);
/*  31 */         part.scaleY = Float.parseFloat(scale[1]);
/*  32 */         part.scaleZ = Float.parseFloat(scale[2]);
/*     */         
/*  34 */         String[] textureSize = model.Model.TextureSize.split(",");
/*  35 */         part.textureWidth = Integer.parseInt(textureSize[0]);
/*  36 */         part.textureHeight = Integer.parseInt(textureSize[1]);
/*     */         
/*  38 */         part.image = model.Model.image;
/*     */         
/*  40 */         this.field_78090_t = part.textureWidth;
/*  41 */         this.field_78089_u = part.textureHeight;
/*     */         
/*  43 */         populateGroup(this, EnumGroupType.NONE, model.Model.Geometry, part.models);
/*     */         
/*  45 */         this.modelParts.add(part);
/*     */       }
/*  47 */       catch (NumberFormatException e) {
/*     */         
/*  49 */         iChunUtil.console("Error parsing Techne 2 model: Invalid number", true);
/*  50 */         e.printStackTrace();
/*     */       }
/*  52 */       catch (ArrayIndexOutOfBoundsException e) {
/*     */         
/*  54 */         iChunUtil.console("Error parsing Techne 2 model: Array too short", true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void populateGroup(ModelBase model, EnumGroupType type, TC2Info.Group geometry, GroupModels models) {
/*  61 */     for (TC2Info.Circular circular : geometry.Circular) {
/*     */       
/*  63 */       ComponentCircularArray array = new ComponentCircularArray();
/*     */       
/*  65 */       setupComponent(model, (type == EnumGroupType.NONE) ? EnumGroupType.CIRCULAR : type, (TC2Info.Null)circular, (ComponentGroup)array);
/*     */       
/*  67 */       array.count = circular.Count;
/*  68 */       array.radius = circular.Radius;
/*     */       
/*  70 */       models.componentCircularArray.add(array);
/*     */     } 
/*  72 */     for (TC2Info.Linear linear : geometry.Linear) {
/*     */       
/*  74 */       ComponentLinearArray array = new ComponentLinearArray();
/*     */       
/*  76 */       setupComponent(model, (type == EnumGroupType.NONE) ? EnumGroupType.LINEAR : type, (TC2Info.Null)linear, (ComponentGroup)array);
/*     */       
/*  78 */       String[] count = linear.Count.split(",");
/*  79 */       array.countX = Integer.parseInt(count[0]);
/*  80 */       array.countY = Integer.parseInt(count[1]);
/*  81 */       array.countZ = Integer.parseInt(count[2]);
/*  82 */       if (array.countX != 0 || array.countY != 0 || array.countZ != 0) {
/*     */         
/*  84 */         if (array.countX == 0)
/*     */         {
/*  86 */           array.countX = 1;
/*     */         }
/*  88 */         if (array.countY == 0)
/*     */         {
/*  90 */           array.countY = 1;
/*     */         }
/*  92 */         if (array.countZ == 0)
/*     */         {
/*  94 */           array.countZ = 1;
/*     */         }
/*     */       } 
/*     */       
/*  98 */       String[] space = linear.Spacing.split(",");
/*  99 */       array.spaceX = Float.parseFloat(space[0]);
/* 100 */       array.spaceY = Float.parseFloat(space[1]);
/* 101 */       array.spaceZ = Float.parseFloat(space[2]);
/*     */       
/* 103 */       models.componentLinearArray.add(array);
/*     */     } 
/* 105 */     for (TC2Info.Null nul : geometry.Null) {
/*     */       
/* 107 */       ComponentGroup array = new ComponentGroup();
/*     */       
/* 109 */       setupComponent(model, type, nul, array);
/*     */       
/* 111 */       models.componentGroup.add(array);
/*     */     } 
/* 113 */     for (TC2Info.Shape shape : geometry.Shape) {
/*     */       
/* 115 */       String[] textureOffset = shape.TextureOffset.split(",");
/*     */       
/* 117 */       ModelRendererTechne cube = new ModelRendererTechne(model, shape.Name);
/* 118 */       cube.func_78784_a(Integer.parseInt(textureOffset[0]), Integer.parseInt(textureOffset[1]));
/* 119 */       cube.field_78809_i = !shape.IsMirrored.equals("False");
/*     */       
/* 121 */       String[] pos = shape.Position.split(",");
/* 122 */       String[] rot = shape.Rotation.split(",");
/* 123 */       String[] size = shape.Size.split(",");
/*     */       
/* 125 */       String[] offset = { "0", "0", "0" };
/* 126 */       if (shape.Offset != null) {
/*     */         
/* 128 */         offset = shape.Offset.split(",");
/*     */       }
/* 130 */       else if (type == EnumGroupType.CIRCULAR) {
/*     */         
/* 132 */         offset = new String[] { Float.toString(Float.parseFloat(size[0]) / -2.0F), Float.toString(Float.parseFloat(size[1]) / -2.0F), Float.toString(Float.parseFloat(size[2]) / -2.0F) };
/* 133 */         pos = rot = new String[] { "0", "0", "0" };
/*     */       } 
/*     */       
/* 136 */       cube.func_78789_a(Float.parseFloat(offset[0]), Float.parseFloat(offset[1]), Float.parseFloat(offset[2]), Integer.parseInt(size[0]), Integer.parseInt(size[1]), Integer.parseInt(size[2]));
/* 137 */       cube.func_78793_a(Float.parseFloat(pos[0]), Float.parseFloat(pos[1]), Float.parseFloat(pos[2]));
/*     */       
/* 139 */       cube.field_78795_f = Float.parseFloat(rot[0]);
/* 140 */       cube.field_78796_g = Float.parseFloat(rot[1]);
/* 141 */       cube.field_78808_h = Float.parseFloat(rot[2]);
/*     */       
/* 143 */       models.models.add(cube);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setupComponent(ModelBase model, EnumGroupType type, TC2Info.Null info, ComponentGroup component) {
/* 149 */     String[] pos = info.Position.split(",");
/* 150 */     component.posX = Float.parseFloat(pos[0]);
/* 151 */     component.posY = Float.parseFloat(pos[1]);
/* 152 */     component.posZ = Float.parseFloat(pos[2]);
/*     */     
/* 154 */     String[] rot = info.Rotation.split(",");
/* 155 */     component.rotationX = Float.parseFloat(rot[0]);
/* 156 */     component.rotationY = Float.parseFloat(rot[1]);
/* 157 */     component.rotationZ = Float.parseFloat(rot[2]);
/*     */     
/* 159 */     populateGroup(model, type, info.Children, component.groupModels);
/*     */   }
/*     */   
/*     */   public enum EnumGroupType
/*     */   {
/* 164 */     NONE,
/* 165 */     CIRCULAR,
/* 166 */     LINEAR;
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(boolean bindTexture, float f5) {
/* 171 */     for (int i = this.modelParts.size() - 1; i >= 0; i--) {
/*     */       
/* 173 */       ModelPart modelPart = this.modelParts.get(i);
/* 174 */       if (!modelPart.render(bindTexture, f5))
/*     */       {
/* 176 */         this.modelParts.remove(i);
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\techne\model\ModelTechne2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */