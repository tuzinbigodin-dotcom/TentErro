/*    */ package ichun.common.core.techne.model;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelBox;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.client.renderer.GLAllocation;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class ModelRendererTechne
/*    */   extends ModelRenderer
/*    */ {
/*    */   private boolean compiled;
/*    */   private int displayList;
/*    */   
/*    */   public ModelRendererTechne(ModelBase par1ModelBase, String par2Str) {
/* 20 */     super(par1ModelBase, par2Str);
/*    */   }
/*    */ 
/*    */   
/*    */   public ModelRendererTechne(ModelBase par1ModelBase) {
/* 25 */     super(par1ModelBase);
/*    */   }
/*    */ 
/*    */   
/*    */   public ModelRendererTechne(ModelBase par1ModelBase, int par2, int par3) {
/* 30 */     super(par1ModelBase, par2, par3);
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void renderWithTechneRotation(float par1) {
/* 36 */     if (!this.field_78807_k)
/*    */     {
/* 38 */       if (this.field_78806_j) {
/*    */         
/* 40 */         if (!this.compiled)
/*    */         {
/* 42 */           compileDisplayList(par1);
/*    */         }
/*    */         
/* 45 */         GL11.glPushMatrix();
/* 46 */         GL11.glTranslatef(this.field_78800_c * par1, this.field_78797_d * par1, this.field_78798_e * par1);
/*    */         
/* 48 */         if (this.field_78796_g != 0.0F)
/*    */         {
/* 50 */           GL11.glRotatef(this.field_78796_g * 57.295776F, 0.0F, 1.0F, 0.0F);
/*    */         }
/*    */         
/* 53 */         if (this.field_78808_h != 0.0F)
/*    */         {
/* 55 */           GL11.glRotatef(this.field_78808_h * 57.295776F, 0.0F, 0.0F, 1.0F);
/*    */         }
/*    */         
/* 58 */         if (this.field_78795_f != 0.0F)
/*    */         {
/* 60 */           GL11.glRotatef(this.field_78795_f * 57.295776F, 1.0F, 0.0F, 0.0F);
/*    */         }
/*    */         
/* 63 */         GL11.glCallList(this.displayList);
/* 64 */         GL11.glPopMatrix();
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   private void compileDisplayList(float par1) {
/* 72 */     this.displayList = GLAllocation.func_74526_a(1);
/* 73 */     GL11.glNewList(this.displayList, 4864);
/* 74 */     Tessellator tessellator = Tessellator.field_78398_a;
/*    */     
/* 76 */     for (int i = 0; i < this.field_78804_l.size(); i++)
/*    */     {
/* 78 */       ((ModelBox)this.field_78804_l.get(i)).func_78245_a(tessellator, par1);
/*    */     }
/*    */     
/* 81 */     GL11.glEndList();
/* 82 */     this.compiled = true;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\core\techne\model\ModelRendererTechne.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */