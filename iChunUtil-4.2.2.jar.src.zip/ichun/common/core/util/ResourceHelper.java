/*    */ package ichun.common.core.util;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import java.io.File;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class ResourceHelper
/*    */ {
/* 13 */   public static final ResourceLocation texPig = new ResourceLocation("textures/entity/pig/pig.png");
/* 14 */   public static final ResourceLocation texFont = new ResourceLocation("textures/font/ascii.png");
/*    */   
/*    */   private static File fileAssets;
/*    */   private static File fileMods;
/*    */   private static File fileConfig;
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public static void init() {
/* 22 */     fileAssets = new File((Minecraft.func_71410_x()).field_71412_D, "assets");
/* 23 */     fileMods = new File((Minecraft.func_71410_x()).field_71412_D, "mods");
/* 24 */     fileConfig = new File((Minecraft.func_71410_x()).field_71412_D, "config");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static File getAssetsFolder() {
/* 33 */     return fileAssets;
/*    */   }
/*    */ 
/*    */   
/*    */   public static File getModsFolder() {
/* 38 */     return fileMods;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static File getConfigFolder() {
/* 44 */     return fileConfig;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\cor\\util\ResourceHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */