/*    */ package ichun.common.core.util;
/*    */ 
/*    */ import ichun.common.iChunUtil;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.security.MessageDigest;
/*    */ import java.text.DecimalFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MD5Checksum
/*    */ {
/* 20 */   static final byte[] HEX_CHAR_TABLE = new byte[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static byte[] createChecksum(File filename) throws Exception {
/* 30 */     InputStream fis = new FileInputStream(filename);
/*    */     
/* 32 */     byte[] buffer = new byte[1024];
/* 33 */     MessageDigest complete = MessageDigest.getInstance("MD5");
/*    */     
/*    */     while (true) {
/* 36 */       int numRead = fis.read(buffer);
/* 37 */       if (numRead > 0) {
/* 38 */         complete.update(buffer, 0, numRead);
/*    */       }
/* 40 */       if (numRead == -1) {
/* 41 */         fis.close();
/* 42 */         return complete.digest();
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String getMD5Checksum(File file) {
/*    */     try {
/* 49 */       byte[] b = createChecksum(file);
/* 50 */       String hex = getHexString(b);
/* 51 */       return hex;
/* 52 */     } catch (Exception e) {
/* 53 */       iChunUtil.console("Failed to generate MD5 checksum for " + file.getName(), true);
/* 54 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static String getHexString(byte[] raw) throws UnsupportedEncodingException {
/* 61 */     byte[] hex = new byte[2 * raw.length];
/* 62 */     int index = 0;
/*    */     
/* 64 */     for (byte b : raw) {
/* 65 */       int v = b & 0xFF;
/* 66 */       hex[index++] = HEX_CHAR_TABLE[v >>> 4];
/* 67 */       hex[index++] = HEX_CHAR_TABLE[v & 0xF];
/*    */     } 
/* 69 */     return new String(hex, "ASCII");
/*    */   }
/*    */   
/*    */   public static String readableFileSize(long size) {
/* 73 */     if (size <= 0L) return "0"; 
/* 74 */     String[] units = { "B", "kB", "MB", "GB", "TB" };
/* 75 */     int digitGroups = (int)(Math.log10(size) / Math.log10(1024.0D));
/* 76 */     return (new DecimalFormat("#,##0.#")).format(size / Math.pow(1024.0D, digitGroups)) + " " + units[digitGroups];
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\cor\\util\MD5Checksum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */