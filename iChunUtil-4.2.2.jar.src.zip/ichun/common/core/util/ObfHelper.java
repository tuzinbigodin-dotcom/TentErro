/*     */ package ichun.common.core.util;
/*     */ 
/*     */ import ichun.common.iChunUtil;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RendererLivingEntity;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObfHelper
/*     */ {
/*     */   public static boolean obfuscation;
/*     */   private static final String obfVersion = "1.7.10";
/*  23 */   public static final String[] resourceDomain = new String[] { "field_110626_a", "resourceDomain", "a" };
/*  24 */   public static final String[] resourcePath = new String[] { "field_110625_b", "resourcePath", "b" };
/*  25 */   public static final String[] gameProfile = new String[] { "field_146106_i", "gameProfile", "i" };
/*     */   
/*     */   public static final String getHurtSoundObf = "func_70621_aR";
/*     */   
/*     */   public static final String getHurtSoundDeobf = "getHurtSound";
/*     */   
/*     */   public static final String getDeathSoundObf = "func_70673_aS";
/*     */   
/*     */   public static final String getDeathSoundDeobf = "getDeathSound";
/*     */   
/*     */   public static final String preRenderCallbackObf = "func_77041_b";
/*     */   
/*     */   public static final String preRenderCallbackDeobf = "preRenderCallback";
/*     */   
/*     */   public static final String getEntityTextureObf = "func_110775_a";
/*     */   
/*     */   public static final String getEntityTextureDeobf = "getEntityTexture";
/*     */ 
/*     */   
/*     */   public static void obfWarning() {
/*  45 */     iChunUtil.console("Forgot to update obfuscation!", true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void detectObfuscation() {
/*  50 */     obfuscation = true;
/*     */     
/*     */     try {
/*  53 */       Field[] fields = Class.forName("net.minecraft.world.World").getDeclaredFields();
/*  54 */       for (Field f : fields) {
/*     */         
/*  56 */         f.setAccessible(true);
/*  57 */         if (f.getName().equalsIgnoreCase("loadedEntityList")) {
/*     */           
/*  59 */           obfuscation = false;
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*  64 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokePreRenderCallback(Render rend, Class<RendererLivingEntity> clz, Entity ent, float rendTick) {
/*  71 */     if (!(rend instanceof RendererLivingEntity) || !(ent instanceof EntityLivingBase)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  77 */       Method m = clz.getDeclaredMethod(obfuscation ? "func_77041_b" : "preRenderCallback", new Class[] { EntityLivingBase.class, float.class });
/*  78 */       m.setAccessible(true);
/*  79 */       m.invoke(rend, new Object[] { ent, Float.valueOf(rendTick) });
/*     */     }
/*  81 */     catch (NoSuchMethodException e) {
/*     */       
/*  83 */       if (clz != RendererLivingEntity.class)
/*     */       {
/*  85 */         invokePreRenderCallback(rend, clz.getSuperclass(), ent, rendTick);
/*     */       }
/*     */     }
/*  88 */     catch (Exception e) {
/*     */       
/*  90 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static ResourceLocation invokeGetEntityTexture(Render rend, Class clz, EntityLivingBase ent) {
/*  96 */     ResourceLocation loc = getEntTexture(rend, clz, ent);
/*  97 */     if (loc != null)
/*     */     {
/*  99 */       return loc;
/*     */     }
/* 101 */     return AbstractClientPlayer.field_110314_b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResourceLocation getEntTexture(Render rend, Class<RendererLivingEntity> clz, EntityLivingBase ent) {
/*     */     try {
/* 108 */       Method m = clz.getDeclaredMethod(obfuscation ? "func_110775_a" : "getEntityTexture", new Class[] { Entity.class });
/* 109 */       m.setAccessible(true);
/* 110 */       return (ResourceLocation)m.invoke(rend, new Object[] { ent });
/*     */     }
/* 112 */     catch (NoSuchMethodException e) {
/*     */       
/* 114 */       if (clz != RendererLivingEntity.class)
/*     */       {
/* 116 */         return invokeGetEntityTexture(rend, clz.getSuperclass(), ent);
/*     */       }
/*     */     }
/* 119 */     catch (Exception e) {
/*     */       
/* 121 */       e.printStackTrace();
/*     */     } 
/* 123 */     return AbstractClientPlayer.field_110314_b;
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\cor\\util\ObfHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */