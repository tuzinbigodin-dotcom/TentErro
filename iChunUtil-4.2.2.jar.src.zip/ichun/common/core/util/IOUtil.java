/*    */ package ichun.common.core.util;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ 
/*    */ public class IOUtil
/*    */ {
/*    */   public static boolean areBufferedImagesEqual(BufferedImage img1, BufferedImage img2) {
/*  9 */     if (img1 == null && img2 == null)
/*    */     {
/* 11 */       return true;
/*    */     }
/* 13 */     if (img1 == null || img2 == null)
/*    */     {
/* 15 */       return false;
/*    */     }
/* 17 */     if (img1.getWidth() == img2.getWidth() && img1.getHeight() == img2.getHeight()) {
/*    */       
/* 19 */       for (int x = 0; x < img1.getWidth(); x++) {
/*    */         
/* 21 */         for (int y = 0; y < img1.getHeight(); y++)
/*    */         {
/* 23 */           if (img1.getRGB(x, y) != img2.getRGB(x, y))
/*    */           {
/* 25 */             return false;
/*    */           }
/*    */         }
/*    */       
/*    */       } 
/*    */     } else {
/*    */       
/* 32 */       return false;
/*    */     } 
/* 34 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\cor\\util\IOUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */