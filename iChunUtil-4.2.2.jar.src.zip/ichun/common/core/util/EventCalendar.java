/*    */ package ichun.common.core.util;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventCalendar
/*    */ {
/*    */   private static boolean isNewYear;
/*    */   private static boolean isPgBirthday;
/*    */   private static boolean isAFDay;
/*    */   private static boolean isHalloween;
/*    */   private static boolean isChristmas;
/*    */   public static int day;
/*    */   
/*    */   public static void checkDate() {
/* 17 */     Calendar calendar = Calendar.getInstance();
/* 18 */     calendar.setTimeInMillis(System.currentTimeMillis());
/*    */     
/* 20 */     switch (calendar.get(2)) {
/*    */ 
/*    */       
/*    */       case 1:
/* 24 */         if (calendar.get(5) == 1)
/*    */         {
/* 26 */           isNewYear = true;
/*    */         }
/*    */         break;
/*    */ 
/*    */       
/*    */       case 3:
/* 32 */         if (calendar.get(5) == 9)
/*    */         {
/* 34 */           isPgBirthday = true;
/*    */         }
/*    */         break;
/*    */ 
/*    */       
/*    */       case 4:
/* 40 */         if (calendar.get(5) == 1)
/*    */         {
/* 42 */           isAFDay = true;
/*    */         }
/*    */         break;
/*    */ 
/*    */       
/*    */       case 10:
/* 48 */         if (calendar.get(5) == 31)
/*    */         {
/* 50 */           isHalloween = true;
/*    */         }
/*    */         break;
/*    */ 
/*    */       
/*    */       case 12:
/* 56 */         if (calendar.get(5) == 25)
/*    */         {
/* 58 */           isChristmas = true;
/*    */         }
/*    */         break;
/*    */     } 
/*    */     
/* 63 */     day = calendar.get(5);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isNewYear() {
/* 68 */     return isNewYear;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isPgBirthday() {
/* 73 */     return isPgBirthday;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isAFDay() {
/* 78 */     return isAFDay;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isHalloween() {
/* 83 */     return isHalloween;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isChristmas() {
/* 88 */     return isChristmas;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar!\ichun\common\cor\\util\EventCalendar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */