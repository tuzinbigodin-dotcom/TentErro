/*     */ package us.ichun.mods.ichunutil.client.thread;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import ichun.common.core.EntityHelperBase;
/*     */ import ichun.common.core.config.Config;
/*     */ import ichun.common.core.config.ConfigHandler;
/*     */ import ichun.common.core.config.IConfigUser;
/*     */ import ichun.common.core.updateChecker.ModVersionChecker;
/*     */ import ichun.common.core.updateChecker.ModVersionInfo;
/*     */ import ichun.common.core.util.ObfHelper;
/*     */ import ichun.common.core.util.ResourceHelper;
/*     */ import ichun.common.iChunUtil;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.commons.lang3.RandomStringUtils;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.NameValuePair;
/*     */ import org.apache.http.client.entity.UrlEncodedFormEntity;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.client.HttpClients;
/*     */ import org.apache.http.message.BasicNameValuePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ThreadStatistics
/*     */   extends Thread
/*     */ {
/*     */   public int type;
/*     */   public Object[] data;
/*     */   
/*     */   public ThreadStatistics(int type1, Object... data1) {
/*  41 */     setName("iChunUtil Statistics Thread");
/*  42 */     setDaemon(true);
/*     */     
/*  44 */     this.type = type1;
/*  45 */     this.data = data1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/*  53 */       CloseableHttpClient closeableHttpClient = HttpClients.createDefault();
/*  54 */       HttpPost httppost = new HttpPost("http://ichun.us/infect/stats2.php");
/*     */ 
/*     */       
/*  57 */       ArrayList<NameValuePair> params = new ArrayList<NameValuePair>(2);
/*  58 */       params.add(new BasicNameValuePair("event", Integer.toString(this.type)));
/*  59 */       params.add(new BasicNameValuePair("UUID", Minecraft.func_71410_x().func_110432_I().func_148255_b().replaceAll("-", "")));
/*  60 */       if (this.type != 4) {
/*     */         StringBuilder sb; ArrayList<ModVersionInfo> mods; int i;
/*  62 */         params.add(new BasicNameValuePair("time", Long.toString(System.currentTimeMillis())));
/*     */         
/*  64 */         switch (this.type) {
/*     */ 
/*     */           
/*     */           case 1:
/*  68 */             params.add(new BasicNameValuePair("version", "4.2.2".replaceAll(" ", "").replaceAll("\\.", "_")));
/*     */             
/*  70 */             sb = new StringBuilder();
/*  71 */             if (!ObfHelper.obfuscation)
/*     */             {
/*  73 */               sb.append("devEnv-");
/*     */             }
/*  75 */             mods = ModVersionChecker.getListOf_iChunMods();
/*  76 */             for (i = 0; i < mods.size(); i++) {
/*     */               
/*  78 */               sb.append(((ModVersionInfo)mods.get(i)).modName.replaceAll(" ", "").replaceAll("\\.", "_") + "_" + ((ModVersionInfo)mods.get(i)).modVersion.replaceAll("\\.", "_"));
/*  79 */               if (i < mods.size() - 1)
/*     */               {
/*  81 */                 sb.append("-");
/*     */               }
/*     */             } 
/*     */             
/*  85 */             params.add(new BasicNameValuePair("mods", sb.toString()));
/*  86 */             params.add(new BasicNameValuePair("level", Integer.toString(getImmunityLevel())));
/*     */             break;
/*     */ 
/*     */           
/*     */           case 2:
/*  91 */             params.add(new BasicNameValuePair("infector", (String)this.data[1]));
/*     */ 
/*     */           
/*     */           case 3:
/*  95 */             params.add(new BasicNameValuePair("level", Integer.toString(((Integer)this.data[0]).intValue())));
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 101 */       httppost.setEntity((HttpEntity)new UrlEncodedFormEntity(params, "UTF-8"));
/*     */ 
/*     */ 
/*     */       
/* 105 */       HttpResponse response = closeableHttpClient.execute((HttpUriRequest)httppost);
/*     */       
/* 107 */       if (this.type == 4) {
/*     */         
/* 109 */         HttpEntity entity = response.getEntity();
/*     */         
/* 111 */         if (entity != null) {
/*     */           
/* 113 */           InputStream is = entity.getContent();
/*     */           
/*     */           try {
/* 116 */             int lv = Integer.parseInt(IOUtils.toString(is, "UTF-8").trim());
/*     */             
/* 118 */             if (lv >= 0)
/*     */             {
/* 120 */               stats.get("statsData").set(getInfectionHash(lv));
/* 121 */               stats.save();
/*     */             }
/*     */             else
/*     */             {
/* 125 */               (new ThreadStatistics(1, new Object[0])).start();
/*     */             }
/*     */           
/*     */           } finally {
/*     */             
/* 130 */             is.close();
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 135 */     } catch (Exception e) {
/*     */       
/* 137 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/* 141 */   public static final ArrayList<String> infectionHash = new ArrayList<String>();
/* 142 */   public static final Random rand = new Random();
/*     */   
/*     */   public static Config stats;
/*     */ 
/*     */   
/*     */   public static void checkFirstLaunch() {
/* 148 */     stats = ConfigHandler.createConfig(new File(ResourceHelper.getConfigFolder(), "iChunUtil_Stats.cfg"), "ichunutilstats", "iChunUtil Stats", null, (IConfigUser)iChunUtil.instance);
/*     */     
/* 150 */     stats.setCurrentCategory("stats");
/* 151 */     stats.createIntBoolProperty("statsOptOut", true, false, !(Minecraft.func_71410_x()).field_71474_y.field_74355_t);
/* 152 */     stats.createStringProperty("statsIdentifier", false, false, "");
/* 153 */     stats.createStringProperty("statsData", false, false, "");
/*     */     
/* 155 */     if (stats.getInt("statsOptOut") == 1) {
/*     */       
/* 157 */       iChunUtil.console("Opting out of stat collection :(");
/*     */     }
/*     */     else {
/*     */       
/* 161 */       boolean isPatientZero = (getImmunityLevel() == 0);
/* 162 */       if (stats.getString("statsData").trim().isEmpty() || getInfectionLevel(stats.getString("statsData")) == -1) {
/*     */         
/* 164 */         stats.get("statsData").set(isPatientZero ? getInfectionHash(0) : "");
/* 165 */         stats.save();
/*     */       } 
/* 167 */       String firstLaunchHash = createFirstLaunchHash();
/* 168 */       if (stats.getString("statsIdentifier").trim().isEmpty() || !stats.getString("statsIdentifier").equals(firstLaunchHash)) {
/*     */         
/* 170 */         stats.get("statsIdentifier").set(firstLaunchHash);
/* 171 */         stats.save();
/* 172 */         (new ThreadStatistics(4, new Object[0])).start();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String createFirstLaunchHash() {
/* 179 */     rand.setSeed(Math.abs(Minecraft.func_71410_x().func_110432_I().func_148255_b().hashCode() - "FirstRunV2".hashCode()));
/* 180 */     return RandomStringUtils.random(20, 32, 127, false, false, null, rand);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getImmunityLevel() {
/* 185 */     Minecraft mc = Minecraft.func_71410_x();
/*     */     
/* 187 */     return EntityHelperBase.getImmunityLevel(mc.func_110432_I().func_148255_b());
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getInfectionLevel(String s) {
/* 192 */     if (s.isEmpty())
/*     */     {
/* 194 */       return -1;
/*     */     }
/*     */     
/* 197 */     if (infectionHash.isEmpty())
/*     */     {
/* 199 */       generateInfectionHash();
/*     */     }
/*     */     
/* 202 */     for (int i = 0; i < infectionHash.size(); i++) {
/*     */       
/* 204 */       if (((String)infectionHash.get(i)).equals(s))
/*     */       {
/* 206 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 210 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getInfectionHash(int i) {
/* 215 */     if (infectionHash.isEmpty())
/*     */     {
/* 217 */       generateInfectionHash();
/*     */     }
/* 219 */     if (i >= infectionHash.size())
/*     */     {
/* 221 */       return "CHEATER";
/*     */     }
/* 223 */     return infectionHash.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void generateInfectionHash() {
/* 228 */     infectionHash.clear();
/*     */     
/* 230 */     Minecraft mc = Minecraft.func_71410_x();
/*     */     
/* 232 */     float immunity = 1.0F;
/* 233 */     int i = 0;
/*     */     
/* 235 */     while (immunity > 0.0F) {
/*     */       
/* 237 */       rand.setSeed(Math.abs(mc.func_110432_I().func_148255_b().replaceAll("-", "").hashCode() + infectionHash.size() * Math.abs("infection".hashCode())));
/* 238 */       infectionHash.add(RandomStringUtils.random(20, 32, 127, false, false, null, rand));
/* 239 */       immunity -= EntityHelperBase.RARITY[i];
/* 240 */       i++;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\mods\ichunutil\client\thread\ThreadStatistics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */