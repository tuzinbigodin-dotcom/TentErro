/*    */ package us.ichun.mods.ichunutil.common.core.packet.mod;
/*    */ 
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import ichun.common.core.CommonProxy;
/*    */ import ichun.common.core.network.AbstractPacket;
/*    */ import ichun.common.core.network.PacketHandler;
/*    */ import ichun.common.iChunUtil;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import us.ichun.mods.ichunutil.client.thread.ThreadStatistics;
/*    */ 
/*    */ public class PacketPatientData
/*    */   extends AbstractPacket {
/*    */   public int level;
/*    */   public boolean mutate;
/*    */   public String infector;
/*    */   
/*    */   public PacketPatientData() {}
/*    */   
/*    */   public PacketPatientData(int i, boolean isMutation, String inf) {
/* 23 */     this.level = i;
/* 24 */     this.mutate = isMutation;
/* 25 */     this.infector = inf;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeTo(ByteBuf buffer, Side side) {
/* 31 */     buffer.writeInt(this.level);
/* 32 */     buffer.writeBoolean(this.mutate);
/* 33 */     ByteBufUtils.writeUTF8String(buffer, this.infector);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void readFrom(ByteBuf buffer, Side side) {
/* 39 */     this.level = buffer.readInt();
/* 40 */     this.mutate = buffer.readBoolean();
/* 41 */     this.infector = ByteBufUtils.readUTF8String(buffer);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute(Side side, EntityPlayer player) {
/* 47 */     if (side.isServer()) {
/*    */       
/* 49 */       CommonProxy.tickHandlerServer.infectionMap.put(player.func_146103_bH().getId().toString(), Integer.valueOf(this.level));
/*    */     }
/*    */     else {
/*    */       
/* 53 */       handleClient();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void handleClient() {
/* 60 */     if (ThreadStatistics.stats.getInt("statsOptOut") != 1) {
/*    */       
/* 62 */       CommonProxy.tickHandlerClient.infectionTimeout = (this.level == 0) ? 100 : 60;
/* 63 */       CommonProxy.tickHandlerClient.isFirstInfection = (this.level == 0);
/* 64 */       int currentInfection = ThreadStatistics.getInfectionLevel(ThreadStatistics.stats.getString("statsData"));
/* 65 */       if (currentInfection < this.level)
/*    */       {
/* 67 */         if (currentInfection >= 0 && this.level != currentInfection + 1) {
/*    */           
/* 69 */           PacketHandler.sendToServer(iChunUtil.channels, new PacketPatientData(currentInfection, false, ""));
/*    */         }
/*    */         else {
/*    */           
/* 73 */           ThreadStatistics.stats.get("statsData").set(ThreadStatistics.getInfectionHash(this.level));
/* 74 */           ThreadStatistics.stats.save();
/*    */           
/* 76 */           if (!this.mutate) {
/*    */             
/* 78 */             (new ThreadStatistics(2, new Object[] { Integer.valueOf(this.level), this.infector })).start();
/*    */           }
/*    */           else {
/*    */             
/* 82 */             (new ThreadStatistics(3, new Object[] { Integer.valueOf(this.level) })).start();
/*    */           } 
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\mods\ichunutil\common\core\packet\mod\PacketPatientData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */