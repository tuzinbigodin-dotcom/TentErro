/*    */ package us.ichun.mods.ichunutil.common.core;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import cpw.mods.fml.common.gameevent.TickEvent;
/*    */ import ichun.common.core.EntityHelperBase;
/*    */ import ichun.common.core.network.AbstractPacket;
/*    */ import ichun.common.core.network.PacketHandler;
/*    */ import ichun.common.iChunUtil;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import us.ichun.mods.ichunutil.common.core.packet.mod.PacketPatientData;
/*    */ 
/*    */ 
/*    */ public class TickHandlerServer
/*    */ {
/*    */   public int ticks;
/*    */   
/*    */   @SubscribeEvent
/*    */   public void serverTick(TickEvent.ServerTickEvent event) {
/* 23 */     if (event.phase.equals(TickEvent.Phase.END))
/*    */     {
/* 25 */       this.ticks++;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void playerTick(TickEvent.PlayerTickEvent event) {
/* 32 */     if (event.side.isServer() && event.phase.equals(TickEvent.Phase.END))
/*    */     {
/* 34 */       if (this.infectionMap.containsKey(event.player.func_146103_bH().getId().toString())) {
/*    */         
/* 36 */         int infectionLevel = ((Integer)this.infectionMap.get(event.player.func_146103_bH().getId().toString())).intValue();
/* 37 */         if (event.player.field_70173_aa % 13 == 0) {
/*    */           
/* 39 */           List<EntityPlayer> list = event.player.func_130014_f_().func_72872_a(EntityPlayer.class, event.player.field_70121_D.func_72314_b(5.0D, 5.0D, 5.0D));
/* 40 */           list.remove(event.player);
/* 41 */           for (int i = 0; i < list.size(); i++) {
/*    */             
/* 43 */             EntityPlayer player = list.get(i);
/* 44 */             if (player.field_70173_aa >= 100)
/*    */             {
/*    */ 
/*    */               
/* 48 */               if (this.infectionMap.containsKey(player.func_146103_bH().getId().toString())) {
/*    */                 
/* 50 */                 if (((Integer)this.infectionMap.get(player.func_146103_bH().getId().toString())).intValue() == infectionLevel - 1)
/*    */                 {
/* 52 */                   this.infectionMap.put(player.func_146103_bH().getId().toString(), Integer.valueOf(infectionLevel));
/* 53 */                   PacketHandler.sendToPlayer(iChunUtil.channels, (AbstractPacket)new PacketPatientData(infectionLevel, false, event.player.func_146103_bH().getId().toString().replace("-", "")), player);
/* 54 */                   player.func_70690_d(new PotionEffect(Potion.field_76428_l.field_76415_H, infectionLevel * 20));
/*    */                 }
/*    */               
/*    */               }
/*    */               else {
/*    */                 
/* 60 */                 this.infectionMap.put(player.func_146103_bH().getId().toString(), Integer.valueOf(0));
/* 61 */                 PacketHandler.sendToPlayer(iChunUtil.channels, (AbstractPacket)new PacketPatientData(0, false, event.player.func_146103_bH().getId().toString().replace("-", "")), player);
/* 62 */                 player.func_70690_d(new PotionEffect(Potion.field_76436_u.field_76415_H, 100));
/*    */               } 
/*    */             }
/*    */           } 
/*    */         } 
/*    */         
/* 68 */         if (infectionLevel == EntityHelperBase.getImmunityLevel(event.player.func_146103_bH().getId().toString().replaceAll("-", "")) - 1 && event.player.field_70170_p.field_73012_v.nextFloat() < 5.0E-4F) {
/*    */           
/* 70 */           this.infectionMap.put(event.player.func_146103_bH().getId().toString(), Integer.valueOf(infectionLevel + 1));
/* 71 */           PacketHandler.sendToPlayer(iChunUtil.channels, (AbstractPacket)new PacketPatientData(infectionLevel + 1, true, ""), event.player);
/* 72 */           event.player.func_70690_d(new PotionEffect(Potion.field_76428_l.field_76415_H, infectionLevel * 20));
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 80 */   public HashMap<String, Integer> infectionMap = new HashMap<String, Integer>();
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\mods\ichunutil\common\core\TickHandlerServer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */