/*    */ package us.ichun.module.tabula.common.math;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PolynomialFunctionLagrangeForm
/*    */ {
/*    */   private final double[] x;
/*    */   private final double[] y;
/*    */   
/*    */   public PolynomialFunctionLagrangeForm(double[] x, double[] y) {
/* 13 */     this.x = new double[x.length];
/* 14 */     this.y = new double[y.length];
/* 15 */     System.arraycopy(x, 0, this.x, 0, x.length);
/* 16 */     System.arraycopy(y, 0, this.y, 0, y.length);
/*    */   }
/*    */   
/*    */   public double value(double z) {
/* 20 */     return evaluateInternal(this.x, this.y, z);
/*    */   }
/*    */   
/*    */   private static double evaluateInternal(double[] x, double[] y, double z) {
/* 24 */     int nearest = 0;
/* 25 */     int n = x.length;
/* 26 */     double[] c = new double[n];
/* 27 */     double[] d = new double[n];
/* 28 */     double min_dist = Double.POSITIVE_INFINITY;
/* 29 */     for (int i = 0; i < n; i++) {
/*    */       
/* 31 */       c[i] = y[i];
/* 32 */       d[i] = y[i];
/*    */       
/* 34 */       double dist = Double.longBitsToDouble(Long.MAX_VALUE & Double.doubleToRawLongBits(z - x[i]));
/* 35 */       if (dist < min_dist) {
/* 36 */         nearest = i;
/* 37 */         min_dist = dist;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 42 */     double value = y[nearest];
/*    */     
/* 44 */     for (int j = 1; j < n; j++) {
/* 45 */       for (int k = 0; k < n - j; k++) {
/* 46 */         double tc = x[k] - z;
/* 47 */         double td = x[j + k] - z;
/* 48 */         double divider = x[k] - x[j + k];
/*    */         
/* 50 */         double w = (c[k + 1] - d[k]) / divider;
/* 51 */         c[k] = tc * w;
/* 52 */         d[k] = td * w;
/*    */       } 
/*    */       
/* 55 */       if (nearest < 0.5D * (n - j + 1)) {
/* 56 */         value += c[nearest];
/*    */       } else {
/* 58 */         nearest--;
/* 59 */         value += d[nearest];
/*    */       } 
/*    */     } 
/*    */     
/* 63 */     return value;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\common\math\PolynomialFunctionLagrangeForm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */