/*    */ package us.ichun.module.tabula.common.project.components;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import org.apache.commons.lang3.RandomStringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CubeInfo
/*    */ {
/*    */   public String name;
/*    */   public int[] dimensions;
/*    */   public double[] position;
/*    */   public double[] offset;
/*    */   public double[] rotation;
/*    */   public double[] scale;
/*    */   public int[] txOffset;
/*    */   
/*    */   public CubeInfo(String name) {
/* 23 */     this.dimensions = new int[3];
/*    */     
/* 25 */     this.position = new double[3];
/* 26 */     this.offset = new double[3];
/* 27 */     this.rotation = new double[3];
/*    */     
/* 29 */     this.scale = new double[3];
/*    */     
/* 31 */     this.txOffset = new int[2];
/* 32 */     this.txMirror = false;
/*    */     
/* 34 */     this.mcScale = 0.0D;
/*    */     
/* 36 */     this.opacity = 100.0D;
/*    */     
/* 38 */     this.hidden = false;
/*    */     
/* 40 */     this.children = new ArrayList<CubeInfo>();
/*    */     this.name = name;
/*    */     this.dimensions = new int[] { 1, 1, 1 };
/*    */     this.scale = new double[] { 1.0D, 1.0D, 1.0D };
/*    */     this.opacity = 100.0D;
/*    */     this.identifier = RandomStringUtils.randomAscii(20);
/*    */   }
/*    */   public boolean txMirror; public double mcScale; public double opacity; public boolean hidden; private ArrayList<CubeInfo> children; public String parentIdentifier; public String identifier; @SideOnly(Side.CLIENT)
/*    */   public transient ModelRenderer modelCube;
/*    */   public void addChild(CubeInfo info) {
/* 50 */     this.children.add(info);
/* 51 */     info.scale = new double[] { 1.0D, 1.0D, 1.0D };
/* 52 */     info.mcScale = 0.0D;
/* 53 */     info.opacity = this.opacity;
/* 54 */     info.parentIdentifier = this.identifier;
/* 55 */     info.hidden = false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void removeChild(CubeInfo info) {
/* 60 */     this.children.remove(info);
/* 61 */     if (info.parentIdentifier != null && info.parentIdentifier.equals(this.identifier))
/*    */     {
/* 63 */       info.parentIdentifier = null;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public ArrayList<CubeInfo> getChildren() {
/* 69 */     return this.children;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\common\project\components\CubeInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */