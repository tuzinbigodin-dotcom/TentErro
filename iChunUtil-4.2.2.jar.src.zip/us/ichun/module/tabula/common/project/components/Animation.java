/*    */ package us.ichun.module.tabula.common.project.components;
/*    */ 
/*    */ import com.google.common.collect.Ordering;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Comparator;
/*    */ import java.util.Map;
/*    */ import java.util.TreeMap;
/*    */ import org.apache.commons.lang3.RandomStringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Animation
/*    */ {
/*    */   public String name;
/*    */   public String identifier;
/*    */   public boolean loops;
/* 18 */   public TreeMap<String, ArrayList<AnimationComponent>> sets = new TreeMap<String, ArrayList<AnimationComponent>>((Comparator<? super String>)Ordering.natural());
/*    */   
/*    */   public transient int playTime;
/*    */   
/*    */   public transient boolean playing;
/*    */   
/*    */   public Animation(String name) {
/* 25 */     this.name = name;
/* 26 */     this.identifier = RandomStringUtils.randomAscii(20);
/*    */   }
/*    */ 
/*    */   
/*    */   public void createAnimComponent(String cubeIdent, String name, int length, int pos) {
/* 31 */     ArrayList<AnimationComponent> set = this.sets.get(cubeIdent);
/* 32 */     if (set == null) {
/*    */       
/* 34 */       set = new ArrayList<AnimationComponent>();
/* 35 */       this.sets.put(cubeIdent, set);
/*    */     } 
/*    */     
/* 38 */     set.add(new AnimationComponent(name, length, pos));
/*    */   }
/*    */ 
/*    */   
/*    */   public void update() {
/* 43 */     if (this.playing) {
/*    */       
/* 45 */       this.playTime++;
/* 46 */       if (this.playTime > getLength())
/*    */       {
/* 48 */         if (this.loops) {
/*    */           
/* 50 */           this.playTime = 0;
/*    */         }
/*    */         else {
/*    */           
/* 54 */           stop();
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void play() {
/* 62 */     if (!this.playing) {
/*    */       
/* 64 */       this.playing = true;
/* 65 */       this.playTime = 0;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void stop() {
/* 71 */     this.playing = false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 76 */     int lastTick = 0;
/* 77 */     for (Map.Entry<String, ArrayList<AnimationComponent>> e : this.sets.entrySet()) {
/*    */       
/* 79 */       for (AnimationComponent comp : e.getValue()) {
/*    */         
/* 81 */         if (comp.startKey + comp.length > lastTick)
/*    */         {
/* 83 */           lastTick = comp.startKey + comp.length;
/*    */         }
/*    */       } 
/*    */     } 
/* 87 */     return lastTick;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\common\project\components\Animation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */