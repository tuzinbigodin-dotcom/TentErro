/*     */ package us.ichun.module.tabula.common.project.components;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import org.apache.commons.lang3.RandomStringUtils;
/*     */ import us.ichun.module.tabula.common.math.PolynomialFunctionLagrangeForm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimationComponent
/*     */   implements Comparable
/*     */ {
/*  14 */   public double[] posChange = new double[3];
/*  15 */   public double[] rotChange = new double[3];
/*  16 */   public double[] scaleChange = new double[3];
/*  17 */   public double opacityChange = 0.0D;
/*     */   
/*  19 */   public double[] posOffset = new double[3];
/*  20 */   public double[] rotOffset = new double[3];
/*  21 */   public double[] scaleOffset = new double[3];
/*  22 */   public double opacityOffset = 0.0D;
/*     */   
/*     */   public ArrayList<double[]> progressionCoords;
/*     */   
/*     */   public transient PolynomialFunctionLagrangeForm progressionCurve;
/*     */   
/*     */   public String name;
/*     */   
/*     */   public int length;
/*     */   
/*     */   public int startKey;
/*     */   
/*     */   public boolean hidden;
/*     */   
/*     */   public String identifier;
/*     */   
/*     */   public AnimationComponent(String name, int length, int startKey) {
/*  39 */     this.name = name;
/*  40 */     this.length = length;
/*  41 */     this.startKey = startKey;
/*  42 */     this.identifier = RandomStringUtils.randomAscii(20);
/*     */   }
/*     */ 
/*     */   
/*     */   public void animate(CubeInfo info, float time) {
/*  47 */     float prog = MathHelper.func_76131_a((time - this.startKey) / this.length, 0.0F, 1.0F);
/*  48 */     float mag = prog;
/*  49 */     if (getProgressionCurve() != null)
/*     */     {
/*  51 */       mag = MathHelper.func_76131_a((float)getProgressionCurve().value(prog), 0.0F, 1.0F);
/*     */     }
/*  53 */     if (time >= this.startKey) {
/*     */       
/*  55 */       for (int j = 0; j < 3; j++) {
/*     */         
/*  57 */         info.position[j] = info.position[j] + this.posOffset[j];
/*  58 */         info.rotation[j] = info.rotation[j] + this.rotOffset[j];
/*  59 */         info.scale[j] = info.scale[j] + this.scaleOffset[j];
/*     */       } 
/*  61 */       info.opacity += this.opacityOffset;
/*     */     } 
/*  63 */     for (int i = 0; i < 3; i++) {
/*     */       
/*  65 */       info.position[i] = info.position[i] + this.posChange[i] * mag;
/*  66 */       info.rotation[i] = info.rotation[i] + this.rotChange[i] * mag;
/*  67 */       info.scale[i] = info.scale[i] + this.scaleChange[i] * mag;
/*     */     } 
/*  69 */     info.opacity += this.opacityChange * mag;
/*     */     
/*  71 */     if (info.modelCube != null) {
/*     */       
/*  73 */       info.modelCube.func_78793_a((float)info.position[0], (float)info.position[1], (float)info.position[2]);
/*  74 */       info.modelCube.field_78795_f = (float)Math.toRadians(info.rotation[0]);
/*  75 */       info.modelCube.field_78796_g = (float)Math.toRadians(info.rotation[1]);
/*  76 */       info.modelCube.field_78808_h = (float)Math.toRadians(info.rotation[2]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset(CubeInfo info, float time) {
/*  82 */     float prog = MathHelper.func_76131_a((time - this.startKey) / this.length, 0.0F, 1.0F);
/*  83 */     float mag = prog;
/*  84 */     if (getProgressionCurve() != null)
/*     */     {
/*  86 */       mag = MathHelper.func_76131_a((float)getProgressionCurve().value(prog), 0.0F, 1.0F);
/*     */     }
/*  88 */     if (time >= this.startKey) {
/*     */       
/*  90 */       for (int j = 0; j < 3; j++) {
/*     */         
/*  92 */         info.position[j] = info.position[j] - this.posOffset[j];
/*  93 */         info.rotation[j] = info.rotation[j] - this.rotOffset[j];
/*  94 */         info.scale[j] = info.scale[j] - this.scaleOffset[j];
/*     */       } 
/*  96 */       info.opacity -= this.opacityOffset;
/*     */     } 
/*  98 */     for (int i = 0; i < 3; i++) {
/*     */       
/* 100 */       info.position[i] = info.position[i] - this.posChange[i] * mag;
/* 101 */       info.rotation[i] = info.rotation[i] - this.rotChange[i] * mag;
/* 102 */       info.scale[i] = info.scale[i] - this.scaleChange[i] * mag;
/*     */     } 
/* 104 */     info.opacity -= this.opacityChange * mag;
/*     */     
/* 106 */     if (info.modelCube != null) {
/*     */       
/* 108 */       info.modelCube.func_78793_a((float)info.position[0], (float)info.position[1], (float)info.position[2]);
/* 109 */       info.modelCube.field_78795_f = (float)Math.toRadians(info.rotation[0]);
/* 110 */       info.modelCube.field_78796_g = (float)Math.toRadians(info.rotation[1]);
/* 111 */       info.modelCube.field_78808_h = (float)Math.toRadians(info.rotation[2]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getProgressionFactor(double progression) {
/* 117 */     if (this.progressionCurve == null)
/*     */     {
/* 119 */       return progression;
/*     */     }
/* 121 */     return this.progressionCurve.value(progression);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addProgressionCoords(double x, double y) {
/* 126 */     if (this.progressionCoords == null)
/*     */     {
/* 128 */       this.progressionCoords = (ArrayList)new ArrayList<double>();
/*     */     }
/* 130 */     this.progressionCoords.add(new double[] { x, y });
/*     */     
/* 132 */     createProgressionCurve();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeProgressionCoords(double x, double y) {
/* 137 */     for (int i = this.progressionCoords.size() - 1; i >= 0; i--) {
/*     */       
/* 139 */       double[] coord = this.progressionCoords.get(i);
/* 140 */       if (coord[0] == x && coord[1] == y)
/*     */       {
/* 142 */         this.progressionCoords.remove(i);
/*     */       }
/*     */     } 
/*     */     
/* 146 */     if (this.progressionCoords.isEmpty()) {
/*     */       
/* 148 */       this.progressionCoords = null;
/* 149 */       this.progressionCurve = null;
/*     */     }
/*     */     else {
/*     */       
/* 153 */       createProgressionCurve();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void moveProgressionCoords(double x, double y, double newX, double newY) {
/* 159 */     for (int i = this.progressionCoords.size() - 1; i >= 0; i--) {
/*     */       
/* 161 */       double[] coord = this.progressionCoords.get(i);
/* 162 */       if (coord[0] == x && coord[1] == y) {
/*     */         
/* 164 */         coord[0] = newX;
/* 165 */         coord[1] = newY;
/*     */       } 
/*     */     } 
/*     */     
/* 169 */     createProgressionCurve();
/*     */   }
/*     */ 
/*     */   
/*     */   public void createProgressionCurve() {
/* 174 */     if (this.progressionCoords != null) {
/*     */       
/* 176 */       double[] xes = new double[this.progressionCoords.size() + 2];
/* 177 */       double[] yes = new double[this.progressionCoords.size() + 2];
/*     */       
/* 179 */       yes[0] = 0.0D; xes[0] = 0.0D;
/* 180 */       yes[1] = 1.0D; xes[1] = 1.0D;
/*     */       
/* 182 */       for (int i = 0; i < this.progressionCoords.size(); i++) {
/*     */         
/* 184 */         xes[2 + i] = ((double[])this.progressionCoords.get(i))[0];
/* 185 */         yes[2 + i] = ((double[])this.progressionCoords.get(i))[1];
/*     */       } 
/*     */       
/* 188 */       this.progressionCurve = new PolynomialFunctionLagrangeForm(xes, yes);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PolynomialFunctionLagrangeForm getProgressionCurve() {
/* 194 */     if (this.progressionCoords != null && this.progressionCurve == null)
/*     */     {
/* 196 */       createProgressionCurve();
/*     */     }
/* 198 */     return this.progressionCurve;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object arg0) {
/* 204 */     if (arg0 instanceof AnimationComponent) {
/*     */       
/* 206 */       AnimationComponent comp = (AnimationComponent)arg0;
/* 207 */       return Integer.compare(this.startKey, comp.startKey);
/*     */     } 
/* 209 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\common\project\components\AnimationComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */