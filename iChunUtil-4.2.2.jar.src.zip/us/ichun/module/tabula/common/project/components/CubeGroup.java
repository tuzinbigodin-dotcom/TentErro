/*    */ package us.ichun.module.tabula.common.project.components;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.apache.commons.lang3.RandomStringUtils;
/*    */ 
/*    */ public class CubeGroup
/*    */ {
/*    */   public ArrayList<CubeInfo> cubes;
/*    */   public ArrayList<CubeGroup> cubeGroups;
/*    */   public String name;
/*    */   public boolean txMirror;
/*    */   public boolean hidden;
/*    */   public String identifier;
/*    */   
/*    */   public CubeGroup(String name) {
/* 16 */     this.cubes = new ArrayList<CubeInfo>();
/* 17 */     this.cubeGroups = new ArrayList<CubeGroup>();
/*    */ 
/*    */ 
/*    */     
/* 21 */     this.txMirror = false;
/*    */     
/* 23 */     this.hidden = false;
/*    */     this.name = name;
/*    */     this.identifier = RandomStringUtils.randomAscii(20);
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\common\project\components\CubeGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */