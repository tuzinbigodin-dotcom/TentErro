/*     */ package us.ichun.module.tabula.common.project;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import ichun.common.iChunUtil;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.ModelBox;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.model.PositionTextureVertex;
/*     */ import net.minecraft.client.model.TextureOffset;
/*     */ import net.minecraft.client.resources.IResource;
/*     */ import us.ichun.module.tabula.client.model.ModelBaseDummy;
/*     */ import us.ichun.module.tabula.client.model.ModelInfo;
/*     */ import us.ichun.module.tabula.common.project.components.Animation;
/*     */ import us.ichun.module.tabula.common.project.components.CubeGroup;
/*     */ import us.ichun.module.tabula.common.project.components.CubeInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectInfo
/*     */ {
/*     */   public static final int IDENTIFIER_LENGTH = 20;
/*     */   public static final int PROJ_VERSION = 2;
/*     */   public transient String identifier;
/*     */   public transient File saveFile;
/*     */   public transient String saveFileMd5;
/*     */   public transient boolean saved;
/*     */   public transient int lastAutosave;
/*     */   public transient boolean autosaved;
/*  42 */   public transient float cameraFov = 30.0F;
/*  43 */   public transient float cameraZoom = 1.0F;
/*     */   
/*     */   public transient float cameraYaw;
/*     */   
/*     */   public transient float cameraPitch;
/*     */   
/*     */   public transient float cameraOffsetX;
/*     */   
/*     */   public transient float cameraOffsetY;
/*     */   
/*     */   public transient boolean ignoreNextImage;
/*     */   
/*     */   public transient File textureFile;
/*     */   
/*     */   public transient String textureFileMd5;
/*     */   public transient BufferedImage bufferedTexture;
/*     */   public transient boolean destroyed;
/*     */   public transient ArrayList<String> states;
/*     */   public transient int lastState;
/*     */   public transient int switchState;
/*     */   @SideOnly(Side.CLIENT)
/*     */   public transient ModelBaseDummy model;
/*     */   public String modelName;
/*     */   public String authorName;
/*     */   public int projVersion;
/*  68 */   public int textureWidth = 64;
/*  69 */   public int textureHeight = 32;
/*     */   
/*  71 */   public double[] scale = new double[] { 1.0D, 1.0D, 1.0D };
/*     */   
/*     */   public ArrayList<CubeGroup> cubeGroups;
/*     */   
/*     */   public ArrayList<CubeInfo> cubes;
/*     */   
/*     */   public ArrayList<Animation> anims;
/*     */   
/*     */   public int cubeCount;
/*     */   
/*     */   public ProjectInfo() {
/*  82 */     this.modelName = "";
/*  83 */     this.authorName = "";
/*  84 */     this.cameraFov = 30.0F;
/*  85 */     this.cameraZoom = 1.0F;
/*  86 */     this.cubeGroups = new ArrayList<CubeGroup>();
/*  87 */     this.cubes = new ArrayList<CubeInfo>();
/*  88 */     this.anims = new ArrayList<Animation>();
/*     */     
/*  90 */     this.states = new ArrayList<String>();
/*  91 */     this.switchState = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public ProjectInfo(String name, String author) {
/*  96 */     this();
/*  97 */     this.modelName = name;
/*  98 */     this.authorName = author;
/*     */     
/* 100 */     this.cubeGroups = new ArrayList<CubeGroup>();
/* 101 */     this.cubes = new ArrayList<CubeInfo>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAsJson() {
/* 107 */     Gson gson = new Gson();
/*     */     
/* 109 */     return gson.toJson(this);
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void initClient() {
/* 115 */     this.model = new ModelBaseDummy(this);
/* 116 */     this.model.field_78090_t = this.textureWidth;
/* 117 */     this.model.field_78089_u = this.textureHeight; int i;
/* 118 */     for (i = 0; i < this.cubeGroups.size(); i++)
/*     */     {
/* 120 */       createGroupCubes(this.cubeGroups.get(i));
/*     */     }
/* 122 */     for (i = 0; i < this.cubes.size(); i++)
/*     */     {
/* 124 */       this.model.createModelFromCubeInfo(this.cubes.get(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void destroy() {
/* 131 */     if (this.model != null && !this.destroyed) {
/*     */       
/* 133 */       this.destroyed = true;
/* 134 */       for (int i = this.model.cubes.size() - 1; i >= 0; i--)
/*     */       {
/* 136 */         this.model.removeCubeInfo(this.model.cubes.get(i));
/*     */       }
/* 138 */       this.model.rotationPoint.destroy();
/* 139 */       this.model.rotationControls.destroy();
/* 140 */       this.model.sizeControls.destroy();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<CubeInfo> getAllCubes() {
/* 146 */     ArrayList<CubeInfo> cubes = new ArrayList<CubeInfo>();
/* 147 */     addAllCubes(cubes, this.cubes);
/* 148 */     addAllCubesFromGroups(cubes, this.cubeGroups);
/* 149 */     return cubes;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAllCubes(ArrayList<CubeInfo> list, ArrayList<CubeInfo> cubes) {
/* 154 */     list.addAll(cubes);
/* 155 */     for (CubeInfo cube : cubes)
/*     */     {
/* 157 */       addAllCubes(list, cube.getChildren());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAllCubesFromGroups(ArrayList<CubeInfo> list, ArrayList<CubeGroup> groups) {
/* 163 */     for (CubeGroup group : groups) {
/*     */       
/* 165 */       addAllCubes(list, group.cubes);
/* 166 */       addAllCubesFromGroups(list, group.cubeGroups);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void createNewGroup() {
/* 172 */     this.cubeGroups.add(new CubeGroup("Group"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void createNewCube() {
/* 177 */     this.cubeCount++;
/* 178 */     this.cubes.add(new CubeInfo("shape" + Integer.toString(this.cubeCount)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void createNewAnimation(String name, boolean loop) {
/* 183 */     Animation anim = new Animation(name);
/* 184 */     anim.loops = loop;
/*     */     
/* 186 */     this.anims.add(anim);
/*     */   }
/*     */   
/*     */   private void createGroupCubes(CubeGroup group) {
/*     */     int i;
/* 191 */     for (i = 0; i < group.cubeGroups.size(); i++)
/*     */     {
/* 193 */       createGroupCubes(group.cubeGroups.get(i));
/*     */     }
/* 195 */     for (i = 0; i < group.cubes.size(); i++)
/*     */     {
/* 197 */       this.model.createModelFromCubeInfo(group.cubes.get(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getObjectByIdent(String ident) {
/* 203 */     Object obj = null;
/* 204 */     for (CubeInfo inf : this.cubes) {
/*     */       
/* 206 */       if (obj == null)
/*     */       {
/* 208 */         obj = findObjectInCube(ident, inf);
/*     */       }
/*     */     } 
/* 211 */     for (CubeGroup group1 : this.cubeGroups) {
/*     */       
/* 213 */       if (obj == null)
/*     */       {
/* 215 */         obj = findObjectInGroup(ident, group1);
/*     */       }
/*     */     } 
/* 218 */     return obj;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object findObjectInCube(String ident, CubeInfo cube) {
/* 223 */     if (cube.identifier.equals(ident))
/*     */     {
/* 225 */       return cube;
/*     */     }
/* 227 */     Object obj = null;
/* 228 */     for (CubeInfo inf : cube.getChildren()) {
/*     */       
/* 230 */       if (obj == null)
/*     */       {
/* 232 */         obj = findObjectInCube(ident, inf);
/*     */       }
/*     */     } 
/* 235 */     return obj;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object findObjectInGroup(String ident, CubeGroup group) {
/* 240 */     if (group.identifier.equals(ident))
/*     */     {
/* 242 */       return group;
/*     */     }
/* 244 */     Object obj = null;
/* 245 */     for (CubeInfo inf : group.cubes) {
/*     */       
/* 247 */       if (obj == null)
/*     */       {
/* 249 */         obj = findObjectInCube(ident, inf);
/*     */       }
/*     */     } 
/* 252 */     for (CubeGroup group1 : group.cubeGroups) {
/*     */       
/* 254 */       if (obj == null)
/*     */       {
/* 256 */         obj = findObjectInGroup(ident, group1);
/*     */       }
/*     */     } 
/* 259 */     return obj;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean importModel(ModelInfo model, boolean texture) {
/* 265 */     for (Map.Entry<String, ModelRenderer> e : (Iterable<Map.Entry<String, ModelRenderer>>)model.modelList.entrySet()) {
/*     */       
/* 267 */       ModelRenderer rend = e.getValue();
/*     */       
/* 269 */       if (this.cubes.isEmpty()) {
/*     */         
/* 271 */         this.textureHeight = (int)rend.field_78799_b;
/* 272 */         this.textureWidth = (int)rend.field_78801_a;
/*     */       } 
/*     */       
/* 275 */       CubeInfo firstCreated = null;
/*     */       
/* 277 */       if (rend.field_78804_l.isEmpty()) {
/*     */         
/* 279 */         CubeInfo info = new CubeInfo(e.getKey());
/*     */         
/* 281 */         info.dimensions[2] = 0; info.dimensions[1] = 0; info.dimensions[0] = 0;
/* 282 */         info.scale[2] = 1.0D; info.scale[1] = 1.0D; info.scale[0] = 1.0D;
/*     */         
/* 284 */         this.cubeCount++;
/* 285 */         this.cubes.add(info);
/* 286 */         if (firstCreated == null)
/*     */         {
/* 288 */           firstCreated = info;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 293 */         for (int j = 0; j < rend.field_78804_l.size(); j++) {
/*     */           
/* 295 */           ModelBox box = rend.field_78804_l.get(j);
/* 296 */           CubeInfo info = new CubeInfo((box.field_78247_g != null) ? box.field_78247_g.substring(box.field_78247_g.lastIndexOf(".") + 1) : ((String)e.getKey() + ((rend.field_78804_l.size() == 1) ? "" : (" - " + j))));
/*     */           
/* 298 */           info.dimensions[0] = (int)Math.abs(box.field_78248_d - box.field_78252_a);
/* 299 */           info.dimensions[1] = (int)Math.abs(box.field_78249_e - box.field_78250_b);
/* 300 */           info.dimensions[2] = (int)Math.abs(box.field_78246_f - box.field_78251_c);
/*     */           
/* 302 */           info.position[0] = rend.field_78800_c;
/* 303 */           info.position[1] = rend.field_78797_d;
/* 304 */           info.position[2] = rend.field_78798_e;
/*     */           
/* 306 */           info.offset[0] = box.field_78252_a;
/* 307 */           info.offset[1] = box.field_78250_b;
/* 308 */           info.offset[2] = box.field_78251_c;
/*     */           
/* 310 */           info.rotation[0] = Math.toDegrees(rend.field_78795_f);
/* 311 */           info.rotation[1] = Math.toDegrees(rend.field_78796_g);
/* 312 */           info.rotation[2] = Math.toDegrees(rend.field_78808_h);
/*     */           
/* 314 */           info.scale[2] = 1.0D; info.scale[1] = 1.0D; info.scale[0] = 1.0D;
/*     */           
/* 316 */           PositionTextureVertex[] vertices = (box.field_78254_i[1]).field_78239_a;
/*     */           
/* 318 */           info.txMirror = (((vertices[info.txMirror ? 1 : 2]).field_78243_a.field_72448_b - (vertices[info.txMirror ? 3 : 0]).field_78243_a.field_72448_b - info.dimensions[1]) / 2.0D < 0.0D);
/*     */           
/* 320 */           info.txOffset[0] = (int)((vertices[info.txMirror ? 2 : 1]).field_78241_b * rend.field_78801_a);
/* 321 */           info.txOffset[1] = (int)((vertices[info.txMirror ? 2 : 1]).field_78242_c * rend.field_78799_b) - info.dimensions[2];
/*     */           
/* 323 */           if ((vertices[info.txMirror ? 2 : 1]).field_78242_c > (vertices[info.txMirror ? 1 : 2]).field_78242_c) {
/*     */             
/* 325 */             info.txMirror = !info.txMirror;
/*     */             
/* 327 */             info.txOffset[0] = (int)((vertices[info.txMirror ? 2 : 1]).field_78241_b * rend.field_78801_a);
/* 328 */             info.txOffset[1] = (int)((vertices[info.txMirror ? 2 : 1]).field_78242_c * rend.field_78799_b) - info.dimensions[2];
/*     */           } 
/*     */           
/* 331 */           if (box.field_78247_g != null) {
/*     */             
/* 333 */             TextureOffset textureoffset = rend.field_78810_s.func_78084_a(box.field_78247_g);
/* 334 */             if (textureoffset != null) {
/*     */               
/* 336 */               info.txOffset[0] = textureoffset.field_78783_a;
/* 337 */               info.txOffset[1] = textureoffset.field_78782_b;
/*     */             } 
/*     */           } 
/*     */           
/* 341 */           info.mcScale = ((vertices[info.txMirror ? 1 : 2]).field_78243_a.field_72448_b - (vertices[info.txMirror ? 3 : 0]).field_78243_a.field_72448_b - info.dimensions[1]) / 2.0D;
/*     */           
/* 343 */           this.cubeCount++;
/* 344 */           this.cubes.add(info);
/* 345 */           if (firstCreated == null)
/*     */           {
/* 347 */             firstCreated = info;
/*     */           }
/*     */         } 
/*     */       } 
/* 351 */       if (firstCreated != null)
/*     */       {
/* 353 */         createChildren(e.getKey(), rend, firstCreated);
/*     */       }
/*     */     } 
/* 356 */     if (texture)
/*     */     {
/* 358 */       if (model.texture != null) {
/*     */         
/* 360 */         InputStream inputstream = null;
/*     */         
/*     */         try {
/* 363 */           IResource iresource = (Minecraft.func_71410_x()).field_110451_am.func_110536_a(model.texture);
/* 364 */           inputstream = iresource.func_110527_b();
/* 365 */           this.bufferedTexture = ImageIO.read(inputstream);
/*     */           
/* 367 */           if (this.bufferedTexture != null)
/*     */           {
/* 369 */             Iterator<Map.Entry<String, ModelRenderer>> iterator = model.modelList.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry<String, ModelRenderer> e = iterator.next();
/*     */               
/* 371 */               ModelRenderer rend = e.getValue();
/*     */               
/* 373 */               this.textureHeight = (int)rend.field_78799_b;
/* 374 */               this.textureWidth = (int)rend.field_78801_a; }
/*     */ 
/*     */ 
/*     */             
/* 378 */             return true;
/*     */           }
/*     */         
/* 381 */         } catch (Exception exception) {}
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 388 */         this.bufferedTexture = null;
/* 389 */         return true;
/*     */       } 
/*     */     }
/* 392 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void createChildren(String name, ModelRenderer rend, CubeInfo info) {
/* 398 */     if (rend.field_78805_m == null) {
/*     */       return;
/*     */     }
/*     */     
/* 402 */     for (int i = 0; i < rend.field_78805_m.size(); i++) {
/*     */       
/* 404 */       CubeInfo firstCreated = null;
/* 405 */       ModelRenderer rend1 = rend.field_78805_m.get(i);
/* 406 */       for (int j = 0; j < rend1.field_78804_l.size(); j++) {
/*     */         
/* 408 */         String fullName = name + ((rend1.field_78804_l.size() == 1) ? "Child" : ("Child - " + j));
/* 409 */         ModelBox box = rend1.field_78804_l.get(j);
/* 410 */         if (box.field_78247_g != null)
/*     */         {
/* 412 */           fullName = box.field_78247_g.substring(box.field_78247_g.lastIndexOf(".") + 1);
/*     */         }
/* 414 */         CubeInfo info1 = new CubeInfo(fullName);
/*     */         
/* 416 */         info1.dimensions[0] = (int)Math.abs(box.field_78248_d - box.field_78252_a);
/* 417 */         info1.dimensions[1] = (int)Math.abs(box.field_78249_e - box.field_78250_b);
/* 418 */         info1.dimensions[2] = (int)Math.abs(box.field_78246_f - box.field_78251_c);
/*     */         
/* 420 */         info1.position[0] = rend1.field_78800_c;
/* 421 */         info1.position[1] = rend1.field_78797_d;
/* 422 */         info1.position[2] = rend1.field_78798_e;
/*     */         
/* 424 */         info1.offset[0] = box.field_78252_a;
/* 425 */         info1.offset[1] = box.field_78250_b;
/* 426 */         info1.offset[2] = box.field_78251_c;
/*     */         
/* 428 */         info1.rotation[0] = Math.toDegrees(rend1.field_78795_f);
/* 429 */         info1.rotation[1] = Math.toDegrees(rend1.field_78796_g);
/* 430 */         info1.rotation[2] = Math.toDegrees(rend1.field_78808_h);
/*     */         
/* 432 */         info1.scale[2] = 1.0D; info1.scale[1] = 1.0D; info1.scale[0] = 1.0D;
/*     */         
/* 434 */         info1.txOffset[0] = rend1.field_78803_o;
/* 435 */         info1.txOffset[1] = rend1.field_78813_p;
/*     */         
/* 437 */         if (box.field_78247_g != null) {
/*     */           
/* 439 */           TextureOffset textureoffset = rend1.field_78810_s.func_78084_a(box.field_78247_g);
/* 440 */           if (textureoffset != null) {
/*     */             
/* 442 */             info1.txOffset[0] = textureoffset.field_78783_a;
/* 443 */             info1.txOffset[1] = textureoffset.field_78782_b;
/*     */           } 
/*     */         } 
/*     */         
/* 447 */         PositionTextureVertex[] vertices = (box.field_78254_i[1]).field_78239_a;
/* 448 */         info1.txMirror = (((vertices[info1.txMirror ? 1 : 2]).field_78243_a.field_72448_b - (vertices[info1.txMirror ? 3 : 0]).field_78243_a.field_72448_b - info1.dimensions[1]) / 2.0D < 0.0D);
/*     */         
/* 450 */         this.cubeCount++;
/* 451 */         info.addChild(info1);
/* 452 */         if (firstCreated == null)
/*     */         {
/* 454 */           firstCreated = info1;
/*     */         }
/*     */       } 
/* 457 */       if (firstCreated != null)
/*     */       {
/* 459 */         createChildren(name + "Child", rend1, firstCreated);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cloneFrom(ProjectInfo info) {
/* 466 */     this.saveFile = info.saveFile;
/* 467 */     this.saveFileMd5 = info.saveFileMd5;
/* 468 */     this.textureFile = info.textureFile;
/* 469 */     this.ignoreNextImage = info.ignoreNextImage;
/* 470 */     this.bufferedTexture = info.bufferedTexture;
/* 471 */     this.cameraFov = info.cameraFov;
/* 472 */     this.cameraZoom = info.cameraZoom;
/* 473 */     this.cameraYaw = info.cameraYaw;
/* 474 */     this.cameraPitch = info.cameraPitch;
/* 475 */     this.cameraOffsetX = info.cameraOffsetX;
/* 476 */     this.cameraOffsetY = info.cameraOffsetY;
/* 477 */     this.lastAutosave = info.lastAutosave;
/*     */   }
/*     */ 
/*     */   
/*     */   public void inherit(ProjectInfo info) {
/* 482 */     cloneFrom(info);
/* 483 */     this.identifier = info.identifier;
/* 484 */     this.textureFileMd5 = info.textureFileMd5;
/* 485 */     this.states = info.states;
/* 486 */     this.lastState = info.lastState;
/* 487 */     this.projVersion = info.projVersion;
/* 488 */     this.textureWidth = info.textureWidth;
/* 489 */     this.textureHeight = info.textureHeight;
/* 490 */     this.switchState = info.switchState;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getMaximumSize() {
/* 495 */     ArrayList<CubeInfo> allCubes = getAllCubes();
/* 496 */     double minX = 0.0D;
/* 497 */     double minY = 0.0D;
/* 498 */     double minZ = 0.0D;
/* 499 */     double maxX = 0.0D;
/* 500 */     double maxY = 0.0D;
/* 501 */     double maxZ = 0.0D;
/* 502 */     for (CubeInfo info : allCubes) {
/*     */       
/* 504 */       if ((info.position[0] + info.offset[0]) * info.scale[0] < minX)
/*     */       {
/* 506 */         minX = (info.position[0] + info.offset[0]) * info.scale[0];
/*     */       }
/* 508 */       if ((info.dimensions[0] + info.position[0] + info.offset[0]) * info.scale[0] > maxX)
/*     */       {
/* 510 */         maxX = (info.dimensions[0] + info.position[0] + info.offset[0]) * info.scale[0];
/*     */       }
/* 512 */       if ((info.position[1] + info.offset[1]) * info.scale[1] < minY)
/*     */       {
/* 514 */         minY = (info.position[1] + info.offset[1]) * info.scale[1];
/*     */       }
/* 516 */       if ((info.dimensions[1] + info.position[1] + info.offset[1]) * info.scale[1] > maxY)
/*     */       {
/* 518 */         maxY = (info.dimensions[1] + info.position[1] + info.offset[1]) * info.scale[1];
/*     */       }
/* 520 */       if ((info.position[2] + info.offset[2]) * info.scale[2] < minZ)
/*     */       {
/* 522 */         minZ = (info.position[2] + info.offset[2]) * info.scale[2];
/*     */       }
/* 524 */       if ((info.dimensions[2] + info.position[2] + info.offset[2]) * info.scale[2] > maxZ)
/*     */       {
/* 526 */         maxZ = (info.dimensions[2] + info.position[2] + info.offset[2]) * info.scale[2];
/*     */       }
/*     */     } 
/* 529 */     return (float)Math.max((maxX - minX) / this.scale[0], Math.max((maxY - minY) / this.scale[1] * 2.0D, (maxZ - minZ) / this.scale[2]));
/*     */   }
/*     */ 
/*     */   
/*     */   public void repair() {
/* 534 */     while (this.projVersion < 2) {
/*     */       
/* 536 */       if (this.projVersion == 1) {
/*     */         
/* 538 */         this.scale = new double[] { 1.0D, 1.0D, 1.0D };
/*     */         
/* 540 */         for (CubeInfo info : getAllCubes())
/*     */         {
/* 542 */           info.opacity = 100.0D;
/*     */         }
/*     */       } 
/* 545 */       this.projVersion++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean saveProject(ProjectInfo info, File file) {
/*     */     try {
/* 553 */       file.getParentFile().mkdirs();
/*     */       
/* 555 */       ZipOutputStream out = new ZipOutputStream(new FileOutputStream(file));
/* 556 */       out.setLevel(9);
/* 557 */       out.putNextEntry(new ZipEntry("model.json"));
/*     */       
/* 559 */       byte[] data = (new Gson()).toJson(info).getBytes();
/* 560 */       out.write(data, 0, data.length);
/* 561 */       out.closeEntry();
/*     */       
/* 563 */       if (info.bufferedTexture != null) {
/*     */         
/* 565 */         out.putNextEntry(new ZipEntry("texture.png"));
/* 566 */         ImageIO.write(info.bufferedTexture, "png", out);
/*     */       } 
/* 568 */       out.closeEntry();
/*     */       
/* 570 */       out.close();
/*     */       
/* 572 */       info.saved = true;
/* 573 */       return true;
/*     */     }
/* 575 */     catch (Exception e) {
/*     */       
/* 577 */       iChunUtil.console("Failed to save model: " + info.modelName, true);
/* 578 */       e.printStackTrace();
/* 579 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\common\project\ProjectInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */