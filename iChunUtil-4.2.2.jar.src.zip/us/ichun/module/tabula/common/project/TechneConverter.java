/*     */ package us.ichun.module.tabula.common.project;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TechneConverter
/*     */ {
/*     */   public static Rotation fromTechne(Rotation rotation) {
/*  19 */     Matrix3x3 rotationMatrixX = Matrix3x3.createRotationMatrixX(rotation.getRadiansX());
/*  20 */     Matrix3x3 rotationMatrixY = Matrix3x3.createRotationMatrixY(rotation.getRadiansY());
/*  21 */     Matrix3x3 rotationMatrixZ = Matrix3x3.createRotationMatrixZ(rotation.getRadiansZ());
/*     */     
/*  23 */     Matrix3x3 combinedRotation = rotationMatrixY.multiply(rotationMatrixZ).multiply(rotationMatrixX);
/*     */ 
/*     */     
/*  26 */     return Rotation.createFromMatrixZYX(combinedRotation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rotation toTechne(Rotation rotation) {
/*  35 */     Matrix3x3 rotationMatrixX = Matrix3x3.createRotationMatrixX(rotation.getRadiansX());
/*  36 */     Matrix3x3 rotationMatrixY = Matrix3x3.createRotationMatrixY(rotation.getRadiansY());
/*  37 */     Matrix3x3 rotationMatrixZ = Matrix3x3.createRotationMatrixZ(rotation.getRadiansZ());
/*     */     
/*  39 */     Matrix3x3 combinedRotation = rotationMatrixZ.multiply(rotationMatrixY).multiply(rotationMatrixX);
/*     */ 
/*     */     
/*  42 */     return Rotation.createFromMatrixYZX(combinedRotation);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Matrix3x3
/*     */   {
/*     */     private double[] data;
/*     */ 
/*     */     
/*     */     private Matrix3x3(double... data) {
/*  52 */       this.data = data;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Matrix3x3 createRotationMatrixX(double angle) {
/*  62 */       double c = Math.cos(angle);
/*  63 */       double s = Math.sin(angle);
/*  64 */       return new Matrix3x3(new double[] { 1.0D, 0.0D, 0.0D, 0.0D, c, -s, 0.0D, s, c });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Matrix3x3 createRotationMatrixY(double angle) {
/*  77 */       double c = Math.cos(angle);
/*  78 */       double s = Math.sin(angle);
/*  79 */       return new Matrix3x3(new double[] { c, 0.0D, s, 0.0D, 1.0D, 0.0D, -s, 0.0D, c });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Matrix3x3 createRotationMatrixZ(double angle) {
/*  92 */       double c = Math.cos(angle);
/*  93 */       double s = Math.sin(angle);
/*  94 */       return new Matrix3x3(new double[] { c, -s, 0.0D, s, c, 0.0D, 0.0D, 0.0D, 1.0D });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Matrix3x3 multiply(Matrix3x3 other) {
/* 107 */       Matrix3x3 result = new Matrix3x3(new double[9]);
/*     */       
/* 109 */       for (int x = 0; x < 3; x++) {
/* 110 */         for (int y = 0; y < 3; y++) {
/* 111 */           double val = 0.0D;
/* 112 */           for (int i = 0; i < 3; i++) {
/* 113 */             val += getValue(i, y) * other.getValue(x, i);
/*     */           }
/* 115 */           result.setValue(x, y, val);
/*     */         } 
/*     */       } 
/*     */       
/* 119 */       return result;
/*     */     }
/*     */     
/*     */     private void setValue(int x, int y, double val) {
/* 123 */       this.data[x + y * 3] = val;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getValue(int x, int y) {
/* 133 */       return this.data[x + y * 3];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void debug() {
/* 140 */       System.out.println();
/* 141 */       System.out.println("[" + this.data[0] + ", " + this.data[1] + ", " + this.data[2]);
/* 142 */       System.out.println(this.data[3] + ", " + this.data[4] + ", " + this.data[5]);
/* 143 */       System.out.println(this.data[6] + ", " + this.data[7] + ", " + this.data[8] + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Rotation
/*     */   {
/*     */     private double rotationX;
/*     */     
/*     */     private double rotationY;
/*     */     
/*     */     private double rotationZ;
/*     */     
/*     */     private Rotation(double rotationX, double rotationY, double rotationZ) {
/* 157 */       this.rotationX = rotationX;
/* 158 */       this.rotationY = rotationY;
/* 159 */       this.rotationZ = rotationZ;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Rotation createFromRadians(double rotationX, double rotationY, double rotationZ) {
/* 170 */       return new Rotation(rotationX, rotationY, rotationZ);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Rotation createFromDegrees(double rotationX, double rotationY, double rotationZ) {
/* 181 */       return new Rotation(Math.toRadians(rotationX), Math.toRadians(rotationY), Math.toRadians(rotationZ));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getRadiansX() {
/* 190 */       return this.rotationX;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getRadiansY() {
/* 198 */       return this.rotationY;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getRadiansZ() {
/* 206 */       return this.rotationZ;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDegreesX() {
/* 214 */       return Math.toDegrees(this.rotationX);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDegreesY() {
/* 222 */       return Math.toDegrees(this.rotationY);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDegreesZ() {
/* 230 */       return Math.toDegrees(this.rotationZ);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Rotation createFromMatrixZYX(TechneConverter.Matrix3x3 matrix) {
/* 243 */       Rotation result = new Rotation(0.0D, 0.0D, 0.0D);
/*     */ 
/*     */       
/* 246 */       if (matrix.getValue(0, 2) < 1.0D) {
/* 247 */         if (matrix.getValue(0, 2) > -1.0D) {
/* 248 */           result.rotationY = Math.asin(-matrix.getValue(0, 2));
/* 249 */           result.rotationZ = Math.atan2(matrix.getValue(0, 1), matrix.getValue(0, 0));
/* 250 */           result.rotationX = Math.atan2(matrix.getValue(1, 2), matrix.getValue(2, 2));
/*     */         } else {
/*     */           
/* 253 */           result.rotationY = 1.5707963267948966D;
/* 254 */           result.rotationZ = -Math.atan2(-matrix.getValue(2, 1), matrix.getValue(1, 1));
/* 255 */           result.rotationX = 0.0D;
/*     */         } 
/*     */       } else {
/* 258 */         result.rotationY = -1.5707963267948966D;
/* 259 */         result.rotationZ = Math.atan2(-matrix.getValue(2, 1), matrix.getValue(1, 1));
/* 260 */         result.rotationX = 0.0D;
/*     */       } 
/*     */       
/* 263 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Rotation createFromMatrixYZX(TechneConverter.Matrix3x3 matrix) {
/* 276 */       Rotation result = new Rotation(0.0D, 0.0D, 0.0D);
/*     */       
/* 278 */       if (matrix.getValue(0, 1) < 1.0D) {
/* 279 */         if (matrix.getValue(0, 1) > -1.0D) {
/* 280 */           result.rotationZ = Math.asin(matrix.getValue(0, 1));
/* 281 */           result.rotationY = Math.atan2(-matrix.getValue(0, 2), matrix.getValue(0, 0));
/* 282 */           result.rotationX = Math.atan2(-matrix.getValue(2, 1), matrix.getValue(1, 1));
/*     */         } else {
/* 284 */           result.rotationZ = -1.5707963267948966D;
/* 285 */           result.rotationY = -Math.atan2(matrix.getValue(1, 2), matrix.getValue(2, 2));
/* 286 */           result.rotationX = 0.0D;
/*     */         } 
/*     */       } else {
/* 289 */         result.rotationZ = 1.5707963267948966D;
/* 290 */         result.rotationY = Math.atan2(matrix.getValue(1, 2), matrix.getValue(2, 2));
/* 291 */         result.rotationX = 0.0D;
/*     */       } 
/*     */       
/* 294 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\common\project\TechneConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */