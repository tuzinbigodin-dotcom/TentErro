/*    */ package us.ichun.module.tabula.client.formats;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.io.FilenameUtils;
/*    */ import us.ichun.module.tabula.client.formats.types.ImportTabula;
/*    */ import us.ichun.module.tabula.client.formats.types.Importer;
/*    */ import us.ichun.module.tabula.common.project.ProjectInfo;
/*    */ 
/*    */ 
/*    */ public class ImportList
/*    */ {
/* 13 */   public static final ImportTabula tabulaImporterInstance = new ImportTabula();
/* 14 */   public static final HashMap<String, Importer> compatibleFormats = new HashMap<String, Importer>()
/*    */     {
/*    */     
/*    */     };
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isFileSupported(File file) {
/* 22 */     return compatibleFormats.containsKey(FilenameUtils.getExtension(file.getName()));
/*    */   }
/*    */ 
/*    */   
/*    */   public static ProjectInfo createProjectFromFile(File file) {
/* 27 */     if (compatibleFormats.containsKey(FilenameUtils.getExtension(file.getName())))
/*    */     {
/* 29 */       return ((Importer)compatibleFormats.get(FilenameUtils.getExtension(file.getName()))).createProjectInfo(file);
/*    */     }
/* 31 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\client\formats\ImportList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */