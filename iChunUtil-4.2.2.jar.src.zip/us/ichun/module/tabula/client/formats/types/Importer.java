package us.ichun.module.tabula.client.formats.types;

import java.io.File;
import us.ichun.module.tabula.common.project.ProjectInfo;

public abstract class Importer {
  public abstract ProjectInfo createProjectInfo(File paramFile);
  
  public abstract int getProjectVersion();
}


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\client\formats\types\Importer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */