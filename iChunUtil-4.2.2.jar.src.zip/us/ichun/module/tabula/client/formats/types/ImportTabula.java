/*     */ package us.ichun.module.tabula.client.formats.types;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import ichun.common.core.techne.TC1Json;
/*     */ import ichun.common.core.techne.TC2Info;
/*     */ import ichun.common.iChunUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import us.ichun.module.tabula.common.project.ProjectInfo;
/*     */ import us.ichun.module.tabula.common.project.TechneConverter;
/*     */ import us.ichun.module.tabula.common.project.components.CubeGroup;
/*     */ import us.ichun.module.tabula.common.project.components.CubeInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportTabula
/*     */   extends Importer
/*     */ {
/*     */   public ProjectInfo createProjectInfo(File file) {
/*     */     try {
/*  33 */       ZipFile zipFile = new ZipFile(file);
/*  34 */       Enumeration<? extends ZipEntry> entries = zipFile.entries();
/*     */       
/*  36 */       ZipEntry modelInfo = null;
/*  37 */       HashMap<String, InputStream> images = new HashMap<String, InputStream>();
/*     */       
/*  39 */       boolean tampered = false;
/*     */       
/*  41 */       while (entries.hasMoreElements()) {
/*     */         
/*  43 */         ZipEntry entry = entries.nextElement();
/*  44 */         if (!entry.isDirectory()) {
/*     */           
/*  46 */           if (entry.getName().endsWith(".png") && entry.getCrc() != Long.decode("0xf970c898").longValue())
/*     */           {
/*  48 */             images.put(entry.getName(), zipFile.getInputStream(entry));
/*     */           }
/*  50 */           if (entry.getName().endsWith(".xml") || entry.getName().endsWith(".json"))
/*     */           {
/*  52 */             modelInfo = entry;
/*     */           }
/*  54 */           if (!entry.getName().endsWith(".png") && !entry.getName().endsWith(".xml") && !entry.getName().endsWith(".json"))
/*     */           {
/*  56 */             tampered = true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*  61 */       ProjectInfo info = null;
/*  62 */       if (modelInfo != null)
/*     */       {
/*  64 */         if (modelInfo.getName().endsWith(".xml")) {
/*     */           
/*  66 */           info = convertTechneFile(TC2Info.convertTechneFile(zipFile.getInputStream(modelInfo), images), file.getName());
/*     */         }
/*     */         else {
/*     */           
/*  70 */           info = readModelFile(zipFile.getInputStream(modelInfo), images, file.getName());
/*     */         } 
/*     */       }
/*     */       
/*  74 */       zipFile.close();
/*     */       
/*  76 */       if (tampered)
/*     */       {
/*  78 */         iChunUtil.console(file.getName() + " is a tampered model file.", true);
/*     */       }
/*     */       
/*  81 */       return info;
/*     */     }
/*  83 */     catch (Exception e1) {
/*     */       
/*  85 */       e1.printStackTrace();
/*  86 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getProjectVersion() {
/*  93 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ProjectInfo convertTechneFile(TC2Info tc2Info, String fileName) {
/*  98 */     if (tc2Info == null)
/*     */     {
/* 100 */       return null;
/*     */     }
/*     */     
/* 103 */     ProjectInfo project = new ProjectInfo(fileName, "TechneToTabulaImporter");
/*     */     
/* 105 */     project.projVersion = 2;
/* 106 */     if (!tc2Info.Techne.Author.equals("ZeuX") && !tc2Info.Techne.Author.equals("NotZeux"))
/*     */     {
/* 108 */       project.authorName = tc2Info.Techne.Author;
/*     */     }
/*     */     
/* 111 */     float scaleX = 1.0F;
/* 112 */     float scaleY = 1.0F;
/* 113 */     float scaleZ = 1.0F;
/*     */     
/* 115 */     for (TC2Info.Model model : tc2Info.Techne.Models) {
/*     */ 
/*     */       
/*     */       try {
/* 119 */         String[] textureSize = model.Model.TextureSize.split(",");
/* 120 */         project.textureWidth = Integer.parseInt(textureSize[0]);
/* 121 */         project.textureHeight = Integer.parseInt(textureSize[1]);
/*     */         
/* 123 */         if (project.bufferedTexture == null)
/*     */         {
/* 125 */           project.bufferedTexture = model.Model.image;
/*     */         }
/*     */         
/* 128 */         String[] scale = model.Model.GlScale.split(",");
/* 129 */         scaleX = Float.parseFloat(scale[0]);
/* 130 */         scaleY = Float.parseFloat(scale[1]);
/* 131 */         scaleZ = Float.parseFloat(scale[2]);
/*     */         
/* 133 */         boolean degrees = determineAngleType(model.Model.Geometry);
/* 134 */         project.cubeCount += exploreTC2Info(project.cubes, project.cubeGroups, model.Model.Geometry, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, scaleX, scaleY, scaleZ, degrees);
/*     */       }
/* 136 */       catch (NumberFormatException e) {
/*     */         
/* 138 */         iChunUtil.console("Error parsing Techne 2 model for Tabula: Invalid number", true);
/* 139 */         e.printStackTrace();
/*     */       }
/* 141 */       catch (ArrayIndexOutOfBoundsException e) {
/*     */         
/* 143 */         iChunUtil.console("Error parsing Techne 2 model for Tabula: Array too short", true);
/*     */       } 
/*     */     } 
/*     */     
/* 147 */     return project;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean determineAngleType(TC2Info.Group geometry) {
/* 152 */     boolean degrees = false;
/* 153 */     if (geometry.Shape != null)
/*     */     {
/* 155 */       for (TC2Info.Shape shape : geometry.Shape) {
/*     */         
/* 157 */         String[] rot = shape.Rotation.split(",");
/* 158 */         double rX = Float.parseFloat(rot[0]);
/* 159 */         double rY = Float.parseFloat(rot[1]);
/* 160 */         double rZ = Float.parseFloat(rot[2]);
/*     */         
/* 162 */         if (rX < -3.141592653589793D || rX > Math.PI || rY < -3.141592653589793D || rY > Math.PI || rZ < -3.141592653589793D || rZ > Math.PI) {
/*     */           
/* 164 */           degrees = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 170 */     if (geometry.Null != null && !degrees)
/*     */     {
/* 172 */       for (TC2Info.Null nul : geometry.Null) {
/*     */         
/* 174 */         boolean degInner = determineAngleType(nul.Children);
/* 175 */         if (degInner) {
/*     */           
/* 177 */           degrees = degInner;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 182 */     return degrees;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int exploreTC2Info(ArrayList<CubeInfo> cubes, ArrayList<CubeGroup> groups, TC2Info.Group geometry, double posX, double posY, double posZ, double rotX, double rotY, double rotZ, float scaleX, float scaleY, float scaleZ, boolean isDegrees) {
/* 187 */     int cubeCount = 0;
/* 188 */     if (geometry.Shape != null)
/*     */     {
/* 190 */       for (TC2Info.Shape shape : geometry.Shape) {
/*     */         TechneConverter.Rotation rotation;
/* 192 */         CubeInfo info = new CubeInfo((shape.Name == null) ? ("shape" + Integer.toString(cubeCount + 1)) : shape.Name);
/*     */         
/* 194 */         String[] textureOffset = shape.TextureOffset.split(",");
/* 195 */         info.txOffset = new int[] { Integer.parseInt(textureOffset[0]), Integer.parseInt(textureOffset[1]) };
/* 196 */         info.txMirror = !shape.IsMirrored.equals("False");
/*     */         
/* 198 */         String[] pos = shape.Position.split(",");
/* 199 */         String[] rot = shape.Rotation.split(",");
/* 200 */         String[] size = shape.Size.split(",");
/* 201 */         String[] offset = { "0", "0", "0" };
/* 202 */         if (shape.Offset != null)
/*     */         {
/* 204 */           offset = shape.Offset.split(",");
/*     */         }
/* 206 */         info.position = new double[] { Float.parseFloat(pos[0]) + posX, Float.parseFloat(pos[1]) + posY, Float.parseFloat(pos[2]) + posZ };
/* 207 */         info.offset = new double[] { Float.parseFloat(offset[0]), Float.parseFloat(offset[1]), Float.parseFloat(offset[2]) };
/* 208 */         info.dimensions = new int[] { Integer.parseInt(size[0]), Integer.parseInt(size[1]), Integer.parseInt(size[2]) };
/*     */         
/* 210 */         double rX = Float.parseFloat(rot[0]) + rotX;
/* 211 */         double rY = Float.parseFloat(rot[1]) + rotY;
/* 212 */         double rZ = Float.parseFloat(rot[2]) + rotZ;
/*     */ 
/*     */         
/* 215 */         if (isDegrees) {
/*     */           
/* 217 */           rotation = TechneConverter.fromTechne(TechneConverter.Rotation.createFromDegrees(rX, rY, rZ));
/*     */         }
/*     */         else {
/*     */           
/* 221 */           rotation = TechneConverter.fromTechne(TechneConverter.Rotation.createFromRadians(rX, rY, rZ));
/*     */         } 
/* 223 */         info.rotation = new double[] { rotation.getDegreesX(), rotation.getDegreesY(), rotation.getDegreesZ() };
/* 224 */         info.scale = new double[] { scaleX, scaleY, scaleZ };
/*     */         
/* 226 */         cubes.add(info);
/*     */         
/* 228 */         cubeCount++;
/*     */       } 
/*     */     }
/* 231 */     if (geometry.Null != null)
/*     */     {
/* 233 */       for (TC2Info.Null nul : geometry.Null) {
/*     */         
/* 235 */         CubeGroup group = new CubeGroup(nul.Name);
/* 236 */         groups.add(group);
/* 237 */         String[] pos = nul.Position.split(",");
/* 238 */         String[] rot = nul.Rotation.split(",");
/* 239 */         cubeCount += exploreTC2Info(group.cubes, group.cubeGroups, nul.Children, Float.parseFloat(pos[0]), Float.parseFloat(pos[1]), Float.parseFloat(pos[2]), Float.parseFloat(rot[0]), Float.parseFloat(rot[1]), Float.parseFloat(rot[2]), scaleX, scaleY, scaleZ, isDegrees);
/*     */       } 
/*     */     }
/* 242 */     return cubeCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ProjectInfo readModelFile(InputStream json, HashMap<String, InputStream> images, String fileName) throws IOException {
/* 247 */     if (json == null || images == null)
/*     */     {
/* 249 */       return null;
/*     */     }
/*     */     
/* 252 */     StringWriter writer = new StringWriter();
/* 253 */     IOUtils.copy(json, writer);
/* 254 */     String jsonString = writer.toString();
/*     */     
/* 256 */     ProjectInfo project = null;
/*     */     
/* 258 */     if ((jsonString.contains("\"Techne\"") || jsonString.contains("\"\000T\000e\000c\000h\000n\000e\000\"")) && (jsonString.contains("@Version") || jsonString.contains("\000@\000V\000e\000r\000s\000i\000o\000n\000")) && !jsonString.contains("TechneToTabulaImporter")) {
/*     */       TC2Info info;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 264 */         info = (TC2Info)(new Gson()).fromJson(jsonString, TC2Info.class);
/*     */       }
/* 266 */       catch (JsonSyntaxException e1) {
/*     */         
/* 268 */         info = ((TC1Json)(new Gson()).fromJson(jsonString.replaceAll("\000", ""), TC1Json.class)).toTC2Info();
/*     */       } 
/* 270 */       if (info != null)
/*     */       {
/* 272 */         for (TC2Info.Model model : info.Techne.Models) {
/*     */           
/* 274 */           InputStream stream = images.get(model.Model.texture);
/* 275 */           if (stream != null) {
/*     */             
/* 277 */             model.Model.image = ImageIO.read(stream);
/* 278 */             stream.close();
/*     */           } 
/*     */         } 
/*     */         
/* 282 */         project = convertTechneFile(info, fileName);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 287 */       project = (ProjectInfo)(new Gson()).fromJson(jsonString, ProjectInfo.class);
/*     */       
/* 289 */       InputStream stream = images.get("texture.png");
/* 290 */       if (stream != null) {
/*     */         
/* 292 */         project.bufferedTexture = ImageIO.read(stream);
/* 293 */         stream.close();
/*     */       } 
/*     */     } 
/*     */     
/* 297 */     json.close();
/*     */     
/* 299 */     for (Map.Entry<String, InputStream> img : images.entrySet())
/*     */     {
/* 301 */       ((InputStream)img.getValue()).close();
/*     */     }
/* 303 */     return project;
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\client\formats\types\ImportTabula.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */