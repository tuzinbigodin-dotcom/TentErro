/*     */ package us.ichun.module.tabula.client.model;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.GLAllocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelRotationControls
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer shape1;
/*     */   public ModelRenderer shape1_1;
/*     */   public ModelRenderer shape1_2;
/*     */   public ModelRenderer shape1_3;
/*     */   public ModelRenderer shape1_4;
/*     */   public ModelRenderer shape1_5;
/*     */   public ModelRenderer shape1_6;
/*     */   public ModelRenderer shape1_7;
/*     */   
/*     */   public ModelRotationControls() {
/*  23 */     this.field_78090_t = 64;
/*  24 */     this.field_78089_u = 32;
/*  25 */     this.shape1_2 = new ModelRenderer(this, 0, 0);
/*  26 */     this.shape1_2.func_78793_a(0.0F, 0.0F, 0.0F);
/*  27 */     this.shape1_2.func_78790_a(-2.5F, -0.5F, 5.04F, 5, 1, 1, 0.0F);
/*  28 */     setRotateAngle(this.shape1_2, 0.0F, 3.1415927F, 0.0F);
/*  29 */     this.shape1_1 = new ModelRenderer(this, 0, 0);
/*  30 */     this.shape1_1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  31 */     this.shape1_1.func_78790_a(-2.5F, -0.5F, 5.04F, 5, 1, 1, 0.0F);
/*  32 */     setRotateAngle(this.shape1_1, 0.0F, 2.3561945F, 0.0F);
/*  33 */     this.shape1_7 = new ModelRenderer(this, 0, 0);
/*  34 */     this.shape1_7.func_78793_a(0.0F, 0.0F, 0.0F);
/*  35 */     this.shape1_7.func_78790_a(-2.5F, -0.5F, 5.04F, 5, 1, 1, 0.0F);
/*  36 */     setRotateAngle(this.shape1_7, 0.0F, 0.7853982F, 0.0F);
/*  37 */     this.shape1_6 = new ModelRenderer(this, 0, 0);
/*  38 */     this.shape1_6.func_78793_a(0.0F, 0.0F, 0.0F);
/*  39 */     this.shape1_6.func_78790_a(-2.5F, -0.5F, 5.04F, 5, 1, 1, 0.0F);
/*  40 */     setRotateAngle(this.shape1_6, 0.0F, 1.5707964F, 0.0F);
/*  41 */     this.shape1_5 = new ModelRenderer(this, 0, 0);
/*  42 */     this.shape1_5.func_78793_a(0.0F, 0.0F, 0.0F);
/*  43 */     this.shape1_5.func_78790_a(-2.5F, -0.5F, 5.04F, 5, 1, 1, 0.0F);
/*  44 */     setRotateAngle(this.shape1_5, 0.0F, 5.497787F, 0.0F);
/*  45 */     this.shape1_4 = new ModelRenderer(this, 0, 0);
/*  46 */     this.shape1_4.func_78793_a(0.0F, 0.0F, 0.0F);
/*  47 */     this.shape1_4.func_78790_a(-2.5F, -0.5F, 5.04F, 5, 1, 1, 0.0F);
/*  48 */     setRotateAngle(this.shape1_4, 0.0F, 4.712389F, 0.0F);
/*  49 */     this.shape1_3 = new ModelRenderer(this, 0, 0);
/*  50 */     this.shape1_3.func_78793_a(0.0F, 0.0F, 0.0F);
/*  51 */     this.shape1_3.func_78790_a(-2.5F, -0.5F, 5.04F, 5, 1, 1, 0.0F);
/*  52 */     setRotateAngle(this.shape1_3, 0.0F, 3.9269907F, 0.0F);
/*  53 */     this.shape1 = new ModelRenderer(this, 0, 0);
/*  54 */     this.shape1.func_78793_a(0.0F, 0.0F, 0.0F);
/*  55 */     this.shape1.func_78790_a(-2.5F, -0.5F, 5.04F, 5, 1, 1, 0.0F);
/*     */   }
/*     */   
/*     */   public void render(float f5) {
/*  59 */     this.shape1_2.func_78785_a(f5);
/*  60 */     this.shape1_1.func_78785_a(f5);
/*  61 */     this.shape1_7.func_78785_a(f5);
/*  62 */     this.shape1_6.func_78785_a(f5);
/*  63 */     this.shape1_5.func_78785_a(f5);
/*  64 */     this.shape1_4.func_78785_a(f5);
/*  65 */     this.shape1_3.func_78785_a(f5);
/*  66 */     this.shape1.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/*  73 */     modelRenderer.field_78795_f = x;
/*  74 */     modelRenderer.field_78796_g = y;
/*  75 */     modelRenderer.field_78808_h = z;
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  80 */     if (this.shape1.field_78812_q)
/*     */     {
/*  82 */       GLAllocation.func_74523_b(this.shape1.field_78811_r);
/*     */     }
/*  84 */     if (this.shape1_1.field_78812_q)
/*     */     {
/*  86 */       GLAllocation.func_74523_b(this.shape1_1.field_78811_r);
/*     */     }
/*  88 */     if (this.shape1_2.field_78812_q)
/*     */     {
/*  90 */       GLAllocation.func_74523_b(this.shape1_2.field_78811_r);
/*     */     }
/*  92 */     if (this.shape1_3.field_78812_q)
/*     */     {
/*  94 */       GLAllocation.func_74523_b(this.shape1_3.field_78811_r);
/*     */     }
/*  96 */     if (this.shape1_4.field_78812_q)
/*     */     {
/*  98 */       GLAllocation.func_74523_b(this.shape1_4.field_78811_r);
/*     */     }
/* 100 */     if (this.shape1_5.field_78812_q)
/*     */     {
/* 102 */       GLAllocation.func_74523_b(this.shape1_5.field_78811_r);
/*     */     }
/* 104 */     if (this.shape1_6.field_78812_q)
/*     */     {
/* 106 */       GLAllocation.func_74523_b(this.shape1_6.field_78811_r);
/*     */     }
/* 108 */     if (this.shape1_7.field_78812_q)
/*     */     {
/* 110 */       GLAllocation.func_74523_b(this.shape1_7.field_78811_r);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\client\model\ModelRotationControls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */