/*    */ package us.ichun.module.tabula.client.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ 
/*    */ 
/*    */ public final class ModelList
/*    */ {
/*  9 */   public static ArrayList<ModelInfo> models = new ArrayList<ModelInfo>();
/* 10 */   public static ArrayList<Class<? extends ModelBase>> modelBlacklist = new ArrayList<Class<? extends ModelBase>>();
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\client\model\ModelList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */