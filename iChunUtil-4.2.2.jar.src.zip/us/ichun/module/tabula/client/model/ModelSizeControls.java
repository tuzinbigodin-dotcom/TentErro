/*    */ package us.ichun.module.tabula.client.model;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.client.renderer.GLAllocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelSizeControls
/*    */   extends ModelBase
/*    */ {
/*    */   public ModelRenderer shape1;
/*    */   public ModelRenderer shape2;
/*    */   public ModelRenderer shape2_1;
/*    */   public ModelRenderer shape2_2;
/*    */   public ModelRenderer shape2_3;
/*    */   
/*    */   public ModelSizeControls() {
/* 20 */     this.field_78090_t = 64;
/* 21 */     this.field_78089_u = 32;
/* 22 */     this.shape2_1 = new ModelRenderer(this, 0, 0);
/* 23 */     this.shape2_1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 24 */     this.shape2_1.func_78790_a(-0.5F, 1.93F, -4.08F, 1, 1, 3, 0.0F);
/* 25 */     setRotateAngle(this.shape2_1, 1.0471976F, 1.5707964F, 0.0F);
/* 26 */     this.shape1 = new ModelRenderer(this, 0, 0);
/* 27 */     this.shape1.func_78793_a(0.0F, 0.0F, 0.0F);
/* 28 */     this.shape1.func_78790_a(-0.5F, -1.0F, -0.5F, 1, 6, 1, 0.0F);
/* 29 */     this.shape2 = new ModelRenderer(this, 0, 0);
/* 30 */     this.shape2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 31 */     this.shape2.func_78790_a(-0.5F, 1.93F, -4.08F, 1, 1, 3, 0.0F);
/* 32 */     setRotateAngle(this.shape2, 1.0471976F, 0.0F, 0.0F);
/* 33 */     this.shape2_3 = new ModelRenderer(this, 0, 0);
/* 34 */     this.shape2_3.func_78793_a(0.0F, 0.0F, 0.0F);
/* 35 */     this.shape2_3.func_78790_a(-0.5F, 1.93F, -4.08F, 1, 1, 3, 0.0F);
/* 36 */     setRotateAngle(this.shape2_3, 1.0471976F, 4.712389F, 0.0F);
/* 37 */     this.shape2_2 = new ModelRenderer(this, 0, 0);
/* 38 */     this.shape2_2.func_78793_a(0.0F, 0.0F, 0.0F);
/* 39 */     this.shape2_2.func_78790_a(-0.5F, 1.93F, -4.08F, 1, 1, 3, 0.0F);
/* 40 */     setRotateAngle(this.shape2_2, 1.0471976F, 3.1415927F, 0.0F);
/* 41 */     this.shape1.func_78792_a(this.shape2_1);
/* 42 */     this.shape1.func_78792_a(this.shape2);
/* 43 */     this.shape1.func_78792_a(this.shape2_3);
/* 44 */     this.shape1.func_78792_a(this.shape2_2);
/*    */   }
/*    */   
/*    */   public void render(float f5) {
/* 48 */     this.shape1.func_78785_a(f5);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 55 */     modelRenderer.field_78795_f = x;
/* 56 */     modelRenderer.field_78796_g = y;
/* 57 */     modelRenderer.field_78808_h = z;
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 62 */     if (this.shape1.field_78812_q)
/*    */     {
/* 64 */       GLAllocation.func_74523_b(this.shape1.field_78811_r);
/*    */     }
/* 66 */     if (this.shape2.field_78812_q)
/*    */     {
/* 68 */       GLAllocation.func_74523_b(this.shape2.field_78811_r);
/*    */     }
/* 70 */     if (this.shape2_1.field_78812_q)
/*    */     {
/* 72 */       GLAllocation.func_74523_b(this.shape2_1.field_78811_r);
/*    */     }
/* 74 */     if (this.shape2_2.field_78812_q)
/*    */     {
/* 76 */       GLAllocation.func_74523_b(this.shape2_2.field_78811_r);
/*    */     }
/* 78 */     if (this.shape2_3.field_78812_q)
/*    */     {
/* 80 */       GLAllocation.func_74523_b(this.shape2_3.field_78811_r);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\client\model\ModelSizeControls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */