/*    */ package us.ichun.module.tabula.client.model;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.client.renderer.GLAllocation;
/*    */ 
/*    */ public class ModelRotationPoint
/*    */   extends ModelBase
/*    */ {
/*    */   public ModelRenderer cube1;
/*    */   public ModelRenderer cube2;
/*    */   public ModelRenderer cube3;
/*    */   
/*    */   public ModelRotationPoint() {
/* 15 */     float size = 1.0F;
/* 16 */     this.cube1 = new ModelRenderer(this, 0, 0);
/* 17 */     this.cube1.func_78789_a(-(size / 2.0F), -(size / 2.0F), -(size / 2.0F), (int)size, (int)size, (int)size);
/* 18 */     this.cube1.field_78795_f = (float)Math.toRadians(45.0D);
/* 19 */     this.cube2 = new ModelRenderer(this, 0, 0);
/* 20 */     this.cube2.func_78789_a(-(size / 2.0F), -(size / 2.0F), -(size / 2.0F), (int)size, (int)size, (int)size);
/* 21 */     this.cube2.field_78796_g = (float)Math.toRadians(45.0D);
/* 22 */     this.cube3 = new ModelRenderer(this, 0, 0);
/* 23 */     this.cube3.func_78789_a(-(size / 2.0F), -(size / 2.0F), -(size / 2.0F), (int)size, (int)size, (int)size);
/* 24 */     this.cube3.field_78808_h = (float)Math.toRadians(45.0D);
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(float f5) {
/* 29 */     this.cube1.func_78785_a(f5);
/* 30 */     this.cube2.func_78785_a(f5);
/* 31 */     this.cube3.func_78785_a(f5);
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 36 */     if (this.cube1.field_78812_q)
/*    */     {
/* 38 */       GLAllocation.func_74523_b(this.cube1.field_78811_r);
/*    */     }
/* 40 */     if (this.cube2.field_78812_q)
/*    */     {
/* 42 */       GLAllocation.func_74523_b(this.cube2.field_78811_r);
/*    */     }
/* 44 */     if (this.cube3.field_78812_q)
/*    */     {
/* 46 */       GLAllocation.func_74523_b(this.cube3.field_78811_r);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\client\model\ModelRotationPoint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */