/*    */ package us.ichun.module.tabula.client.model;
/*    */ 
/*    */ import ichun.client.model.ModelHelper;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelInfo
/*    */   implements Comparable
/*    */ {
/*    */   public final ResourceLocation texture;
/*    */   public final ModelBase modelParent;
/*    */   public final HashMap<String, ModelRenderer> modelList;
/*    */   public final Class clz;
/*    */   
/*    */   public ModelInfo(ResourceLocation texture, ModelBase modelParent, Class clz) {
/* 20 */     this.texture = texture;
/* 21 */     this.modelParent = modelParent;
/* 22 */     this.modelList = ModelHelper.getModelCubesWithNames(modelParent);
/* 23 */     this.clz = clz;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int compareTo(Object arg0) {
/* 29 */     if (arg0 instanceof ModelInfo) {
/*    */       
/* 31 */       ModelInfo info = (ModelInfo)arg0;
/* 32 */       return this.modelParent.getClass().getSimpleName().compareTo(info.modelParent.getClass().getSimpleName());
/*    */     } 
/* 34 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\client\model\ModelInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */