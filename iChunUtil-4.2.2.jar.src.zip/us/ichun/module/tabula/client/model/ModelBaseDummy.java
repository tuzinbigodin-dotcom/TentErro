/*     */ package us.ichun.module.tabula.client.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.GLAllocation;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import us.ichun.module.tabula.common.project.ProjectInfo;
/*     */ import us.ichun.module.tabula.common.project.components.CubeInfo;
/*     */ 
/*     */ 
/*     */ public class ModelBaseDummy
/*     */   extends ModelBase
/*     */ {
/*     */   public ProjectInfo parent;
/*  18 */   public ArrayList<CubeInfo> cubes = new ArrayList<CubeInfo>();
/*     */   
/*     */   public ModelRotationPoint rotationPoint;
/*     */   
/*     */   public ModelSizeControls sizeControls;
/*     */   public ModelRotationControls rotationControls;
/*     */   
/*     */   public ModelBaseDummy(ProjectInfo par) {
/*  26 */     this.parent = par;
/*  27 */     this.field_78089_u = this.parent.textureHeight;
/*  28 */     this.field_78090_t = this.parent.textureWidth;
/*     */     
/*  30 */     this.rotationPoint = new ModelRotationPoint();
/*  31 */     this.sizeControls = new ModelSizeControls();
/*  32 */     this.rotationControls = new ModelRotationControls();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity ent, float f, float f1, float f2, float f3, float f4, float f5) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isChild(ArrayList<CubeInfo> childList, CubeInfo cube) {
/*  42 */     boolean flag = false;
/*  43 */     for (CubeInfo cube1 : childList) {
/*     */       
/*  45 */       if (cube1.equals(cube))
/*     */       {
/*  47 */         return true;
/*     */       }
/*  49 */       if (!flag)
/*     */       {
/*  51 */         flag = isChild(cube1.getChildren(), cube);
/*     */       }
/*     */     } 
/*  54 */     return flag;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<CubeInfo> getParents(CubeInfo info) {
/*  59 */     ArrayList<CubeInfo> parents = new ArrayList<CubeInfo>();
/*     */     
/*  61 */     for (CubeInfo cube : this.cubes)
/*     */     {
/*  63 */       addIfParent(parents, cube, info);
/*     */     }
/*     */     
/*  66 */     return parents;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addIfParent(ArrayList<CubeInfo> parents, CubeInfo parent, CubeInfo cube) {
/*  71 */     for (CubeInfo children : parent.getChildren())
/*     */     {
/*  73 */       addIfParent(parents, children, cube);
/*     */     }
/*  75 */     if (parent.getChildren().contains(cube) || (!parents.isEmpty() && parent.getChildren().contains(parents.get(parents.size() - 1))))
/*     */     {
/*  77 */       parents.add(parent);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(float f5, ArrayList<CubeInfo> cubesToSelect, ArrayList<CubeInfo> cubesToHide, float zoomLevel, boolean hasTexture, int pass, boolean renderRotationPoint, boolean renderControls) {
/*  83 */     ArrayList<CubeInfo> cubesToRender = new ArrayList<CubeInfo>(cubesToSelect);
/*  84 */     ArrayList<CubeInfo> unrendered = new ArrayList<CubeInfo>(cubesToSelect);
/*  85 */     unrendered.removeAll(this.cubes);
/*  86 */     if (!unrendered.isEmpty())
/*     */     {
/*  88 */       for (CubeInfo cube : unrendered) {
/*     */         
/*  90 */         for (int j = this.cubes.size() - 1; j >= 0; j--) {
/*     */           
/*  92 */           if (isChild(((CubeInfo)this.cubes.get(j)).getChildren(), cube))
/*     */           {
/*  94 */             cubesToRender.add(this.cubes.get(j));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*  99 */     for (int i = this.cubes.size() - 1; i >= 0; i--) {
/*     */       
/* 101 */       CubeInfo info = this.cubes.get(i);
/* 102 */       if (info.modelCube != null)
/*     */       {
/* 104 */         if (cubesToRender.isEmpty() && pass == 1 && !info.hidden && !cubesToHide.contains(info)) {
/*     */           
/* 106 */           GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F * (float)(info.opacity / 100.0D));
/*     */           
/* 108 */           GL11.glPushMatrix();
/* 109 */           GL11.glTranslatef(info.modelCube.field_82906_o, info.modelCube.field_82908_p, info.modelCube.field_82907_q);
/* 110 */           GL11.glTranslatef(info.modelCube.field_78800_c * f5, info.modelCube.field_78797_d * f5, info.modelCube.field_78798_e * f5);
/* 111 */           GL11.glScaled(info.scale[0], info.scale[1], info.scale[2]);
/* 112 */           GL11.glTranslatef(-info.modelCube.field_82906_o, -info.modelCube.field_82908_p, -info.modelCube.field_82907_q);
/* 113 */           GL11.glTranslatef(-info.modelCube.field_78800_c * f5, -info.modelCube.field_78797_d * f5, -info.modelCube.field_78798_e * f5);
/*     */           
/* 115 */           info.modelCube.func_78785_a(f5);
/*     */           
/* 117 */           GL11.glPopMatrix();
/*     */         }
/* 119 */         else if (cubesToRender.contains(info)) {
/*     */           
/* 121 */           if (pass == 0)
/*     */           {
/* 123 */             if (cubesToRender.size() == 1) {
/*     */               
/* 125 */               GL11.glColor4f(0.0F, 0.0F, 0.7F, 0.8F);
/*     */             }
/*     */             else {
/*     */               
/* 129 */               int clr = Math.abs(info.identifier.hashCode()) & 0xFFFFFF;
/* 130 */               float r = (clr >> 16 & 0xFF) / 255.0F;
/* 131 */               float g = (clr >> 8 & 0xFF) / 255.0F;
/* 132 */               float b = (clr & 0xFF) / 255.0F;
/* 133 */               GL11.glColor4f(r, g, b, 0.8F);
/*     */             } 
/*     */             
/* 136 */             renderSelectedCube(info, cubesToHide, f5, zoomLevel, hasTexture, (unrendered.contains(info) || cubesToSelect.contains(info)), renderRotationPoint, renderControls);
/*     */           }
/*     */         
/* 139 */         } else if (pass == 1 && !info.hidden && !cubesToHide.contains(info)) {
/*     */           
/* 141 */           GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F * (float)(info.opacity / 100.0D));
/*     */           
/* 143 */           GL11.glPushMatrix();
/* 144 */           GL11.glTranslatef(info.modelCube.field_82906_o, info.modelCube.field_82908_p, info.modelCube.field_82907_q);
/* 145 */           GL11.glTranslatef(info.modelCube.field_78800_c * f5, info.modelCube.field_78797_d * f5, info.modelCube.field_78798_e * f5);
/* 146 */           GL11.glScaled(info.scale[0], info.scale[1], info.scale[2]);
/* 147 */           GL11.glTranslatef(-info.modelCube.field_82906_o, -info.modelCube.field_82908_p, -info.modelCube.field_82907_q);
/* 148 */           GL11.glTranslatef(-info.modelCube.field_78800_c * f5, -info.modelCube.field_78797_d * f5, -info.modelCube.field_78798_e * f5);
/*     */           
/* 150 */           info.modelCube.func_78785_a(f5);
/*     */           
/* 152 */           GL11.glPopMatrix();
/*     */         } 
/*     */       }
/*     */     } 
/* 156 */     for (CubeInfo info : unrendered) {
/*     */       
/* 158 */       if (pass == 0) {
/*     */         
/* 160 */         if (cubesToRender.size() == 1) {
/*     */           
/* 162 */           GL11.glColor4f(0.0F, 0.0F, 0.7F, 0.8F);
/*     */         }
/*     */         else {
/*     */           
/* 166 */           int clr = Math.abs(info.identifier.hashCode()) & 0xFFFFFF;
/* 167 */           float r = (clr >> 16 & 0xFF) / 255.0F;
/* 168 */           float g = (clr >> 8 & 0xFF) / 255.0F;
/* 169 */           float b = (clr & 0xFF) / 255.0F;
/* 170 */           GL11.glColor4f(r, g, b, 0.8F);
/*     */         } 
/*     */         
/* 173 */         renderSelectedCube(info, cubesToHide, f5, zoomLevel, hasTexture, (unrendered.contains(info) || cubesToSelect.contains(info)), renderRotationPoint, renderControls);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderSelectedCube(CubeInfo info, ArrayList<CubeInfo> hidden, float f5, float zoomLevel, boolean hasTexture, boolean focus, boolean renderRotationPoint, boolean renderControls) {
/* 180 */     if (hasTexture)
/*     */     {
/* 182 */       GL11.glDisable(3553);
/*     */     }
/* 184 */     GL11.glDisable(2896);
/* 185 */     GL11.glEnable(2884);
/*     */     
/* 187 */     ArrayList<CubeInfo> parents = getParents(info);
/*     */     
/* 189 */     GL11.glPushMatrix();
/*     */     
/* 191 */     if (parents.isEmpty()) {
/*     */       
/* 193 */       GL11.glTranslatef(info.modelCube.field_82906_o, info.modelCube.field_82908_p, info.modelCube.field_82907_q);
/* 194 */       GL11.glTranslatef(info.modelCube.field_78800_c * f5, info.modelCube.field_78797_d * f5, info.modelCube.field_78798_e * f5);
/* 195 */       GL11.glScaled(info.scale[0], info.scale[1], info.scale[2]);
/* 196 */       GL11.glTranslatef(-info.modelCube.field_82906_o, -info.modelCube.field_82908_p, -info.modelCube.field_82907_q);
/* 197 */       GL11.glTranslatef(-info.modelCube.field_78800_c * f5, -info.modelCube.field_78797_d * f5, -info.modelCube.field_78798_e * f5);
/*     */     } 
/*     */     int i;
/* 200 */     for (i = parents.size() - 1; i >= 0; i--) {
/*     */       
/* 202 */       CubeInfo parent = parents.get(i);
/*     */       
/* 204 */       if (i == parents.size() - 1) {
/*     */         
/* 206 */         GL11.glTranslatef(parent.modelCube.field_82906_o, parent.modelCube.field_82908_p, parent.modelCube.field_82907_q);
/* 207 */         GL11.glTranslatef(parent.modelCube.field_78800_c * f5, parent.modelCube.field_78797_d * f5, parent.modelCube.field_78798_e * f5);
/* 208 */         GL11.glScaled(parent.scale[0], parent.scale[1], parent.scale[2]);
/* 209 */         GL11.glTranslatef(-parent.modelCube.field_82906_o, -parent.modelCube.field_82908_p, -parent.modelCube.field_82907_q);
/* 210 */         GL11.glTranslatef(-parent.modelCube.field_78800_c * f5, -parent.modelCube.field_78797_d * f5, -parent.modelCube.field_78798_e * f5);
/*     */       } 
/*     */       
/* 213 */       GL11.glTranslatef(parent.modelCube.field_82906_o, parent.modelCube.field_82908_p, parent.modelCube.field_82907_q);
/* 214 */       GL11.glTranslatef(parent.modelCube.field_78800_c * f5, parent.modelCube.field_78797_d * f5, parent.modelCube.field_78798_e * f5);
/*     */       
/* 216 */       if (parent.modelCube.field_78808_h != 0.0F)
/*     */       {
/* 218 */         GL11.glRotatef(parent.modelCube.field_78808_h * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */       }
/*     */       
/* 221 */       if (parent.modelCube.field_78796_g != 0.0F)
/*     */       {
/* 223 */         GL11.glRotatef(parent.modelCube.field_78796_g * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */       }
/*     */       
/* 226 */       if (parent.modelCube.field_78795_f != 0.0F)
/*     */       {
/* 228 */         GL11.glRotatef(parent.modelCube.field_78795_f * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 233 */     GL11.glTranslatef(info.modelCube.field_82906_o, info.modelCube.field_82908_p, info.modelCube.field_82907_q);
/* 234 */     GL11.glTranslatef(info.modelCube.field_78800_c * f5, info.modelCube.field_78797_d * f5, info.modelCube.field_78798_e * f5);
/*     */     
/* 236 */     if (focus && renderRotationPoint)
/*     */     {
/* 238 */       this.rotationPoint.render(f5);
/*     */     }
/*     */     
/* 241 */     if (renderControls) {
/*     */       
/* 243 */       GL11.glPushMatrix();
/*     */       
/* 245 */       if (info.modelCube.field_78808_h != 0.0F)
/*     */       {
/* 247 */         GL11.glRotatef(info.modelCube.field_78808_h * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */       }
/*     */       
/* 250 */       if (info.modelCube.field_78796_g != 0.0F)
/*     */       {
/* 252 */         GL11.glRotatef(info.modelCube.field_78796_g * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */       }
/*     */       
/* 255 */       if (info.modelCube.field_78795_f != 0.0F)
/*     */       {
/* 257 */         GL11.glRotatef(info.modelCube.field_78795_f * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */       }
/*     */       
/* 260 */       if (!GuiScreen.func_146272_n()) {
/*     */         
/* 262 */         GL11.glPushMatrix();
/* 263 */         float scale = 0.75F;
/* 264 */         GL11.glScalef(scale, scale, scale);
/* 265 */         GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/* 266 */         GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/* 267 */         this.rotationControls.render(f5);
/* 268 */         GL11.glRotatef(90.0F, 0.0F, 0.0F, -1.0F);
/* 269 */         this.rotationControls.render(f5);
/* 270 */         GL11.glRotatef(90.0F, -1.0F, 0.0F, 0.0F);
/* 271 */         this.rotationControls.render(f5);
/* 272 */         GL11.glPopMatrix();
/*     */       }
/*     */       else {
/*     */         
/* 276 */         GL11.glPushMatrix();
/* 277 */         float scale1 = 0.5F;
/* 278 */         GL11.glScalef(scale1, scale1, scale1);
/*     */         
/* 280 */         GL11.glPushMatrix();
/* 281 */         GL11.glTranslated(0.125D * (info.dimensions[0] / 2.0D + info.offset[0]), 0.125D * (1.0D + info.dimensions[1] + info.offset[1] + info.mcScale), 0.125D * (info.dimensions[2] / 2.0D + info.offset[2]));
/* 282 */         this.sizeControls.render(f5);
/* 283 */         GL11.glPopMatrix();
/*     */         
/* 285 */         GL11.glPushMatrix();
/* 286 */         GL11.glTranslated(0.125D * (info.dimensions[0] / 2.0D + info.offset[0]), -(0.125D * (1.0D - info.offset[1] + info.mcScale)), 0.125D * (info.dimensions[2] / 2.0D + info.offset[2]));
/* 287 */         GL11.glRotatef(180.0F, 0.0F, 0.0F, -1.0F);
/* 288 */         this.sizeControls.render(f5);
/* 289 */         GL11.glPopMatrix();
/*     */         
/* 291 */         GL11.glPushMatrix();
/* 292 */         GL11.glTranslated(0.125D * (1.0D + info.dimensions[0] + info.offset[0] + info.mcScale), 0.125D * (info.dimensions[1] / 2.0D + info.offset[1]), 0.125D * (info.dimensions[2] / 2.0D + info.offset[2]));
/* 293 */         GL11.glRotatef(90.0F, 0.0F, 0.0F, -1.0F);
/* 294 */         this.sizeControls.render(f5);
/* 295 */         GL11.glPopMatrix();
/*     */         
/* 297 */         GL11.glPushMatrix();
/* 298 */         GL11.glTranslated(-(0.125D * (1.0D - info.offset[0] + info.mcScale)), 0.125D * (info.dimensions[1] / 2.0D + info.offset[1]), 0.125D * (info.dimensions[2] / 2.0D + info.offset[2]));
/* 299 */         GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/* 300 */         this.sizeControls.render(f5);
/* 301 */         GL11.glPopMatrix();
/*     */         
/* 303 */         GL11.glPushMatrix();
/* 304 */         GL11.glTranslated(0.125D * (info.dimensions[0] / 2.0D + info.offset[0]), 0.125D * (info.dimensions[1] / 2.0D + info.offset[1]), 0.125D * (1.0D + info.dimensions[2] + info.offset[2] + info.mcScale));
/* 305 */         GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/* 306 */         this.sizeControls.render(f5);
/* 307 */         GL11.glPopMatrix();
/*     */         
/* 309 */         GL11.glPushMatrix();
/* 310 */         GL11.glTranslated(0.125D * (info.dimensions[0] / 2.0D + info.offset[0]), 0.125D * (info.dimensions[1] / 2.0D + info.offset[1]), -(0.125D * (1.0D - info.offset[2] + info.mcScale)));
/* 311 */         GL11.glRotatef(90.0F, -1.0F, 0.0F, 0.0F);
/* 312 */         this.sizeControls.render(f5);
/* 313 */         GL11.glPopMatrix();
/*     */         
/* 315 */         GL11.glPopMatrix();
/*     */       } 
/*     */       
/* 318 */       GL11.glPopMatrix();
/*     */     } 
/*     */     
/* 321 */     GL11.glPopMatrix();
/*     */     
/* 323 */     GL11.glPushMatrix();
/*     */     
/* 325 */     GL11.glDisable(2884);
/* 326 */     GL11.glEnable(2896);
/* 327 */     if (hasTexture)
/*     */     {
/* 329 */       GL11.glEnable(3553);
/*     */     }
/*     */ 
/*     */     
/* 333 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.9F * (float)(info.opacity / 100.0D));
/* 334 */     if (info.parentIdentifier == null && !info.hidden && !hidden.contains(info)) {
/*     */       
/* 336 */       GL11.glTranslatef(info.modelCube.field_82906_o, info.modelCube.field_82908_p, info.modelCube.field_82907_q);
/* 337 */       GL11.glTranslatef(info.modelCube.field_78800_c * f5, info.modelCube.field_78797_d * f5, info.modelCube.field_78798_e * f5);
/* 338 */       GL11.glScaled(info.scale[0], info.scale[1], info.scale[2]);
/* 339 */       GL11.glTranslatef(-info.modelCube.field_82906_o, -info.modelCube.field_82908_p, -info.modelCube.field_82907_q);
/* 340 */       GL11.glTranslatef(-info.modelCube.field_78800_c * f5, -info.modelCube.field_78797_d * f5, -info.modelCube.field_78798_e * f5);
/* 341 */       info.modelCube.func_78785_a(f5);
/*     */     } 
/*     */     
/* 344 */     if (hasTexture)
/*     */     {
/* 346 */       GL11.glDisable(3553);
/*     */     }
/* 348 */     GL11.glDisable(2896);
/*     */     
/* 350 */     if (focus) {
/*     */       
/* 352 */       GL11.glPushMatrix();
/*     */       
/* 354 */       for (i = parents.size() - 1; i >= 0; i--) {
/*     */         
/* 356 */         CubeInfo parent = parents.get(i);
/*     */         
/* 358 */         if (i == parents.size() - 1) {
/*     */           
/* 360 */           GL11.glTranslatef(parent.modelCube.field_82906_o, parent.modelCube.field_82908_p, parent.modelCube.field_82907_q);
/* 361 */           GL11.glTranslatef(parent.modelCube.field_78800_c * f5, parent.modelCube.field_78797_d * f5, parent.modelCube.field_78798_e * f5);
/* 362 */           GL11.glScaled(parent.scale[0], parent.scale[1], parent.scale[2]);
/* 363 */           GL11.glTranslatef(-parent.modelCube.field_82906_o, -parent.modelCube.field_82908_p, -parent.modelCube.field_82907_q);
/* 364 */           GL11.glTranslatef(-parent.modelCube.field_78800_c * f5, -parent.modelCube.field_78797_d * f5, -parent.modelCube.field_78798_e * f5);
/*     */         } 
/*     */         
/* 367 */         GL11.glTranslatef(parent.modelCube.field_82906_o, parent.modelCube.field_82908_p, parent.modelCube.field_82907_q);
/* 368 */         GL11.glTranslatef(parent.modelCube.field_78800_c * f5, parent.modelCube.field_78797_d * f5, parent.modelCube.field_78798_e * f5);
/*     */         
/* 370 */         if (parent.modelCube.field_78808_h != 0.0F)
/*     */         {
/* 372 */           GL11.glRotatef(parent.modelCube.field_78808_h * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */         }
/*     */         
/* 375 */         if (parent.modelCube.field_78796_g != 0.0F)
/*     */         {
/* 377 */           GL11.glRotatef(parent.modelCube.field_78796_g * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */         }
/*     */         
/* 380 */         if (parent.modelCube.field_78795_f != 0.0F)
/*     */         {
/* 382 */           GL11.glRotatef(parent.modelCube.field_78795_f * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 387 */       GL11.glTranslatef(info.modelCube.field_82906_o, info.modelCube.field_82908_p, info.modelCube.field_82907_q);
/* 388 */       GL11.glTranslatef(info.modelCube.field_78800_c * f5, info.modelCube.field_78797_d * f5, info.modelCube.field_78798_e * f5);
/*     */       
/* 390 */       if (info.modelCube.field_78808_h != 0.0F)
/*     */       {
/* 392 */         GL11.glRotatef(info.modelCube.field_78808_h * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */       }
/*     */       
/* 395 */       if (info.modelCube.field_78796_g != 0.0F)
/*     */       {
/* 397 */         GL11.glRotatef(info.modelCube.field_78796_g * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */       }
/*     */       
/* 400 */       if (info.modelCube.field_78795_f != 0.0F)
/*     */       {
/* 402 */         GL11.glRotatef(info.modelCube.field_78795_f * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */       }
/* 404 */       GL11.glTranslated(info.offset[0] * f5, info.offset[1] * f5, info.offset[2] * f5);
/*     */       
/* 406 */       float width = 4.0F * zoomLevel;
/* 407 */       float border = width * f5 * 6.25E-4F;
/* 408 */       GL11.glLineWidth(width);
/* 409 */       GL11.glColor4f(0.9F, 0.9F, 0.0F, 0.6F);
/* 410 */       GL11.glBegin(1);
/*     */       
/* 412 */       GL11.glVertex3f(-border - (float)info.mcScale * f5, -((float)info.mcScale) * f5, -((float)info.mcScale) * f5);
/* 413 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5 + border, -((float)info.mcScale) * f5, -((float)info.mcScale) * f5);
/*     */       
/* 415 */       GL11.glVertex3f(-border - (float)info.mcScale * f5, (float)(info.dimensions[1] + info.mcScale) * f5, -((float)info.mcScale) * f5);
/* 416 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5 + border, (float)(info.dimensions[1] + info.mcScale) * f5, -((float)info.mcScale) * f5);
/*     */       
/* 418 */       GL11.glVertex3f(-border - (float)info.mcScale * f5, -((float)info.mcScale) * f5, (float)(info.dimensions[2] + info.mcScale) * f5);
/* 419 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5 + border, -((float)info.mcScale) * f5, (float)(info.dimensions[2] + info.mcScale) * f5);
/*     */       
/* 421 */       GL11.glVertex3f(-border - (float)info.mcScale * f5, (float)(info.dimensions[1] + info.mcScale) * f5, (float)(info.dimensions[2] + info.mcScale) * f5);
/* 422 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5 + border, (float)(info.dimensions[1] + info.mcScale) * f5, (float)(info.dimensions[2] + info.mcScale) * f5);
/*     */       
/* 424 */       GL11.glVertex3f(-((float)info.mcScale) * f5, -((float)info.mcScale) * f5, -border - (float)info.mcScale * f5);
/* 425 */       GL11.glVertex3f(-((float)info.mcScale) * f5, -((float)info.mcScale) * f5, (float)(info.dimensions[2] + info.mcScale) * f5 + border);
/*     */       
/* 427 */       GL11.glVertex3f(-((float)info.mcScale) * f5, (float)(info.dimensions[1] + info.mcScale) * f5, -border - (float)info.mcScale * f5);
/* 428 */       GL11.glVertex3f(-((float)info.mcScale) * f5, (float)(info.dimensions[1] + info.mcScale) * f5, (float)(info.dimensions[2] + info.mcScale) * f5 + border);
/*     */       
/* 430 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5, -((float)info.mcScale) * f5, -border - (float)info.mcScale * f5);
/* 431 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5, -((float)info.mcScale) * f5, (float)(info.dimensions[2] + info.mcScale) * f5 + border);
/*     */       
/* 433 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5, (float)(info.dimensions[1] + info.mcScale) * f5, -border - (float)info.mcScale * f5);
/* 434 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5, (float)(info.dimensions[1] + info.mcScale) * f5, (float)(info.dimensions[2] + info.mcScale) * f5 + border);
/*     */       
/* 436 */       GL11.glVertex3f(-((float)info.mcScale) * f5, -border - (float)info.mcScale * f5, -((float)info.mcScale) * f5);
/* 437 */       GL11.glVertex3f(-((float)info.mcScale) * f5, (float)(info.dimensions[1] + info.mcScale) * f5 + border, -((float)info.mcScale) * f5);
/*     */       
/* 439 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5, -border - (float)info.mcScale * f5, -((float)info.mcScale) * f5);
/* 440 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5, (float)(info.dimensions[1] + info.mcScale) * f5 + border, -((float)info.mcScale) * f5);
/*     */       
/* 442 */       GL11.glVertex3f(-((float)info.mcScale) * f5, -border - (float)info.mcScale * f5, (float)(info.dimensions[2] + info.mcScale) * f5);
/* 443 */       GL11.glVertex3f(-((float)info.mcScale) * f5, (float)(info.dimensions[1] + info.mcScale) * f5 + border, (float)(info.dimensions[2] + info.mcScale) * f5);
/*     */       
/* 445 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5, -border - (float)info.mcScale * f5, (float)(info.dimensions[2] + info.mcScale) * f5);
/* 446 */       GL11.glVertex3f((float)(info.dimensions[0] + info.mcScale) * f5, (float)(info.dimensions[1] + info.mcScale) * f5 + border, (float)(info.dimensions[2] + info.mcScale) * f5);
/*     */       
/* 448 */       GL11.glEnd();
/*     */       
/* 450 */       GL11.glPopMatrix();
/*     */     } 
/* 452 */     GL11.glEnable(2896);
/* 453 */     if (hasTexture)
/*     */     {
/* 455 */       GL11.glEnable(3553);
/*     */     }
/*     */     
/* 458 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void createModelFromCubeInfo(CubeInfo info) {
/* 463 */     this.cubes.add(info);
/*     */     
/* 465 */     info.modelCube = new ModelRenderer(this, info.txOffset[0], info.txOffset[1]);
/* 466 */     info.modelCube.field_78809_i = info.txMirror;
/* 467 */     info.modelCube.func_78793_a((float)info.position[0], (float)info.position[1], (float)info.position[2]);
/* 468 */     info.modelCube.func_78790_a((float)info.offset[0], (float)info.offset[1], (float)info.offset[2], info.dimensions[0], info.dimensions[1], info.dimensions[2], (float)info.mcScale);
/* 469 */     info.modelCube.field_78795_f = (float)Math.toRadians(info.rotation[0]);
/* 470 */     info.modelCube.field_78796_g = (float)Math.toRadians(info.rotation[1]);
/* 471 */     info.modelCube.field_78808_h = (float)Math.toRadians(info.rotation[2]);
/*     */     
/* 473 */     createChildren(info);
/*     */   }
/*     */ 
/*     */   
/*     */   public void createChildren(CubeInfo cube) {
/* 478 */     for (CubeInfo child : cube.getChildren()) {
/*     */       
/* 480 */       child.modelCube = new ModelRenderer(this, child.txOffset[0], child.txOffset[1]);
/* 481 */       child.modelCube.field_78809_i = child.txMirror;
/* 482 */       child.modelCube.func_78789_a((float)child.offset[0], (float)child.offset[1], (float)child.offset[2], child.dimensions[0], child.dimensions[1], child.dimensions[2]);
/* 483 */       child.modelCube.func_78793_a((float)child.position[0], (float)child.position[1], (float)child.position[2]);
/* 484 */       child.modelCube.field_78795_f = (float)Math.toRadians(child.rotation[0]);
/* 485 */       child.modelCube.field_78796_g = (float)Math.toRadians(child.rotation[1]);
/* 486 */       child.modelCube.field_78808_h = (float)Math.toRadians(child.rotation[2]);
/*     */       
/* 488 */       cube.modelCube.func_78792_a(child.modelCube);
/*     */       
/* 490 */       createChildren(child);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeCubeInfo(CubeInfo info) {
/* 496 */     deleteModelDisplayList(info);
/* 497 */     this.cubes.remove(info);
/*     */   }
/*     */ 
/*     */   
/*     */   private void deleteModelDisplayList(CubeInfo info) {
/* 502 */     for (CubeInfo info1 : info.getChildren())
/*     */     {
/* 504 */       deleteModelDisplayList(info1);
/*     */     }
/* 506 */     if (info.modelCube != null && info.modelCube.field_78812_q) {
/*     */       
/* 508 */       GLAllocation.func_74523_b(info.modelCube.field_78811_r);
/* 509 */       info.modelCube = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\DADOS\Jogos\Minecraft Legends - Copia\mods\iChunUtil-4.2.2.jar\\us\ichun\module\tabula\client\model\ModelBaseDummy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */